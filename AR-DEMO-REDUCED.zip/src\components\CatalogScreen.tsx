"use client";

import React, { useState, useCallback, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LandmarkerCategory } from "@/hooks/useLandmarkers";
import { TurntablePreview } from "@/components/TurntablePreview";
import { ProductUploadModal } from "@/components/upload";
import { MobileConnectModal } from "@/components/mobile/MobileConnectModal";
import {
  useJewelleryStore,
  JewelleryItem,
  normalizeCategory,
} from "@/context/JewelleryStoreContext";
import { getJewelConfigById } from "@/jewels";
import { getOrRenderThumbnail } from "@/jewels/thumbnailRenderer";
import { RotateCcw, Eye, Sparkles } from "lucide-react";

interface CatalogScreenProps {
  onTryOn: (category: string, itemId: string) => void;
  extraCategories?: unknown;
}

const CATEGORY_ICONS: Record<string, string> = {
  necklaces: "📿",
  necklace: "📿",
  earrings: "💎",
  rings: "💍",
  finger_ring: "💍",
  bangles: "🔮",
  noserings: "💠",
  nose_ring: "💠",
  sets: "✨",
};

const CATEGORY_TITLES: Record<string, string> = {
  necklaces: "Necklaces & Chokers",
  necklace: "Necklaces & Chokers",
  earrings: "Earrings & Studs",
  rings: "Rings & Bands",
  finger_ring: "Rings & Bands",
  bangles: "Bracelets & Kada",
  noserings: "Nath & Studs",
  nose_ring: "Nath & Studs",
  sets: "Haute Sets & Suites",
};

/* ── 3D Rendered Thumbnail with lazy loading ── */
function ModelThumbnail({
  itemId,
  alt,
  className,
  fallbackSrc,
}: {
  itemId: string;
  alt: string;
  className?: string;
  fallbackSrc?: string;
}) {
  const [thumbnailUrl, setThumbnailUrl] = useState<string>(fallbackSrc || "");
  const [loading, setLoading] = useState(true);
  const [inView, setInView] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          obs.disconnect();
        }
      },
      { rootMargin: "300px" }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (!inView) return;
    let cancelled = false;

    if (fallbackSrc) {
      setThumbnailUrl(fallbackSrc);
      setLoading(false);
      return;
    }

    const config = getJewelConfigById(itemId);
    if (config) {
      getOrRenderThumbnail(config, "gold")
        .then((url) => {
          if (!cancelled && url) {
            setThumbnailUrl(url);
            setLoading(false);
          }
        })
        .catch(() => setLoading(false));
    } else {
      setLoading(false);
    }

    return () => {
      cancelled = true;
    };
  }, [inView, itemId, fallbackSrc]);

  return (
    <div ref={ref} className="w-full h-full relative flex items-center justify-center p-2">
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-amber-400/30 border-t-amber-400 rounded-full animate-spin" />
        </div>
      )}
      {thumbnailUrl && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={thumbnailUrl}
          alt={alt}
          className={`${className} transition-all duration-500 drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)] ${
            !loading ? "opacity-100 scale-100" : "opacity-0 scale-95"
          }`}
          onLoad={() => setLoading(false)}
        />
      )}
    </div>
  );
}

export function CatalogScreen({ onTryOn }: CatalogScreenProps) {
  const {
    allCategories,
    selectedItem,
    selectedCategory,
    setSelectedCategory,
    selectItem,
  } = useJewelleryStore();

  const [turntableItem, setTurntableItem] = useState<JewelleryItem | null>(null);
  const [showUploader, setShowUploader] = useState(false);
  const [showMobileModal, setShowMobileModal] = useState(false);

  const activeCat =
    allCategories.find((c) => c.id === selectedCategory) || allCategories[0];

  const handleSelectCategory = (catId: string) => {
    setSelectedCategory(catId);
    const cat = allCategories.find((c) => c.id === catId);
    if (cat && cat.items.length > 0) {
      selectItem(cat.items[0], catId);
    }
  };

  const handleOpen360 = useCallback(
    (e: React.MouseEvent, item: JewelleryItem) => {
      e.stopPropagation();
      selectItem(item, selectedCategory || undefined);
      setTurntableItem(item);
    },
    [selectItem, selectedCategory]
  );

  const handleClose360 = useCallback(() => {
    setTurntableItem(null);
  }, []);

  const handleTryOnFrom360 = useCallback(() => {
    if (turntableItem && selectedCategory) {
      const itemToTry = turntableItem;
      setTurntableItem(null);
      selectItem(itemToTry, selectedCategory);
      onTryOn(selectedCategory, itemToTry.id);
    }
  }, [turntableItem, selectedCategory, selectItem, onTryOn]);

  const handleItemTryOn = (item: JewelleryItem) => {
    selectItem(item, selectedCategory || undefined);
    onTryOn(selectedCategory || "necklaces", item.id);
  };

  return (
    <div className="min-h-screen bg-[#070708] text-neutral-100 flex flex-col relative selection:bg-[#D4AF37]/30 selection:text-[#F5E1A4]">
      {/* ── Background Atmospheric Glows ── */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[55%] bg-gradient-to-br from-[#D4AF37]/10 via-[#997a15]/5 to-transparent rounded-full blur-[160px]" />
        <div className="absolute top-[40%] right-[-15%] w-[50%] h-[50%] bg-[#5c4708]/8 rounded-full blur-[180px]" />
        <div className="absolute bottom-[-20%] left-[20%] w-[45%] h-[45%] bg-[#D4AF37]/5 rounded-full blur-[150px]" />
      </div>

      {/* ── Compact Hero ── */}
      <header className="relative z-10 pt-8 pb-4 px-4 text-center max-w-4xl mx-auto flex flex-col items-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/[0.04] border border-[#D4AF37]/30 mb-3 backdrop-blur-md">
          <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />
          <span className="text-[10px] font-medium tracking-[0.2em] text-[#F5E1A4] uppercase">
            Haute Joaillerie Atelier
          </span>
        </div>

        <h1 className="text-3xl sm:text-4xl font-normal font-serif tracking-tight text-white mb-1.5">
          <span className="text-gold-gradient font-serif italic">Aura</span> Fine Jewellery
        </h1>
        <p className="text-neutral-500 text-xs sm:text-sm font-light max-w-md leading-relaxed">
          50 handcrafted pieces • Real-time 3D AR try-on • 360° studio inspection
        </p>
      </header>

      {/* ── Sticky Category Tabs ── */}
      <div className="sticky top-0 z-30 backdrop-blur-xl bg-[#070708]/85 border-y border-white/[0.06] py-3 transition-all">
        <div className="max-w-6xl mx-auto px-4 flex items-center justify-between gap-4 overflow-x-auto hide-scrollbar">
          <div className="flex items-center gap-2">
            {allCategories.map((cat) => {
              const isActive = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  id={`cat-tab-${cat.id}`}
                  onClick={() => handleSelectCategory(cat.id)}
                  className={`flex-shrink-0 flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs sm:text-sm font-medium transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37] ${
                    isActive
                      ? "bg-gradient-to-r from-[#F5E1A4] via-[#E5C158] to-[#D4AF37] text-neutral-950 font-semibold shadow-lg shadow-[#D4AF37]/25 scale-[1.02]"
                      : "bg-[#141416]/80 text-neutral-300 border border-white/5 hover:border-[#D4AF37]/40 hover:text-white hover:bg-[#1a1a1d]"
                  }`}
                >
                  <span className="text-sm">{CATEGORY_ICONS[cat.id] ?? "💎"}</span>
                  <span>{cat.name}</span>
                  <span
                    className={`ml-1 text-[10px] px-1.5 rounded-full ${
                      isActive ? "bg-black/20 text-neutral-900" : "bg-white/5 text-neutral-400"
                    }`}
                  >
                    {cat.items.length}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowMobileModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.05] hover:bg-white/10 border border-[#D4AF37]/40 hover:border-[#D4AF37] text-[#F5E1A4] text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
            >
              <span>📱</span>
              <span className="hidden sm:inline">Try on</span> Mobile
            </button>
            <div className="hidden md:flex items-center text-xs text-neutral-400 tracking-wider uppercase font-medium">
              <span>{CATEGORY_TITLES[selectedCategory || ""] || "Collection"}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ── Main Catalog Grid ── */}
      <main className="relative z-10 flex-1 max-w-6xl mx-auto w-full px-4 pt-6 pb-24">
        {activeCat && (
          <motion.div layout className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-5">
            {/* Card #1: Upload card */}
            <motion.div
              layout
              onClick={() => setShowUploader(true)}
              whileHover={{ scale: 1.02, borderColor: "#D4AF37" }}
              whileTap={{ scale: 0.98 }}
              className="relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-white/15 bg-[#0e0e11]/80 hover:border-[#D4AF37]/45 hover:bg-[#131316] p-5 cursor-pointer transition-all duration-300 shadow-xl group text-center aspect-[3/4]"
            >
              <div className="w-12 h-12 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/20 flex items-center justify-center mb-3 group-hover:scale-110 transition">
                <Sparkles className="w-5 h-5 text-[#D4AF37]" />
              </div>
              <h3 className="text-sm font-bold text-white mb-1">
                + Upload Your Piece
              </h3>
              <p className="text-[10px] text-neutral-500 leading-tight max-w-[140px] mb-2">
                Photo or GLB for instant AI cutout & live try-on
              </p>
              <span className="text-[9px] font-semibold text-neutral-950 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-[#F5E1A4] to-[#D4AF37]">
                Add Bespoke Jewel
              </span>
            </motion.div>

            {/* Jewel Cards */}
            <AnimatePresence mode="popLayout">
              {activeCat.items.map((item) => {
                const isSelected = selectedItem?.id === item.id;
                const config = getJewelConfigById(item.id);
                const materialsLine = config?.materialsDescription || item.materialsDescription || "";
                const displayPrice = config?.price || item.price || "";

                return (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.25 }}
                    onClick={() => selectItem(item, selectedCategory || undefined)}
                    className={`group relative flex flex-col rounded-2xl border transition-all duration-300 cursor-pointer overflow-hidden aspect-[3/4] ${
                      isSelected
                        ? "border-[#D4AF37] bg-[#141416] shadow-xl shadow-[#D4AF37]/15 ring-1 ring-[#D4AF37]/50"
                        : "border-white/[0.06] bg-[#0c0c0e]/90 hover:border-white/15 hover:bg-[#111114]"
                    }`}
                  >
                    {/* 360 badge */}
                    <div className="absolute top-2.5 right-2.5 z-20 flex items-center gap-1.5">
                      <button
                        id={`open-360-${item.id}`}
                        onClick={(e) => handleOpen360(e, item)}
                        className="flex items-center gap-1 px-2 py-1 rounded-lg bg-black/70 hover:bg-[#D4AF37] text-white hover:text-neutral-950 backdrop-blur-md border border-white/10 hover:border-[#D4AF37] text-[10px] font-bold transition-all shadow-md active:scale-90"
                        title="Open 360° Studio"
                      >
                        <RotateCcw className="w-3 h-3" />
                        360°
                      </button>
                    </div>

                    {/* Thumbnail: Real Gold Product Photograph */}
                    {item.src || item.setNecklaceSrc || item.cutoutUrl ? (
                      <div className="relative w-full aspect-square bg-gradient-to-b from-[#16161a]/50 to-transparent flex items-center justify-center overflow-hidden p-3">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={item.src || item.setNecklaceSrc || item.cutoutUrl}
                          alt={item.name}
                          className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500 drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)]"
                          loading="lazy"
                        />
                      </div>
                    ) : (
                      <div className="relative w-full aspect-square bg-gradient-to-b from-[#16161a]/50 to-transparent flex items-center justify-center overflow-hidden">
                        <ModelThumbnail
                          itemId={item.id}
                          alt={item.name}
                          fallbackSrc={item.src || undefined}
                          className="w-4/5 h-4/5 object-contain group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                    )}

                    {/* Meta & Name */}
                    <div className="p-3.5 flex flex-col flex-1 justify-between gap-2.5 bg-[#090a0c]/80 border-t border-white/[0.04]">
                      <div>
                        {materialsLine && (
                          <p className="text-[10px] text-amber-200/50 mb-1 font-medium truncate">
                            {materialsLine}
                          </p>
                        )}
                        <h4
                          title={item.name}
                          className="text-sm font-semibold text-white font-serif tracking-wide line-clamp-2 leading-snug group-hover:text-[#F5E1A4] transition-colors"
                        >
                          {item.name}
                        </h4>
                      </div>

                      <div className="flex items-center justify-between pt-1.5 border-t border-white/[0.05]">
                        <span className="text-xs font-mono font-medium text-neutral-300">
                          {displayPrice}
                        </span>

                        <button
                          id={`catalog-tryon-${item.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleItemTryOn(item);
                          }}
                          className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-xl transition-all shadow-sm ${
                            isSelected
                              ? "bg-gradient-to-r from-[#F5E1A4] to-[#D4AF37] text-neutral-950 shadow-md shadow-[#D4AF37]/25"
                              : "bg-white/10 text-white hover:bg-[#D4AF37] hover:text-neutral-950"
                          }`}
                        >
                          <Eye className="w-3 h-3" />
                          Try On
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </motion.div>
        )}
      </main>

      {/* ── 360 Turntable Preview Modal ── */}
      {turntableItem && (
        <TurntablePreview
          item={turntableItem}
          onClose={handleClose360}
          onTryOn={handleTryOnFrom360}
        />
      )}

      {/* ── Upload Modal ── */}
      {showUploader && (
        <ProductUploadModal
          initialCategory={(selectedCategory || "necklace") as LandmarkerCategory}
          onClose={() => setShowUploader(false)}
          onItemAdded={(cat, item) => {
            const targetCat = normalizeCategory(cat);
            setSelectedCategory(targetCat);
            selectItem(item as unknown as JewelleryItem, targetCat);
          }}
        />
      )}

      {/* ── Mobile Connect Modal ── */}
      <MobileConnectModal
        isOpen={showMobileModal}
        onClose={() => setShowMobileModal(false)}
      />
    </div>
  );
}
