"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { DRACOLoader } from "three/examples/jsm/loaders/DRACOLoader.js";
import { useJewelleryStore, MetalType } from "@/context/JewelleryStoreContext";
import { METAL_TONES } from "@/jewels/materials";
import { getGlbModelWarnings } from "@/lib/glbValidator";
import {
  Play,
  Pause,
  Camera,
  AlertCircle,
  AlertTriangle,
  ChevronRight,
} from "lucide-react";

interface GlbTurntableViewerProps {
  /** Object URL or public URL of the .glb file */
  glbUrl: string;
  /** Display name for the model */
  modelName?: string;
  onClose: () => void;
  /** Called when user confirms and wants to add to catalog */
  onConfirm?: () => void;
  showTryOnButton?: boolean;
}

function createShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext("2d")!;
  const grad = ctx.createRadialGradient(128, 128, 10, 128, 128, 120);
  grad.addColorStop(0, "rgba(0, 0, 0, 0.65)");
  grad.addColorStop(0.4, "rgba(0, 0, 0, 0.28)");
  grad.addColorStop(0.8, "rgba(0, 0, 0, 0.06)");
  grad.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);
  return new THREE.CanvasTexture(canvas);
}

/** Checks if a material name suggests metal (so metal-switching applies to it) */
function isMetal(matName: string): boolean {
  const n = matName.toLowerCase();
  return n.includes("metal") || n.includes("gold") || n.includes("silver") || n.includes("brass");
}

/** Applies the chosen metal tone to all meshes whose material name suggests metal.
 *  Leaves gem/stone meshes untouched.
 */
function applyMetalToGlb(group: THREE.Object3D, metal: MetalType) {
  const cfg = METAL_TONES[metal] || METAL_TONES.gold;
  group.traverse((child) => {
    const mesh = child as THREE.Mesh;
    if (!mesh.isMesh) return;
    const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    mats.forEach((mat) => {
      if (!mat) return;
      const m = mat as THREE.MeshStandardMaterial;
      if (isMetal(m.name || "")) {
        m.color.setHex(cfg.color);
        m.roughness = cfg.roughness;
        m.metalness = cfg.metalness;
        m.needsUpdate = true;
      }
    });
  });
}

export function GlbTurntableViewer({
  glbUrl,
  modelName = "Custom 3D Model",
  onClose,
  onConfirm,
  showTryOnButton = true,
}: GlbTurntableViewerProps) {
  const { metal, setMetal } = useJewelleryStore();
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const controlsRef = useRef<OrbitControls | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);

  const [playing, setPlaying] = useState(true);
  const [rotationAngle, setRotationAngle] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [showWarnings, setShowWarnings] = useState(false);

  // Metal switching
  useEffect(() => {
    if (modelGroupRef.current) {
      applyMetalToGlb(modelGroupRef.current, metal);
    }
  }, [metal]);

  // Play/pause auto-rotate
  useEffect(() => {
    if (controlsRef.current) {
      controlsRef.current.autoRotate = playing;
    }
  }, [playing]);

  // Main Three.js scene + GLB loader
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    let disposed = false;
    setLoading(true);
    setError(null);
    setWarnings([]);

    const width = container.clientWidth || 560;
    const height = container.clientHeight || 420;

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    const pmrem = new THREE.PMREMGenerator(renderer);
    pmrem.compileEquirectangularShader();
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;

    // Studio lights
    const key = new THREE.DirectionalLight(0xfff5e6, 3.2);
    key.position.set(4, 7, 5);
    key.castShadow = true;
    scene.add(key);
    const fill = new THREE.DirectionalLight(0xddeeff, 1.6);
    fill.position.set(-4, 3, 3);
    scene.add(fill);
    const rim = new THREE.DirectionalLight(0xffffff, 2.8);
    rim.position.set(0, -3, -5);
    scene.add(rim);
    scene.add(new THREE.AmbientLight(0xffffff, 0.85));

    // Floor + shadow disc
    const floorGeo = new THREE.PlaneGeometry(30, 30);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x07080b,
      metalness: 0.92,
      roughness: 0.28,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -2.8;
    floor.receiveShadow = true;
    scene.add(floor);

    const shadowTex = createShadowTexture();
    const shadowDisc = new THREE.Mesh(
      new THREE.PlaneGeometry(6, 6),
      new THREE.MeshBasicMaterial({
        map: shadowTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.85,
      })
    );
    shadowDisc.rotation.x = -Math.PI / 2;
    shadowDisc.position.y = -2.78;
    scene.add(shadowDisc);

    const camera = new THREE.PerspectiveCamera(38, width / height, 0.001, 500);
    camera.position.set(0, 1.2, 5.5);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 2.4;
    controls.minDistance = 0.01;
    controls.maxDistance = 100;
    controlsRef.current = controls;

    // Set up DRACO loader (for compressed meshes)
    const dracoLoader = new DRACOLoader();
    dracoLoader.setDecoderPath("/wasm/draco/");

    const loader = new GLTFLoader();
    loader.setDRACOLoader(dracoLoader);

    loader.load(
      glbUrl,
      (gltf) => {
        if (disposed) return;

        const model = gltf.scene;

        // Normalize: center at origin, scale to standard display size
        const box = new THREE.Box3().setFromObject(model);
        const center = new THREE.Vector3();
        const size = new THREE.Vector3();
        box.getCenter(center);
        box.getSize(size);

        // Move center to origin
        model.position.sub(center);

        // Scale to fit in a ~2-unit bounding sphere (jewellery-like scale in the viewer)
        const maxDim = Math.max(size.x, size.y, size.z) || 1;
        const targetSize = 2.0;
        const scale = targetSize / maxDim;
        model.scale.setScalar(scale);

        const group = new THREE.Group();
        group.add(model);
        scene.add(group);
        modelGroupRef.current = group;

        // Apply current metal
        applyMetalToGlb(group, metal);

        // Auto-fit camera
        const scaledMax = maxDim * scale;
        const fov = camera.fov * (Math.PI / 180);
        const dist = Math.abs(scaledMax / 2 / Math.tan(fov / 2)) * 2.0;
        camera.position.set(0, scaledMax * 0.3, dist);
        camera.lookAt(0, 0, 0);
        controls.target.set(0, 0, 0);

        // Adjust floor/shadow
        const scaledSizeY = size.y * scale;
        floor.position.y = -scaledSizeY * 0.6;
        shadowDisc.position.y = -scaledSizeY * 0.6 + 0.02;
        shadowDisc.scale.setScalar(Math.min(3, scaledMax));

        controls.update();
        setLoading(false);

        // Post-load warnings (triangle count, texture size)
        const warns = getGlbModelWarnings(model);
        if (warns.length > 0) setWarnings(warns);
      },
      undefined,
      (err) => {
        if (disposed) return;
        console.error("[GlbTurntableViewer] Load error:", err);
        setError(
          `Failed to load 3D model. Make sure the file is a valid GLB with embedded textures.\n` +
            `(${(err as Error).message})`
        );
        setLoading(false);
      }
    );

    // Render loop
    const animate = () => {
      rafRef.current = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      disposed = true;
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("resize", handleResize);

      if (modelGroupRef.current) {
        modelGroupRef.current.traverse((c) => {
          const mesh = c as THREE.Mesh;
          if (mesh.isMesh) {
            mesh.geometry?.dispose();
            const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
            mats.forEach((m) => m?.dispose());
          }
        });
        scene.remove(modelGroupRef.current);
        modelGroupRef.current = null;
      }

      envTex.dispose();
      pmrem.dispose();
      shadowTex.dispose();
      floorGeo.dispose();
      floorMat.dispose();
      renderer.dispose();
      dracoLoader.dispose();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [glbUrl]);

  const handleAngleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const deg = parseFloat(e.target.value);
    setRotationAngle(deg);
    setPlaying(false);
    if (modelGroupRef.current) {
      modelGroupRef.current.rotation.y = (deg * Math.PI) / 180;
    }
  }, []);

  return (
    <div className="flex flex-col w-full h-full">
      {/* 3D Canvas */}
      <div
        ref={containerRef}
        className="relative w-full h-[340px] sm:h-[400px] bg-gradient-to-b from-[#0c0d11] to-[#040507] rounded-xl overflow-hidden"
      >
        <canvas
          ref={canvasRef}
          aria-label={modelName}
          className="w-full h-full cursor-grab active:cursor-grabbing"
        />

        {error && (
          <div className="absolute inset-0 flex items-center justify-center p-6 bg-black/90">
            <div className="text-center max-w-md p-5 rounded-xl border border-red-500/50 bg-red-950/40 text-red-200">
              <AlertCircle className="w-8 h-8 text-red-400 mx-auto mb-2" />
              <p className="text-sm font-mono whitespace-pre-wrap">{error}</p>
            </div>
          </div>
        )}

        {loading && !error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 pointer-events-none">
            <div className="w-10 h-10 border-2 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mb-3" />
            <p className="text-xs uppercase tracking-widest text-amber-200/80 font-mono">
              Loading 3D Model…
            </p>
          </div>
        )}

        {/* Warning badge */}
        {warnings.length > 0 && !loading && (
          <button
            onClick={() => setShowWarnings((v) => !v)}
            className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/20 border border-amber-400/40 text-amber-300 text-[10px] font-semibold hover:bg-amber-500/30 transition"
          >
            <AlertTriangle className="w-3 h-3" />
            {warnings.length} Warning{warnings.length > 1 ? "s" : ""}
          </button>
        )}

        <div className="absolute bottom-3 left-4 pointer-events-none text-[10px] tracking-wider text-zinc-400 font-mono bg-black/40 px-2 py-1 rounded backdrop-blur">
          DRAG TO ROTATE • SCROLL TO ZOOM
        </div>
      </div>

      {/* Warnings panel */}
      {showWarnings && warnings.length > 0 && (
        <div className="mx-0 mt-2 p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 space-y-1.5">
          {warnings.map((w, i) => (
            <p key={i} className="text-xs text-amber-200/90 flex gap-2">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
              {w}
            </p>
          ))}
        </div>
      )}

      {/* Controls */}
      <div className="pt-3 flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Play/Pause + Angle */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setPlaying((p) => !p)}
              className="p-2 rounded-lg bg-white/5 border border-white/10 hover:border-amber-400/40 text-zinc-300 hover:text-white transition-all flex items-center gap-1.5 text-xs font-mono"
            >
              {playing ? (
                <Pause className="w-3.5 h-3.5 text-amber-400" />
              ) : (
                <Play className="w-3.5 h-3.5 text-amber-400" />
              )}
              {playing ? "PAUSE" : "SPIN"}
            </button>

            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase tracking-wider text-zinc-400 font-mono">
                Angle
              </span>
              <input
                type="range"
                min="0"
                max="360"
                value={rotationAngle}
                onChange={handleAngleChange}
                className="w-24 sm:w-32 accent-amber-400 bg-zinc-800 rounded h-1 cursor-pointer"
              />
            </div>
          </div>

          {/* Metal Switching */}
          <div className="flex items-center gap-1 p-1 rounded-xl bg-white/5 border border-white/10">
            {(["gold", "silver", "rose_gold"] as MetalType[]).map((m) => (
              <button
                key={m}
                onClick={() => setMetal(m)}
                className={`px-2.5 py-1 text-[11px] rounded-lg font-medium transition-all ${
                  metal === m
                    ? m === "gold"
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                      : m === "silver"
                      ? "bg-slate-300/20 text-slate-200 border border-slate-300/40"
                      : "bg-rose-400/20 text-rose-300 border border-rose-400/40"
                    : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                {m === "gold" ? "22K Gold" : m === "silver" ? "Silver" : "Rose Gold"}
              </button>
            ))}
          </div>
        </div>

        <p className="text-[10px] text-zinc-500 font-mono">
          Metal switching applies to meshes named &quot;metal&quot;, &quot;gold&quot;, or &quot;silver&quot;. Stone/gem meshes
          are preserved.
        </p>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 pt-1">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-white/10 text-zinc-300 hover:text-white hover:bg-white/5 text-sm font-medium transition-colors"
          >
            Choose Different
          </button>
          {showTryOnButton && onConfirm && (
            <button
              id="glb-turntable-confirm"
              onClick={onConfirm}
              className="flex-1 py-2.5 px-5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-semibold text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 group"
            >
              <Camera className="w-4 h-4 transition-transform group-hover:scale-110" />
              Add to Catalog
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
