"use client";

import { useState, useCallback } from "react";
import { CatalogScreen } from "@/components/CatalogScreen";
import { TryOnScreen } from "@/components/TryOnScreen";
import { LandmarkerCategory } from "@/hooks/useLandmarkers";
import { useJewelleryStore } from "@/context/JewelleryStoreContext";

type Screen = "catalog" | "tryon";

export default function Home() {
  const [screen, setScreen] = useState<Screen>("catalog");
  const { selectedCategory, selectedItem, allCategories } = useJewelleryStore();

  const handleTryOn = useCallback(() => {
    setScreen("tryon");
  }, []);

  const handleBack = useCallback(() => {
    setScreen("catalog");
  }, []);

  const effectiveCat = selectedCategory || "necklace";
  const effectiveItemId = selectedItem?.id || allCategories[0]?.items[0]?.id || "";

  if (screen === "tryon") {
    return (
      <TryOnScreen
        initialCategory={effectiveCat as LandmarkerCategory}
        initialItemId={effectiveItemId}
        onBack={handleBack}
      />
    );
  }

  return (
    <CatalogScreen
      onTryOn={handleTryOn}
    />
  );
}
