import { NextRequest, NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";
import crypto from "crypto";

export const maxDuration = 60; // 60 seconds max

const MAX_GLB_SIZE = 20 * 1024 * 1024; // 20 MB
const MAX_PHOTO_SIZE = 5 * 1024 * 1024; // 5 MB

const GLB_MAGIC = [0x67, 0x6c, 0x54, 0x46]; // "glTF" ASCII bytes

export async function POST(req: NextRequest) {
  try {
    const contentType = req.headers.get("content-type") || "";
    if (!contentType.includes("multipart/form-data")) {
      return NextResponse.json(
        { error: "Content-Type must be multipart/form-data" },
        { status: 400 }
      );
    }

    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    const uploadType = (formData.get("type") as string || "glb").toLowerCase();
    const category = (formData.get("category") as string || "necklace").toLowerCase();

    if (!file) {
      return NextResponse.json(
        { error: "No file provided in form data ('file' field required)." },
        { status: 400 }
      );
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const originalName = file.name || "unnamed";
    const extension = originalName.split(".").pop()?.toLowerCase() || "";

    // ── GLB VALIDATION ──────────────────────────────────────────
    if (uploadType === "glb") {
      if (file.size > MAX_GLB_SIZE) {
        return NextResponse.json(
          {
            error: `File exceeds maximum allowed size of 20 MB (actual: ${(
              file.size / (1024 * 1024)
            ).toFixed(1)} MB).`,
          },
          { status: 400 }
        );
      }

      if (extension !== "glb" && extension !== "gltf") {
        return NextResponse.json(
          { error: "Invalid file extension. Only .glb and .gltf files are accepted." },
          { status: 400 }
        );
      }

      if (extension === "glb") {
        // Strict magic byte check: must begin with "glTF" (0x67 0x6C 0x54 0x46)
        if (buffer.length < 4) {
          return NextResponse.json(
            { error: "File too small to be a valid GLB binary." },
            { status: 400 }
          );
        }

        const isGlbMagic =
          buffer[0] === GLB_MAGIC[0] &&
          buffer[1] === GLB_MAGIC[1] &&
          buffer[2] === GLB_MAGIC[2] &&
          buffer[3] === GLB_MAGIC[3];

        if (!isGlbMagic) {
          return NextResponse.json(
            {
              error:
                "Invalid binary header. File does not contain the glTF magic header (0x46546C67). Renamed files are rejected.",
            },
            { status: 400 }
          );
        }
      } else {
        // .gltf JSON check
        try {
          const json = JSON.parse(buffer.toString("utf8"));
          if (!json.asset || !json.asset.version) {
            return NextResponse.json(
              { error: "Invalid glTF JSON: missing 'asset.version' declaration." },
              { status: 400 }
            );
          }
        } catch {
          return NextResponse.json(
            { error: "Invalid .gltf file: not valid JSON." },
            { status: 400 }
          );
        }
      }
    } else if (uploadType === "photo" || uploadType === "photos") {
      // ── PHOTO VALIDATION ───────────────────────────────────────
      if (file.size > MAX_PHOTO_SIZE) {
        return NextResponse.json(
          {
            error: `Photo exceeds maximum allowed size of 5 MB (actual: ${(
              file.size / (1024 * 1024)
            ).toFixed(1)} MB).`,
          },
          { status: 400 }
        );
      }

      const validMimes = ["image/jpeg", "image/png", "image/webp"];
      if (!validMimes.includes(file.type) && !["jpg", "jpeg", "png", "webp"].includes(extension)) {
        return NextResponse.json(
          { error: "Invalid photo type. Only JPEG, PNG, and WebP are accepted." },
          { status: 400 }
        );
      }
    }

    // ── SECURE PERSISTENCE TO UPLOADS DIRECTORY ─────────────────
    const uploadsDir = path.join(process.cwd(), "uploads");
    await fs.mkdir(uploadsDir, { recursive: true });

    const safeId = crypto.randomUUID();
    const safeFilename = `${uploadType}_${safeId}.${extension}`;
    const targetPath = path.join(uploadsDir, safeFilename);

    await fs.writeFile(targetPath, buffer);

    return NextResponse.json(
      {
        ok: true,
        filename: safeFilename,
        originalName,
        size: file.size,
        type: uploadType,
        category,
        url: `/uploads/${safeFilename}`,
      },
      { status: 200 }
    );
  } catch (err: unknown) {
    const error = err as Error;
    console.error("[API upload-product] Server error:", error);
    return NextResponse.json(
      { error: error.message || "Failed to process uploaded product." },
      { status: 500 }
    );
  }
}
