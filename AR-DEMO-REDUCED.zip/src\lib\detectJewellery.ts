"use client";

import {
  pipeline,
  type ZeroShotImageClassificationPipeline,
} from "@huggingface/transformers";

export const JEWELLERY_LABELS = [
  "necklace",
  "earring",
  "bracelet",
  "bangle",
  "finger ring",
  "nose ring",
] as const;

export type JewelleryLabel = (typeof JEWELLERY_LABELS)[number];

export interface DetectJewelleryResult {
  category: string;
  confidence: number;
}

// Lazy singleton for the classifier pipeline
let classifierPromise: Promise<ZeroShotImageClassificationPipeline> | null = null;

function getClassifier(): Promise<ZeroShotImageClassificationPipeline> {
  if (!classifierPromise) {
    classifierPromise = pipeline(
      "zero-shot-image-classification",
      "Xenova/clip-vit-base-patch32"
    ).catch((err) => {
      classifierPromise = null;
      throw err;
    });
  }
  return classifierPromise;
}

/**
 * Auto-detect jewellery type from an uploaded image using zero-shot classification.
 * Client-side only. Falls back gracefully by returning null on error.
 */
export async function detectJewellery(
  imageInput: string | HTMLCanvasElement | HTMLImageElement | Blob | File
): Promise<DetectJewelleryResult | null> {
  if (typeof window === "undefined") {
    return null;
  }

  try {
    const classifier = await getClassifier();
    let input: string;
    let objectUrl: string | null = null;

    if (typeof imageInput === "string") {
      input = imageInput;
    } else if (imageInput instanceof HTMLCanvasElement) {
      input = imageInput.toDataURL("image/jpeg", 0.9);
    } else if (imageInput instanceof HTMLImageElement) {
      input = imageInput.src;
    } else {
      objectUrl = URL.createObjectURL(imageInput);
      input = objectUrl;
    }

    try {
      const output = await classifier(input, [...JEWELLERY_LABELS], {
        hypothesis_template: "a product photo of a gold {}",
      });

      if (output.length > 0) {
        const top = output[0];
        return {
          category: top.label,
          confidence: top.score,
        };
      }

      return null;
    } finally {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    }
  } catch (error) {
    console.warn("Jewellery detection failed or model unavailable:", error);
    return null;
  }
}
