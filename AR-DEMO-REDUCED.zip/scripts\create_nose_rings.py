import os, math
from PIL import Image, ImageDraw, ImageFilter
import numpy as np

os.makedirs('public/catalog/nose_ring', exist_ok=True)

def create_metallic_gold_gradient(w, h):
    x = np.linspace(0, 1, w)
    y = np.linspace(0, 1, h)
    xx, yy = np.meshgrid(x, y)
    angle = np.arctan2(yy - 0.5, xx - 0.5)
    r = np.sqrt((xx - 0.5)**2 + (yy - 0.5)**2)
    # Luxury 22K gold shimmer
    wave = 0.5 + 0.5 * np.sin(angle * 4 + r * 6)
    red = (220 + 35 * wave).clip(0, 255).astype(np.uint8)
    green = (175 + 30 * wave).clip(0, 255).astype(np.uint8)
    blue = (55 + 25 * wave).clip(0, 255).astype(np.uint8)
    rgb = np.stack([red, green, blue], axis=-1)
    return Image.fromarray(rgb)

def generate_nose_rings():
    items = [
        # (id, name, style, details)
        ('gold_nose_ring_01.png', 'Royal Kundan Nath', 'nath_large', {'stones': 9, 'chain': True, 'ruby': True}),
        ('gold_nose_ring_02.png', 'Classic Pearl Nose Stud', 'stud_pearl', {'petals': 0, 'size': 50}),
        ('gold_nose_ring_03.png', 'Solitaire Diamond Nose Pin', 'stud_diamond', {'facets': 8, 'size': 44}),
        ('gold_nose_ring_04.png', 'Floral Cluster Nose Stud', 'flower', {'petals': 6, 'ruby_center': True}),
        ('gold_nose_ring_05.png', 'Traditional Gold Bali Hoop', 'hoop_plain', {'thickness': 14, 'radius': 110}),
        ('gold_nose_ring_06.png', 'Beaded Gold Nose Ring', 'hoop_beaded', {'beads': 16, 'radius': 105}),
        ('gold_nose_ring_07.png', 'Bridal Peacock Nath', 'nath_peacock', {'chain': True, 'pearl_drop': True}),
        ('gold_nose_ring_08.png', 'Heritage Ruby Nose Stud', 'stud_ruby', {'halo': True, 'size': 52}),
        ('gold_nose_ring_09.png', 'Filigree Gold Nose Hoop', 'hoop_filigree', {'radius': 100}),
        ('gold_nose_ring_10.png', 'Emerald Flower Nose Pin', 'flower', {'petals': 5, 'emerald': True}),
        ('gold_nose_ring_11.png', 'Celestial Star Nose Stud', 'star', {'points': 6}),
        ('gold_nose_ring_12.png', 'Teardrop Kundan Nath', 'nath_teardrop', {'chain': True}),
        ('gold_nose_ring_13.png', 'Twisted Wire Gold Hoop', 'hoop_twisted', {'radius': 95}),
        ('gold_nose_ring_14.png', 'Marquise Diamond Nose Stud', 'marquise', {'length': 65, 'width': 35}),
    ]

    for fname, name, style, props in items:
        out_path = os.path.join('public/catalog/nose_ring', fname)
        size = 500
        img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        cx, cy = size // 2, size // 2

        gold_base = (228, 185, 75, 255)
        gold_highlight = (255, 235, 160, 255)
        gold_shadow = (165, 120, 30, 255)
        diamond_white = (250, 252, 255, 255)
        ruby_red = (205, 28, 55, 255)
        emerald_green = (25, 165, 85, 255)
        pearl_cream = (248, 244, 235, 255)

        if 'stud' in style or style in ['flower', 'star', 'marquise']:
            # Render a stud/pin at center
            r = props.get('size', 60)
            if style == 'stud_pearl':
                # Pearl dome with gold bezel
                draw.ellipse([cx - r - 8, cy - r - 8, cx + r + 8, cy + r + 8], fill=gold_base, outline=gold_highlight, width=4)
                draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=pearl_cream)
                draw.ellipse([cx - r//3, cy - r//2, cx + r//4, cy - r//6], fill=(255, 255, 255, 240))
                # 4 prongs
                for a in [0, math.pi/2, math.pi, 3*math.pi/2]:
                    px = cx + (r + 4) * math.cos(a)
                    py = cy + (r + 4) * math.sin(a)
                    draw.ellipse([px - 6, py - 6, px + 6, py + 6], fill=gold_highlight)

            elif style == 'stud_diamond':
                # Brilliant cut diamond with gold prongs
                draw.ellipse([cx - r - 6, cy - r - 6, cx + r + 6, cy + r + 6], fill=gold_shadow)
                draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=diamond_white, outline=(220, 230, 245, 255), width=3)
                # Facet lines
                for a in np.linspace(0, 2*math.pi, 9)[:-1]:
                    fx = cx + r * math.cos(a)
                    fy = cy + r * math.sin(a)
                    draw.line([cx, cy, fx, fy], fill=(200, 215, 235, 180), width=2)
                draw.ellipse([cx - r//3, cy - r//3, cx + r//3, cy + r//3], fill=(255, 255, 255, 220))
                # 6 gold prongs
                for a in np.linspace(0, 2*math.pi, 7)[:-1]:
                    px = cx + (r + 2) * math.cos(a)
                    py = cy + (r + 2) * math.sin(a)
                    draw.ellipse([px - 5, py - 5, px + 5, py + 5], fill=gold_base, outline=gold_highlight)

            elif style == 'stud_ruby':
                # Ruby with diamond halo
                halo_r = r + 20
                draw.ellipse([cx - halo_r, cy - halo_r, cx + halo_r, cy + halo_r], fill=gold_shadow)
                # 10 halo diamonds
                for a in np.linspace(0, 2*math.pi, 11)[:-1]:
                    hx = cx + (r + 10) * math.cos(a)
                    hy = cy + (r + 10) * math.sin(a)
                    draw.ellipse([hx - 7, hy - 7, hx + 7, hy + 7], fill=diamond_white, outline=(200, 200, 200, 255))
                # Center ruby
                draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=ruby_red, outline=gold_highlight, width=3)
                draw.ellipse([cx - r//3, cy - r//3, cx + r//4, cy - r//6], fill=(255, 120, 150, 220))

            elif style == 'flower':
                petals = props.get('petals', 6)
                center_col = ruby_red if props.get('ruby_center') else (emerald_green if props.get('emerald') else gold_base)
                # Petals
                for i in range(petals):
                    a = i * (2 * math.pi / petals)
                    px = cx + 38 * math.cos(a)
                    py = cy + 38 * math.sin(a)
                    petal_fill = diamond_white if props.get('ruby_center') or props.get('emerald') else gold_base
                    draw.ellipse([px - 18, py - 18, px + 18, py + 18], fill=petal_fill, outline=gold_base, width=2)
                    draw.ellipse([px - 8, py - 8, px + 8, py + 8], fill=(255, 255, 255, 200))
                # Center
                draw.ellipse([cx - 20, cy - 20, cx + 20, cy + 20], fill=center_col, outline=gold_highlight, width=3)
                draw.ellipse([cx - 7, cy - 7, cx + 5, cy - 3], fill=(255, 255, 255, 190))

            elif style == 'star':
                # 6 point star in gold & diamond
                points = []
                for i in range(12):
                    rad = 55 if i % 2 == 0 else 22
                    a = i * (math.pi / 6)
                    points.append((cx + rad * math.cos(a), cy + rad * math.sin(a)))
                draw.polygon(points, fill=gold_base, outline=gold_highlight)
                draw.ellipse([cx - 15, cy - 15, cx + 15, cy + 15], fill=diamond_white, outline=gold_shadow)

            elif style == 'marquise':
                # Marquise pointed gem
                ml, mw = props.get('length', 65), props.get('width', 35)
                pts = [(cx, cy - ml), (cx + mw, cy), (cx, cy + ml), (cx - mw, cy)]
                draw.polygon(pts, fill=diamond_white, outline=gold_base)
                for p in pts:
                    draw.ellipse([p[0]-5, p[1]-5, p[0]+5, p[1]+5], fill=gold_highlight)

        elif 'hoop' in style:
            # Render elegant gold hoop
            hr = props.get('radius', 105)
            ht = props.get('thickness', 12)
            # Torus arc ring
            for a in np.linspace(0.1, 1.9 * math.pi, 240):
                hx = cx + hr * math.cos(a)
                hy = cy + hr * math.sin(a)
                draw.ellipse([hx - ht, hy - ht, hx + ht, hy + ht], fill=gold_base)
                draw.ellipse([hx - ht//2, hy - ht//2, hx + ht//2, hy + ht//2], fill=gold_highlight)
            
            if style == 'hoop_beaded':
                beads = props.get('beads', 16)
                for i in range(beads):
                    ba = i * (1.8 * math.pi / beads) + 0.15
                    bx = cx + (hr + 10) * math.cos(ba)
                    by = cy + (hr + 10) * math.sin(ba)
                    draw.ellipse([bx - 9, by - 9, bx + 9, by + 9], fill=gold_highlight, outline=gold_shadow)
            elif style == 'hoop_filigree':
                # Hanging tiny droplet
                dx = cx + hr * math.cos(math.pi / 2)
                dy = cy + hr * math.sin(math.pi / 2) + 25
                draw.ellipse([dx - 14, dy - 14, dx + 14, dy + 14], fill=ruby_red, outline=gold_highlight, width=3)
                draw.ellipse([dx - 8, dy + 20, dx + 8, dy + 36], fill=pearl_cream)

        elif 'nath' in style:
            # Traditional bridal nath with large hoop, gem cluster, and chain
            nr = 110
            nt = 8
            # Main ring
            for a in np.linspace(0, 2*math.pi, 200):
                nx = cx - 20 + nr * math.cos(a)
                ny = cy + nr * math.sin(a)
                draw.ellipse([nx - nt, ny - nt, nx + nt, ny + nt], fill=gold_base)
                draw.ellipse([nx - nt//2, ny - nt//2, nx + nt//2, ny + nt//2], fill=gold_highlight)
            
            # Ornate cluster along bottom-left
            cluster_a = 0.75 * math.pi
            cl_x = cx - 20 + nr * math.cos(cluster_a)
            cl_y = cy + nr * math.sin(cluster_a)
            
            # Central ruby/kundan medallion
            draw.ellipse([cl_x - 30, cl_y - 30, cl_x + 30, cl_y + 30], fill=gold_shadow)
            draw.ellipse([cl_x - 24, cl_y - 24, cl_x + 24, cl_y + 24], fill=ruby_red, outline=gold_highlight, width=4)
            
            # Pearls around medallion
            for pa in np.linspace(0, 2*math.pi, 9)[:-1]:
                prx = cl_x + 36 * math.cos(pa)
                pry = cl_y + 36 * math.sin(pa)
                draw.ellipse([prx - 9, pry - 9, prx + 9, pry + 9], fill=pearl_cream, outline=gold_shadow)
            
            # Hanging pearl drops (latkan)
            for ox in [-20, 0, 20]:
                dx = cl_x + ox
                dy = cl_y + 45 + abs(ox)//2
                draw.ellipse([dx - 7, dy - 7, dx + 7, dy + 7], fill=gold_base)
                draw.ellipse([dx - 8, dy + 12, dx + 8, dy + 28], fill=pearl_cream)

            # Elegant side chain leading up and right
            if props.get('chain'):
                chain_pts = []
                for t in np.linspace(0, 1, 35):
                    # Bezier curve
                    px = (1-t)**2 * (cx - 20 + nr) + 2*(1-t)*t * (cx + 120) + t**2 * (size - 20)
                    py = (1-t)**2 * cy + 2*(1-t)*t * (cy - 90) + t**2 * 40
                    chain_pts.append((px, py))
                    # Little gold beads
                    draw.ellipse([px - 4, py - 4, px + 4, py + 4], fill=gold_highlight, outline=gold_shadow)
                for i in range(len(chain_pts)-1):
                    draw.line([chain_pts[i], chain_pts[i+1]], fill=gold_base, width=2)

        # Smooth and save
        img = img.filter(ImageFilter.SMOOTH_MORE)
        img.save(out_path, 'PNG')
        print(f"Generated {fname}: {name}")

generate_nose_rings()
