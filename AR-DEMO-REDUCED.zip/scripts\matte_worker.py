import sys
import os
import json
import hashlib
from PIL import Image
import numpy as np
import rembg

session = None

def get_session():
    global session
    if session is None:
        session = rembg.new_session("isnet-general-use")
    return session

def process_one(input_path, output_path, min_gold_ratio=0.15):
    try:
        with Image.open(input_path) as raw_img:
            img = raw_img.convert("RGB")
        
        arr = np.array(img)
        hsv = img.convert("HSV")
        h, s, v = np.array(hsv).transpose(2, 0, 1)

        # Exclude white/grey background and extreme dark
        non_bg = ~((arr[..., 0] > 230) & (arr[..., 1] > 230) & (arr[..., 2] > 230)) & (v > 30)
        total_valid = np.sum(non_bg)
        if total_valid < 100:
            return {"success": False, "reason": "mostly empty or plain background"}
        
        # Gold/yellow hue mask in HSV (H: 12-46, S: 35-255, V: 45-255)
        gold_mask = non_bg & (h >= 12) & (h <= 46) & (s >= 35) & (v >= 45)
        gold_ratio = float(np.sum(gold_mask) / max(1, total_valid))

        if gold_ratio < min_gold_ratio:
            return {"success": False, "reason": f"low initial gold ratio: {gold_ratio:.3f}"}

        # Run high-detail neural matting
        sess = get_session()
        matted = rembg.remove(img, session=sess)

        # Find tight bounding box of alpha
        bbox = matted.getbbox()
        if not bbox:
            return {"success": False, "reason": "empty alpha mask after matting"}
        
        cropped = matted.crop(bbox)
        
        # Create canvas with guaranteed 16px transparent margin on all sides
        margin = 16
        padded = Image.new("RGBA", (cropped.width + margin * 2, cropped.height + margin * 2), (0, 0, 0, 0))
        padded.paste(cropped, (margin, margin))

        # Max dimension 900px for web performance
        max_d = max(padded.size)
        if max_d > 900:
            scale = 900 / max_d
            new_size = (int(padded.size[0] * scale), int(padded.size[1] * scale))
            padded = padded.resize(new_size, Image.Resampling.LANCZOS)

        # ── Strict Quality Validation Rules ──
        arr_p = np.array(padded)
        alpha = arr_p[..., 3]
        rgb = arr_p[..., :3]
        w, h_dim = padded.size

        # 1. Corner pixels alpha near-transparent (rembg leaves slight bleed 1-15)
        corners = [alpha[0, 0], alpha[0, -1], alpha[-1, 0], alpha[-1, -1]]
        if not all(c <= 15 for c in corners):
            return {"success": False, "reason": f"corners not transparent: {corners}"}

        # 2. Opaque coverage between 5% and 75%
        opaque = alpha > 20
        total_opaque = int(np.sum(opaque))
        if total_opaque < 200:
            return {"success": False, "reason": "foreground too small"}

        coverage = float(total_opaque / (w * h_dim))
        if not (0.05 <= coverage <= 0.75):
            return {"success": False, "reason": f"coverage {coverage:.2f} out of [0.05, 0.75]"}

        # 3. Mean luminance of opaque pixels > 55 (reject near-black mannequins and velvet busts)
        lum = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
        mean_lum = float(np.mean(lum[opaque]))
        if mean_lum <= 55.0:
            return {"success": False, "reason": f"mean luminance {mean_lum:.1f} <= 55 (dark bust/mannequin)"}

        # 4. Mannequin / neck bust / person rejection:
        # Check for dark velvet/cloth blob (V < 55)
        hsv_p = padded.convert("HSV")
        h_p, s_p, v_p = np.array(hsv_p).transpose(2, 0, 1)
        dark_ratio = float(np.sum(opaque & (v_p < 55)) / total_opaque)
        if dark_ratio > 0.30:
            return {"success": False, "reason": f"dark bust/stand detected: dark_ratio={dark_ratio:.2f}"}

        # Low saturation non-gold blob (cloth stand, mannequin neck, grey velvet)
        low_sat_ratio = float(np.sum(opaque & (s_p < 30) & (v_p < 110)) / total_opaque)
        if low_sat_ratio > 0.35:
            return {"success": False, "reason": f"mannequin/velvet stand: low_sat_ratio={low_sat_ratio:.2f}"}

        # Foreground gold ratio check on final matted piece
        final_gold = opaque & (h_p >= 10) & (h_p <= 50) & (s_p >= 30) & (v_p >= 40)
        final_gold_ratio = float(np.sum(final_gold) / total_opaque)
        if final_gold_ratio < 0.12:
            return {"success": False, "reason": f"low final gold ratio on foreground: {final_gold_ratio:.2f}"}

        # Save validated transparent PNG
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        padded.save(output_path, format="PNG", optimize=True)

        with open(output_path, "rb") as f:
            data = f.read()
            hsh = hashlib.sha256(data).hexdigest()

        return {
            "success": True,
            "hash": hsh,
            "width": padded.size[0],
            "height": padded.size[1],
            "coverage": round(coverage, 3),
            "meanLuminance": round(mean_lum, 1),
            "goldRatio": round(final_gold_ratio, 3)
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

if __name__ == "__main__":
    if len(sys.argv) >= 3:
        inp = sys.argv[1]
        outp = sys.argv[2]
        res = process_one(inp, outp)
        print(json.dumps(res))
    else:
        # Batch mode via stdin lines
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            req = json.loads(line)
            res = process_one(req["inputPath"], req["outputPath"], req.get("minGoldRatio", 0.15))
            print(json.dumps(res), flush=True)
