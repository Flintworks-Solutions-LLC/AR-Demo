import * as THREE from 'three';
import { JewelConfig } from './types';
import { createJewelMaterials, createBrilliantGemGeometry } from './materials';

/**
 * Builds a single earring originating at the top pivot (0, 0, 0) and hanging downwards along -Y.
 * Scale: 1 unit = 1 cm (earring length ~2.0 - 5.5 cm).
 */
export function buildSingleEarring(config: JewelConfig): THREE.Group {
  const group = new THREE.Group();
  group.name = `earring_unit_${config.id}`;

  const { metalMat, diamondMat, rubyMat, emeraldMat, sapphireMat, pearlMat } =
    createJewelMaterials(config.metalTone);

  // Top lobe post / stud anchor at (0, 0, 0)
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.35, 8), metalMat);
  post.position.set(0, 0, -0.15);
  post.rotation.x = Math.PI / 2;
  group.add(post);

  switch (config.style) {
    case 'round_studs': {
      // 4-prong brilliant solitaire stud
      const gem = new THREE.Mesh(createBrilliantGemGeometry(0.38), diamondMat);
      gem.position.set(0, 0, 0.08);
      group.add(gem);

      const collet = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.22, 0.18, 16), metalMat);
      collet.position.set(0, 0, 0);
      collet.rotation.x = Math.PI / 2;
      group.add(collet);

      for (let i = 0; i < 4; i++) {
        const a = (i * Math.PI) / 2 + Math.PI / 4;
        const prong = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.25, 6), metalMat);
        prong.position.set(Math.cos(a) * 0.28, Math.sin(a) * 0.28, 0.06);
        group.add(prong);
      }
      break;
    }

    case 'jhumka': {
      // Top stud disc
      const topDisc = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.1, 16), metalMat);
      topDisc.rotation.x = Math.PI / 2;
      group.add(topDisc);

      const rubyTop = new THREE.Mesh(createBrilliantGemGeometry(0.18), rubyMat);
      rubyTop.position.set(0, 0, 0.06);
      group.add(rubyTop);

      // Connecting jump ring
      const jumpRing = new THREE.Mesh(new THREE.TorusGeometry(0.14, 0.03, 8, 16), metalMat);
      jumpRing.position.set(0, -0.32, 0);
      group.add(jumpRing);

      // Jhumka bell dome using LatheGeometry
      const domePoints: THREE.Vector2[] = [];
      for (let i = 0; i <= 10; i++) {
        const t = i / 10;
        const x = Math.sin(t * Math.PI * 0.5) * 0.65;
        const y = -Math.cos(t * Math.PI * 0.5) * 0.55;
        domePoints.push(new THREE.Vector2(x, y));
      }
      const domeGeom = new THREE.LatheGeometry(domePoints, 24);
      const dome = new THREE.Mesh(domeGeom, metalMat);
      dome.position.set(0, -0.65, 0);
      group.add(dome);

      // Hanging bead fringe at bottom rim of dome
      const beadCount = 12;
      const rimRadius = 0.65;
      for (let i = 0; i < beadCount; i++) {
        const a = (i * Math.PI * 2) / beadCount;
        const bead = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 8), pearlMat);
        bead.position.set(
          Math.cos(a) * rimRadius,
          -1.25,
          Math.sin(a) * rimRadius
        );
        group.add(bead);

        const wire = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.16, 6), metalMat);
        wire.position.set(
          Math.cos(a) * rimRadius,
          -1.15,
          Math.sin(a) * rimRadius
        );
        group.add(wire);
      }
      break;
    }

    case 'halo_drops': {
      // Top diamond huggie
      const topGem = new THREE.Mesh(createBrilliantGemGeometry(0.22), diamondMat);
      topGem.position.set(0, 0, 0.05);
      group.add(topGem);

      // Articulated drop link
      const link = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.6, 8), metalMat);
      link.position.set(0, -0.45, 0);
      group.add(link);

      // Oval sapphire drop in diamond halo
      const dropSapphire = new THREE.Mesh(createBrilliantGemGeometry(0.38), sapphireMat);
      dropSapphire.position.set(0, -1.05, 0);
      group.add(dropSapphire);

      const halo = new THREE.Mesh(new THREE.TorusGeometry(0.48, 0.06, 12, 24), metalMat);
      halo.position.set(0, -1.05, 0);
      group.add(halo);

      for (let i = 0; i < 12; i++) {
        const a = (i * Math.PI * 2) / 12;
        const micro = new THREE.Mesh(new THREE.SphereGeometry(0.055, 6, 6), diamondMat);
        micro.position.set(Math.cos(a) * 0.48, -1.05 + Math.sin(a) * 0.48, 0.02);
        group.add(micro);
      }
      break;
    }

    case 'chandelier': {
      // 3-tier filigree cascade
      const topCluster = new THREE.Mesh(createBrilliantGemGeometry(0.25), diamondMat);
      group.add(topCluster);

      // Tier 1 bar
      const bar1 = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.06, 0.06), metalMat);
      bar1.position.set(0, -0.45, 0);
      group.add(bar1);

      // Tier 2 bar
      const bar2 = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.06, 0.06), metalMat);
      bar2.position.set(0, -0.95, 0);
      group.add(bar2);

      // Hanging ruby drops
      const dropPositions = [-0.5, -0.25, 0, 0.25, 0.5];
      dropPositions.forEach((x, idx) => {
        const ruby = new THREE.Mesh(createBrilliantGemGeometry(0.16), rubyMat);
        ruby.position.set(x, -1.45 - (idx % 2 === 0 ? 0.2 : 0), 0);
        group.add(ruby);

        const chain = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.4, 6), metalMat);
        chain.position.set(x, -1.15, 0);
        group.add(chain);
      });
      break;
    }

    case 'hoops': {
      // Inside-out diamond hoops (diameter ~2.8 cm)
      const hoopRadius = 1.4;
      const hoop = new THREE.Mesh(
        new THREE.TorusGeometry(hoopRadius, 0.10, 16, 48, Math.PI * 1.8),
        metalMat
      );
      hoop.position.set(0, -hoopRadius, 0);
      group.add(hoop);

      // Diamonds lining front outer curve
      for (let i = 0; i < 18; i++) {
        const a = -Math.PI * 0.4 + (i / 17) * Math.PI * 1.6;
        const gem = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), diamondMat);
        gem.position.set(Math.cos(a) * (hoopRadius + 0.08), -hoopRadius + Math.sin(a) * (hoopRadius + 0.08), 0);
        group.add(gem);
      }
      break;
    }

    case 'pearl_drop': {
      // Diamond petal cap with glowing South-sea pearl drop
      const topStone = new THREE.Mesh(createBrilliantGemGeometry(0.25), diamondMat);
      group.add(topStone);

      const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.42, 0.25, 16), metalMat);
      cap.position.set(0, -0.55, 0);
      group.add(cap);

      const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.44, 24, 24), pearlMat);
      pearl.position.set(0, -1.05, 0);
      group.add(pearl);
      break;
    }

    case 'temple': {
      // Antique Lakshmi coin with hanging ruby drops
      const coin = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.08, 20), metalMat);
      coin.position.set(0, -0.45, 0);
      coin.rotation.x = Math.PI / 2;
      group.add(coin);

      const centerRuby = new THREE.Mesh(createBrilliantGemGeometry(0.16), rubyMat);
      centerRuby.position.set(0, -0.45, 0.06);
      group.add(centerRuby);

      // 3 ruby drop bells
      [-0.32, 0, 0.32].forEach((x) => {
        const bell = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.22, 12), metalMat);
        bell.position.set(x, -1.15, 0);
        group.add(bell);

        const bead = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), pearlMat);
        bead.position.set(x, -1.35, 0);
        group.add(bead);
      });
      break;
    }

    case 'kundan': {
      // Uncut Polki diamond stud with green enamel meenakari teardrop
      const polki = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.32, 0.12, 8), diamondMat);
      polki.position.set(0, -0.1, 0.05);
      group.add(polki);

      const goldFoil = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.38, 0.14, 8), metalMat);
      goldFoil.position.set(0, -0.1, 0);
      group.add(goldFoil);

      // Teardrop emerald drop
      const dropGeom = new THREE.ConeGeometry(0.32, 0.8, 12);
      dropGeom.rotateZ(Math.PI);
      const drop = new THREE.Mesh(dropGeom, emeraldMat);
      drop.position.set(0, -0.95, 0);
      group.add(drop);
      break;
    }

    case 'leaf': {
      // Curved willow leaf climber encrusted with pave emeralds
      const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.02, 1.8, 12), metalMat);
      stem.position.set(0, -0.85, 0);
      stem.rotation.z = 0.2;
      group.add(stem);

      for (let i = 0; i < 6; i++) {
        const y = -0.2 - i * 0.26;
        const side = i % 2 === 0 ? 1 : -1;
        const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.12, 0.06), emeraldMat);
        leaf.position.set(side * 0.2, y, 0.04);
        leaf.rotation.z = side * 0.45;
        group.add(leaf);
      }
      break;
    }

    case 'floral_cluster':
    default: {
      // 7-stone diamond daisy stud
      const center = new THREE.Mesh(createBrilliantGemGeometry(0.24), diamondMat);
      group.add(center);

      for (let i = 0; i < 6; i++) {
        const a = (i * Math.PI * 2) / 6;
        const petal = new THREE.Mesh(createBrilliantGemGeometry(0.18), diamondMat);
        petal.position.set(Math.cos(a) * 0.32, Math.sin(a) * 0.32, 0);
        group.add(petal);

        const prong = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.14, 6), metalMat);
        prong.position.set(Math.cos(a) * 0.32, Math.sin(a) * 0.32, -0.04);
        group.add(prong);
      }
      break;
    }
  }

  return group;
}

/**
 * Builds a mirrored pair of earrings for 360 viewer display.
 */
export function buildEarringPair(config: JewelConfig): THREE.Group {
  const pairGroup = new THREE.Group();
  pairGroup.name = `earring_pair_${config.id}`;

  const leftEarring = buildSingleEarring(config);
  leftEarring.position.x = -1.2;
  pairGroup.add(leftEarring);

  const rightEarring = buildSingleEarring(config);
  rightEarring.position.x = 1.2;
  rightEarring.scale.x = -1; // Mirrored
  pairGroup.add(rightEarring);

  return pairGroup;
}
