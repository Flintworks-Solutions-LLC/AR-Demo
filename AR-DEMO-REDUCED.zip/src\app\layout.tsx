import type { Metadata } from "next";
import { Playfair_Display, Inter } from "next/font/google";
import "./globals.css";

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "AURA LUXE | Haute Joaillerie AR Try-On",
  description: "Experience fine jewellery in real-time augmented reality with studio precision.",
};

import { JewelleryStoreProvider } from "@/context/JewelleryStoreContext";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body
        className={`${inter.variable} ${playfair.variable} font-sans bg-[#080808] text-neutral-100 antialiased selection:bg-[#D4AF37]/30 selection:text-[#F5E1A4]`}
      >
        <JewelleryStoreProvider>
          {children}
        </JewelleryStoreProvider>
      </body>
    </html>
  );
}
