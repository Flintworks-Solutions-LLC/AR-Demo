import { NextRequest, NextResponse } from "next/server";

export const maxDuration = 30;

/**
 * Optional small vision LLM fallback route for ambiguous jewellery asset prep.
 * If ANTHROPIC_API_KEY or GEMINI_API_KEY is present in env, queries Claude 3.5 Haiku or Gemini.
 * If no key is set or the call fails, returns { fallback: true } so client heuristics take over.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null);
    if (!body || !body.image) {
      return NextResponse.json({ fallback: true, reason: "No image payload" }, { status: 400 });
    }

    const anthropicKey = process.env.ANTHROPIC_API_KEY;
    const geminiKey = process.env.GEMINI_API_KEY;

    // If no key configured, fall back immediately with zero delay
    if (!anthropicKey && !geminiKey) {
      return NextResponse.json({ fallback: true, reason: "No vision API key configured" });
    }

    const base64Data = body.image.includes(",") ? body.image.split(",")[1] : body.image;
    const mimeType = body.image.includes("data:image/png") ? "image/png" : "image/jpeg";

    if (anthropicKey) {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": anthropicKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-3-5-haiku-latest",
          max_tokens: 300,
          temperature: 0,
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "image",
                  source: {
                    type: "base64",
                    media_type: mimeType,
                    data: base64Data,
                  },
                },
                {
                  type: "text",
                  text: `Analyze this jewellery cutout photo for an AR try-on system. Output strict JSON only with no markdown or explanation:
{
  "category": "necklace|earrings|finger_ring|bangles|nose_ring",
  "view": "front|top-down|side",
  "rotation_degrees_to_upright": 0,
  "front_bbox": [0, 0, 1, 1],
  "clasp_side": "top|bottom|none",
  "anchor": [0.5, 0.5]
}`,
                },
              ],
            },
          ],
        }),
      });

      if (!response.ok) {
        return NextResponse.json({ fallback: true, reason: "Anthropic request failed" });
      }

      const resData = await response.json();
      const rawText = resData?.content?.[0]?.text || "";
      const cleanedJson = rawText.replace(/```json/g, "").replace(/```/g, "").trim();
      const parsed = JSON.parse(cleanedJson);

      // Validate & clamp
      return NextResponse.json({
        fallback: false,
        category: typeof parsed.category === "string" ? parsed.category : undefined,
        view: ["front", "top-down", "side"].includes(parsed.view) ? parsed.view : "front",
        rotation_degrees_to_upright:
          typeof parsed.rotation_degrees_to_upright === "number"
            ? Math.max(-180, Math.min(180, parsed.rotation_degrees_to_upright))
            : 0,
        front_bbox: Array.isArray(parsed.front_bbox) ? parsed.front_bbox : [0, 0, 1, 1],
        clasp_side: parsed.clasp_side || "none",
        anchor: Array.isArray(parsed.anchor) ? parsed.anchor : [0.5, 0.5],
      });
    }

    return NextResponse.json({ fallback: true, reason: "Fallback heuristic preferred" });
  } catch (err: unknown) {
    console.warn("[VisionAssetPrep API] Falling back to heuristics:", (err as Error).message);
    return NextResponse.json({ fallback: true, error: (err as Error).message });
  }
}

