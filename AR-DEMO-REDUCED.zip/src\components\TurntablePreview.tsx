"use client";

import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { useJewelleryStore, MetalType } from "@/context/JewelleryStoreContext";
import {
  buildJewel,
  getJewelConfigById,
  JewelConfig,
  updateGroupMetal,
} from "@/jewels";
import { X, Play, Pause, Camera, AlertCircle } from "lucide-react";

interface TurntablePreviewProps {
  item: { id: string; name?: string; category?: string; [key: string]: unknown };
  onClose: () => void;
  onTryOn: () => void;
}

function createStudioShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext("2d")!;
  const grad = ctx.createRadialGradient(128, 128, 10, 128, 128, 120);
  grad.addColorStop(0, "rgba(0, 0, 0, 0.25)");
  grad.addColorStop(0.4, "rgba(0, 0, 0, 0.12)");
  grad.addColorStop(0.8, "rgba(0, 0, 0, 0.03)");
  grad.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);
  return new THREE.CanvasTexture(canvas);
}

/**
 * Detect if an item is a user-uploaded single-photo item (2d type with cutout src).
 */
function isSinglePhotoUpload(item: Record<string, unknown>): boolean {
  return (
    (item.type === "2d" || item.type === undefined) &&
    typeof item.src === "string" &&
    (item.src as string).startsWith("data:") &&
    !item.modelUrl &&
    typeof item.id === "string" &&
    (item.id as string).startsWith("upload_")
  );
}

/**
 * Creates an authentic, realistic fine jewellery backside texture:
 * - Matches the exact silhouette & transparency of the piece
 * - Renders a luxurious solid precious metal finish (18K/22K yellow gold, white gold/silver, or rose gold)
 * - Renders an authentic engraved fine jewellery hallmark ("AURA · 750" or "AURA · 916")
 * - Features ajouré under-gallery openings and setting collet windows so light passes through
 */
export function createRealisticJewelleryBacksideTexture(
  img: HTMLImageElement | HTMLCanvasElement,
  metalTone: MetalType = "gold"
): THREE.CanvasTexture {
  const bw = (img as HTMLImageElement).naturalWidth || img.width || 512;
  const bh = (img as HTMLImageElement).naturalHeight || img.height || 512;
  const canvas = document.createElement("canvas");
  canvas.width = bw;
  canvas.height = bh;
  const ctx = canvas.getContext("2d")!;

  // 1. Draw mirrored image to capture exact silhouette
  ctx.save();
  ctx.translate(bw, 0);
  ctx.scale(-1, 1);
  ctx.drawImage(img, 0, 0);
  ctx.restore();

  // 2. Retain ONLY the transparent jewel silhouette
  ctx.globalCompositeOperation = "source-in";

  // 3. Luxurious brushed precious metal gradient
  const grad = ctx.createLinearGradient(0, 0, bw, bh);
  if (metalTone === "silver") {
    grad.addColorStop(0.0, "#ffffff");
    grad.addColorStop(0.2, "#e2e6eb");
    grad.addColorStop(0.4, "#f7f9fa");
    grad.addColorStop(0.65, "#c9cfd7");
    grad.addColorStop(0.85, "#eef1f4");
    grad.addColorStop(1.0, "#b8c0cc");
  } else if (metalTone === "rose_gold") {
    grad.addColorStop(0.0, "#fbece8");
    grad.addColorStop(0.2, "#e5a79a");
    grad.addColorStop(0.4, "#fad7cf");
    grad.addColorStop(0.65, "#cf8172");
    grad.addColorStop(0.85, "#f3c2b8");
    grad.addColorStop(1.0, "#b96a5c");
  } else {
    // Rich 18K/22K Gold
    grad.addColorStop(0.0, "#fff0a8");
    grad.addColorStop(0.2, "#e2b83b");
    grad.addColorStop(0.4, "#fae489");
    grad.addColorStop(0.65, "#c5961e");
    grad.addColorStop(0.85, "#f5dc72");
    grad.addColorStop(1.0, "#a87a12");
  }
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, bw, bh);

  // 4. Fine brushed satin hairline texture
  ctx.globalCompositeOperation = "source-atop";
  ctx.strokeStyle = metalTone === "silver" ? "rgba(180, 190, 200, 0.12)" : "rgba(140, 100, 20, 0.14)";
  ctx.lineWidth = 1;
  const step = Math.max(3, Math.round(bh / 160));
  for (let y = 0; y < bh; y += step) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(bw, y + 2);
    ctx.stroke();
  }

  // 5. Authentic fine jewellery hallmark cartouche engraved on the backplate
  const stampW = Math.min(bw * 0.22, 110);
  const stampH = stampW * 0.42;
  const stampX = (bw - stampW) / 2;
  const stampY = bh * 0.52;

  // Recessed hallmark cartouche
  ctx.fillStyle = metalTone === "silver" ? "rgba(80, 90, 100, 0.35)" : "rgba(85, 60, 12, 0.40)";
  ctx.beginPath();
  ctx.roundRect(stampX, stampY, stampW, stampH, stampH * 0.3);
  ctx.fill();

  ctx.strokeStyle = metalTone === "silver" ? "rgba(255, 255, 255, 0.45)" : "rgba(255, 240, 180, 0.50)";
  ctx.lineWidth = 1;
  ctx.stroke();

  // Hallmark text (e.g. AURA 750 / 18K seal)
  ctx.fillStyle = metalTone === "silver" ? "#2a313a" : "#4a3508";
  ctx.font = `bold ${Math.round(stampH * 0.42)}px sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const purityText = metalTone === "silver" ? "AURA · 925" : "AURA · 750";
  ctx.fillText(purityText, bw / 2, stampY + stampH * 0.52);

  // 6. Delicate under-gallery collet openings (ajouré pierced holes behind gem settings)
  ctx.fillStyle = metalTone === "silver" ? "rgba(60, 70, 80, 0.28)" : "rgba(70, 50, 10, 0.32)";
  const colletRadius = Math.max(4, Math.round(bw * 0.022));
  const colletY1 = bh * 0.38;
  const colletY2 = bh * 0.68;
  for (let dx = -0.22; dx <= 0.22; dx += 0.11) {
    ctx.beginPath();
    ctx.arc(bw / 2 + dx * bw, colletY1, colletRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(bw / 2 + dx * bw * 0.8, colletY2, colletRadius * 0.85, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

/**
 * Build an extruded 3D shape from a cutout image's alpha silhouette.
 * - Front: photo texture
 * - Back: authentic real gold backplate with hallmark & under-gallery
 * - Edges: polished gold metal
 * - Depth: ~3% of width
 * - No gold box/slab, no grey floor
 */
async function buildExtrudedCutout(
  imageUrl: string,
  metalTone: MetalType,
): Promise<THREE.Group> {
  const group = new THREE.Group();

  // Load the texture
  const texture = await new Promise<THREE.Texture>((resolve, reject) => {
    new THREE.TextureLoader().load(
      imageUrl,
      (t) => {
        t.colorSpace = THREE.SRGBColorSpace;
        t.minFilter = THREE.LinearMipmapLinearFilter;
        t.magFilter = THREE.LinearFilter;
        resolve(t);
      },
      undefined,
      reject,
    );
  });

  const img = texture.image as HTMLImageElement;
  const imgWidth = img?.width || 512;
  const imgHeight = img?.height || 512;
  const aspect = imgWidth / imgHeight;

  // Normalize to ~7 units on the long side
  const baseSize = 7.0;
  const planeW = aspect >= 1 ? baseSize : baseSize * aspect;
  const planeH = aspect >= 1 ? baseSize / aspect : baseSize;
  const depth = planeW * 0.03; // 3% of width

  // Create geometry for front/back planes
  const planeGeo = new THREE.PlaneGeometry(planeW, planeH);

  // ── Front face: photo texture ──
  const frontMat = new THREE.MeshStandardMaterial({
    map: texture,
    transparent: true,
    alphaTest: 0.05,
    roughness: 0.22,
    metalness: 0.88,
    side: THREE.FrontSide,
    envMapIntensity: 1.2,
  });
  const frontMesh = new THREE.Mesh(planeGeo, frontMat);
  frontMesh.position.z = depth / 2;
  group.add(frontMesh);

  // ── Back face: Authentic Real Gold Backplate & Hallmark ──
  const backTexture = createRealisticJewelleryBacksideTexture(img, metalTone);
  const backMat = new THREE.MeshStandardMaterial({
    map: backTexture,
    transparent: true,
    alphaTest: 0.05,
    roughness: metalTone === "silver" ? 0.24 : 0.20,
    metalness: 0.95,
    side: THREE.FrontSide,
    envMapIntensity: 1.4,
  });
  const backMesh = new THREE.Mesh(planeGeo, backMat);
  backMesh.position.z = -depth / 2;
  backMesh.rotation.y = Math.PI; // face backwards
  group.add(backMesh);

  return group;
}

export function TurntablePreview({ item, onClose, onTryOn }: TurntablePreviewProps) {
  const { metal, setMetal } = useJewelleryStore();
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const controlsRef = useRef<OrbitControls | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const activeMetalRef = useRef<MetalType>(metal);

  const [playing, setPlaying] = useState(true);
  const [rotationAngle, setRotationAngle] = useState(0);
  const [modelLoading, setModelLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  activeMetalRef.current = metal;

  const isSingleUpload = isSinglePhotoUpload(item as Record<string, unknown>);

  // Auto-switch metal if item specifies silver or rose gold
  useEffect(() => {
    const itemName = item.name?.toLowerCase() || "";
    const itemMetal = item.metal;
    if (itemMetal === "silver" || itemName.includes("silver")) {
      setMetal("silver");
    } else if (itemMetal === "rose_gold" || itemName.includes("rose")) {
      setMetal("rose_gold");
    }
  }, [item, setMetal]);

  // Live metal switching
  useEffect(() => {
    if (!modelGroupRef.current) return;
    updateGroupMetal(modelGroupRef.current, metal);
  }, [metal]);

  // Play / Pause autoRotate
  useEffect(() => {
    if (controlsRef.current) {
      controlsRef.current.autoRotate = playing;
    }
  }, [playing]);

  // Main Three.js Scene Setup & Model Loading
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    let isDisposed = false;
    setModelLoading(true);
    setErrorMessage(null);

    const width = container.clientWidth || 560;
    const height = container.clientHeight || 340;

    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // PMREM Environment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();
    const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTexture;

    // Studio Lights
    const keyLight = new THREE.DirectionalLight(0xfff5e6, 3.2);
    keyLight.position.set(4, 7, 5);
    keyLight.castShadow = true;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xddeeff, 1.6);
    fillLight.position.set(-4, 3, 3);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 2.8);
    rimLight.position.set(0, -3, -5);
    scene.add(rimLight);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const isSet = item.category === "sets";
    const hasPhotoSrc = typeof item.src === "string" && (item.src as string).length > 0 && !item.modelUrl;
    const isPhotoItem = isSingleUpload || hasPhotoSrc;

    // For photo items and single-photo uploads: dark background, no floor
    // For everything else: keep existing floor/shadow behavior
    let floor: THREE.Mesh | null = null;
    let floorGeo: THREE.PlaneGeometry | null = null;
    let floorMat: THREE.MeshStandardMaterial | null = null;

    if (!isSet && !isPhotoItem) {
      floorGeo = new THREE.PlaneGeometry(30, 30);
      floorMat = new THREE.MeshStandardMaterial({
        color: 0x07080b,
        metalness: 0.92,
        roughness: 0.28,
      });
      floor = new THREE.Mesh(floorGeo, floorMat);
      floor.rotation.x = -Math.PI / 2;
      floor.position.y = -2.8;
      floor.receiveShadow = true;
      scene.add(floor);
    }

    // Soft contact shadow disc
    const shadowTex = createStudioShadowTexture();
    const shadowGeo = new THREE.PlaneGeometry(6, 2.4);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      depthWrite: false,
      opacity: 1,
    });
    const shadowDisc = new THREE.Mesh(shadowGeo, shadowMat);
    shadowDisc.rotation.x = -Math.PI / 2;
    shadowDisc.position.y = -2.78;
    scene.add(shadowDisc);

    // Dark background for photo items
    if (isPhotoItem) {
      scene.background = new THREE.Color(0x0a0a0f);
    }

    // Camera
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 1.2, 5.5);

    // OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.autoRotate = playing;
    controls.autoRotateSpeed = 2.4;
    controls.minDistance = 1.8;
    controls.maxDistance = 18.0;
    controlsRef.current = controls;

    // Helper for cutout image turntable with thin metallic edge (no slab)
    const buildCutoutTurntable = (imageUrl: string) => {
      new THREE.TextureLoader().load(
        imageUrl,
        (tex) => {
          if (isDisposed) return;
          tex.colorSpace = THREE.SRGBColorSpace;

          const group = new THREE.Group();
          const w = 7.0;
          const h = 7.0;
          const geom = new THREE.PlaneGeometry(w, h);

          // Front
          const frontMat = new THREE.MeshStandardMaterial({
            map: tex,
            transparent: true,
            alphaTest: 0.05,
            roughness: 0.25,
            metalness: 0.85,
            side: THREE.FrontSide,
          });
          const frontMesh = new THREE.Mesh(geom, frontMat);
          frontMesh.position.z = 0.01;
          group.add(frontMesh);

          // Back: Authentic Real Gold Backside with Hallmark
          const backTex = createRealisticJewelleryBacksideTexture(tex.image as HTMLImageElement, activeMetalRef.current);
          const backMat = new THREE.MeshStandardMaterial({
            map: backTex,
            transparent: true,
            alphaTest: 0.05,
            roughness: activeMetalRef.current === "silver" ? 0.24 : 0.20,
            metalness: 0.95,
            side: THREE.BackSide,
            envMapIntensity: 1.4,
          });
          const backMesh = new THREE.Mesh(geom, backMat);
          backMesh.position.z = -0.01;
          backMesh.rotation.y = Math.PI;
          group.add(backMesh);

          // Thin metallic perimeter edge (pure thin line, NO solid slab)
          const edges = new THREE.EdgesGeometry(geom);
          const lineMat = new THREE.LineBasicMaterial({
            color: activeMetalRef.current === "silver" ? 0xcccccc : activeMetalRef.current === "rose_gold" ? 0xb76e79 : 0xd4af37,
            linewidth: 1,
          });
          const lineMesh = new THREE.LineSegments(edges, lineMat);
          group.add(lineMesh);

          scene.add(group);
          modelGroupRef.current = group;

          shadowDisc.scale.set(3.2, 3.2, 3.2);
          shadowDisc.position.y = -3.8;

          camera.position.set(0, 0.5, 9.5);
          camera.lookAt(0, 0, 0);
          controls.target.set(0, 0, 0);
          controls.update();

          setModelLoading(false);
        },
        undefined,
        (err) => {
          console.error("Failed to load turntable texture:", err);
          setErrorMessage("Failed to load preview texture.");
          setModelLoading(false);
        }
      );
    };

    // ── Real Gold Photo & Single-Photo: Extruded 3D silhouette ───
    if (isPhotoItem && typeof item.src === "string" && (item.src as string).length > 0 && !isSet) {
      buildExtrudedCutout(item.src as string, activeMetalRef.current)
        .then((model) => {
          if (isDisposed) return;

          // Center model
          const box = new THREE.Box3().setFromObject(model);
          const center = new THREE.Vector3();
          box.getCenter(center);
          model.position.sub(center);

          scene.add(model);
          modelGroupRef.current = model;

          // Camera: center on the piece, slightly above
          camera.position.set(0, 0.3, 9.0);
          camera.lookAt(0, 0, 0);
          controls.target.set(0, 0, 0);
          controls.update();

          setModelLoading(false);
        })
        .catch((err) => {
          console.error("Failed to build extruded cutout:", err);
          // Fallback to flat cutout turntable
          buildCutoutTurntable(item.src as string);
        });
    }
    // ── Build Sets 3D Scene (Exclusive to Sets category) ───────────
    else if (isSet) {
      const setPieces = (item as unknown as { setPieces?: { necklace?: { id: string }; earrings?: { id: string } } }).setPieces;
      const neckId = setPieces?.necklace?.id;
      const earId = setPieces?.earrings?.id;
      const neckConfig = neckId ? getJewelConfigById(neckId) : null;
      const earConfig = earId ? getJewelConfigById(earId) : null;

      if (neckConfig && earConfig) {
        // Both 3D models exist! Build matching necklace and earrings together
        Promise.all([
          buildJewel(neckConfig, activeMetalRef.current),
          buildJewel(earConfig, activeMetalRef.current),
        ])
          .then(([neckModel, earModel]) => {
            if (isDisposed) return;

            const setGroup = new THREE.Group();

            // Center necklace model
            const nBox = new THREE.Box3().setFromObject(neckModel);
            const nCenter = new THREE.Vector3();
            nBox.getCenter(nCenter);
            neckModel.position.sub(nCenter);
            neckModel.position.y -= 0.8;
            setGroup.add(neckModel);

            // Center earring model prototype
            const eBox = new THREE.Box3().setFromObject(earModel);
            const eCenter = new THREE.Vector3();
            eBox.getCenter(eCenter);
            earModel.position.sub(eCenter);

            // Left earring flanking necklace
            const leftEar = earModel.clone();
            leftEar.position.set(-3.6, 2.0, 0.4);
            setGroup.add(leftEar);

            // Right earring flanking necklace (symmetrical)
            const rightEar = earModel.clone();
            rightEar.position.set(3.6, 2.0, 0.4);
            rightEar.scale.x = -1;
            setGroup.add(rightEar);

            scene.add(setGroup);
            modelGroupRef.current = setGroup;

            // Soft shadow under set on dark background
            shadowDisc.scale.set(3.4, 3.4, 3.4);
            shadowDisc.position.y = -6.5;

            camera.position.set(0, 1.2, 12.5);
            camera.lookAt(0, 0, 0);
            controls.target.set(0, 0, 0);
            controls.update();

            setModelLoading(false);
          })
          .catch((err) => {
            console.error("Failed to build 3D set models, fallback to cutout turntable:", err);
            const fallbackUrl = (item.src as string) || (item.setNecklaceSrc as string) || "";
            if (fallbackUrl) {
              buildCutoutTurntable(fallbackUrl);
            } else {
              setErrorMessage("Set 3D models could not be loaded.");
              setModelLoading(false);
            }
          });
      } else {
        // Cutout fallback with thin metallic edge, no slab
        const fallbackUrl = (item.src as string) || (item.setNecklaceSrc as string) || "";
        if (fallbackUrl) {
          buildCutoutTurntable(fallbackUrl);
        } else {
          setErrorMessage("Set preview image not found.");
          setModelLoading(false);
        }
      }
    } else {
      // ── Standard Categories: Existing Flow Unchanged ─────────────
      let config = getJewelConfigById(item.id);
      if (!config) {
        // Check if custom uploaded item
        const customItem = item as unknown as {
          id: string;
          name: string;
          category: string;
          src?: string;
          modelUrl?: string;
          price?: string;
        };
        if (customItem.src || customItem.modelUrl) {
          config = {
            id: customItem.id,
            name: customItem.name || "Custom Jewel",
            category: (customItem.category as JewelConfig["category"]) || "necklace",
            style: "custom_relief",
            metalTone: activeMetalRef.current,
            gemType: "none",
            gemCount: 0,
            gemSize: 0,
            motif: "User bespoke upload",
            price: customItem.price || "Custom",
            materialsDescription: "Bespoke Cutout & Metal Relief",
            dimensions: { width: 4.0, height: 4.0, depth: 0.4 },
            wearAnchor: { x: 0.5, y: 0.5 },
            isCustom: true,
            cutoutUrl: customItem.src,
            modelUrl: customItem.modelUrl,
          };
        }
      }

      if (!config) {
        setErrorMessage(`Fatal Error: Jewel ID "${item.id}" has no registered 3D parametric model.`);
        setModelLoading(false);
        return;
      }

      buildJewel(config, activeMetalRef.current)
        .then((model) => {
          if (isDisposed) {
            model.traverse((c) => {
              if ((c as THREE.Mesh).isMesh) {
                const m = c as THREE.Mesh;
                m.geometry?.dispose();
              }
            });
            return;
          }

          // Frame model automatically via Box3
          const box = new THREE.Box3().setFromObject(model);
          const center = new THREE.Vector3();
          const size = new THREE.Vector3();
          box.getCenter(center);
          box.getSize(size);

          // Center model at origin
          model.position.sub(center);

          const jewelGroup = new THREE.Group();
          jewelGroup.add(model);
          scene.add(jewelGroup);
          modelGroupRef.current = jewelGroup;

          // Auto camera distance based on category and bounding size
          const maxDim = Math.max(size.x, size.y, size.z) || 1;
          const fov = camera.fov * (Math.PI / 180);
          let dist = Math.abs((maxDim / 2) / Math.tan(fov / 2)) * 1.5;

          if (config.category === "nose_ring") {
            dist = Math.max(dist, 1.8);
            shadowDisc.scale.set(0.3, 0.3, 0.3);
            if (floor) floor.position.y = -0.5;
            shadowDisc.position.y = -0.49;
          } else if (config.category === "finger_ring") {
            dist = Math.max(dist, 3.2);
            shadowDisc.scale.set(0.7, 0.7, 0.7);
            if (floor) floor.position.y = -1.2;
            shadowDisc.position.y = -1.19;
          } else if (config.category === "necklace") {
            dist = Math.max(dist, 10.0);
            shadowDisc.scale.set(2.4, 2.4, 2.4);
            if (floor) floor.position.y = -7.0;
            shadowDisc.position.y = -6.98;
          } else if (config.category === "bangles") {
            dist = Math.max(dist, 6.2);
            shadowDisc.scale.set(1.4, 1.4, 1.4);
            if (floor) floor.position.y = -2.8;
            shadowDisc.position.y = -2.78;
          } else if (config.category === "earrings") {
            dist = Math.max(dist, 4.2);
            shadowDisc.scale.set(0.9, 0.9, 0.9);
            if (floor) floor.position.y = -2.2;
            shadowDisc.position.y = -2.18;
          }

          camera.position.set(0, 0.8, dist);
          camera.lookAt(0, 0, 0);
          controls.target.set(0, 0, 0);
          controls.update();

          setModelLoading(false);
        })
        .catch((err) => {
          console.error("Failed to build 3D jewel:", err);
          setErrorMessage(`Model Build Error: ${err.message}`);
          setModelLoading(false);
        });
    }

    // Render loop
    const animate = () => {
      rafRef.current = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      isDisposed = true;
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(rafRef.current);

      if (modelGroupRef.current) {
        modelGroupRef.current.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) {
            const mesh = child as THREE.Mesh;
            mesh.geometry?.dispose();
            if (Array.isArray(mesh.material)) {
              mesh.material.forEach((m) => m.dispose());
            } else {
              mesh.material?.dispose();
            }
          }
        });
        scene.remove(modelGroupRef.current);
        modelGroupRef.current = null;
      }

      envTexture.dispose();
      pmremGenerator.dispose();
      shadowTex.dispose();
      if (floorGeo) floorGeo.dispose();
      if (floorMat) floorMat.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      renderer.dispose();
    };
  }, [item, isSingleUpload, playing]);

  // Angle slider manual rotation
  const handleAngleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const angleDeg = parseFloat(e.target.value);
    setRotationAngle(angleDeg);
    setPlaying(false);
    if (modelGroupRef.current) {
      modelGroupRef.current.rotation.y = (angleDeg * Math.PI) / 180;
    }
  };

  const jewelConfig = getJewelConfigById(item.id);
  const itemName = jewelConfig?.name || item.name || "Aura High Jewel";
  const materialsInfo = jewelConfig?.materialsDescription || (isSingleUpload ? "Custom Upload • Extruded 3D" : "22K Solid Gold");
  const priceInfo: string = jewelConfig?.price || (typeof item.price === "string" ? item.price : isSingleUpload ? "Bespoke" : "$3,800");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl max-h-[94vh] overflow-y-auto overflow-x-hidden bg-gradient-to-b from-[#13151b] to-[#0a0b0e] border border-amber-500/30 rounded-2xl shadow-2xl flex flex-col my-auto" style={{ scrollbarWidth: "thin" }}>
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-3.5 border-b border-white/10 bg-[#13151b]/95 backdrop-blur-md">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase tracking-widest text-amber-400 font-semibold px-2 py-0.5 rounded-full bg-amber-400/10 border border-amber-400/20">
                {item.category === "sets" ? "3D Set Showcase" : isSingleUpload ? "Extruded 3D Preview" : "360° Studio Inspection"}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-serif text-white tracking-wide mt-1">{itemName}</h2>
            <p className="text-xs text-amber-200/70 font-sans">{materialsInfo} • <span className="text-white font-medium">{priceInfo}</span></p>
          </div>

          <button
            onClick={onClose}
            aria-label="Close Preview"
            className="p-2 rounded-full text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 3D Canvas Area: comfortably sized so all bottom buttons stay visible */}
        <div ref={containerRef} className="relative w-full h-[290px] sm:h-[350px] bg-gradient-to-b from-[#0c0d11] to-[#040507]">
          <canvas ref={canvasRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

          {/* Error display if no model */}
          {errorMessage && (
            <div className="absolute inset-0 flex items-center justify-center p-6 bg-black/90">
              <div className="text-center max-w-md p-5 rounded-xl border border-red-500/50 bg-red-950/40 text-red-200">
                <AlertCircle className="w-8 h-8 text-red-400 mx-auto mb-2" />
                <p className="text-sm font-mono">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Loading spinner */}
          {modelLoading && !errorMessage && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 pointer-events-none">
              <div className="w-10 h-10 border-2 border-amber-400/30 border-t-amber-400 rounded-full animate-spin mb-3" />
              <p className="text-xs uppercase tracking-widest text-amber-200/80 font-mono">
                {isSingleUpload ? "Building Extruded 3D Shape…" : item.category === "sets" ? "Composing 3D Set Scene…" : "Generating Faceted 3D Geometry…"}
              </p>
            </div>
          )}

          {/* Interaction hint */}
          <div className="absolute bottom-3 left-4 pointer-events-none text-[10px] tracking-wider text-zinc-400 font-mono bg-black/40 px-2 py-1 rounded backdrop-blur">
            DRAG TO ROTATE • PINCH TO ZOOM
          </div>
        </div>

        {/* Studio Controls Bar: Always visible, never cut off */}
        <div className="p-4 sm:p-5 border-t border-white/10 bg-black/60 flex flex-col gap-3.5 flex-shrink-0">
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Play / Pause & Angle Slider */}
            <div className="flex items-center gap-3">
              <button
                id="turntable-play-pause-btn"
                onClick={() => setPlaying(!playing)}
                className="p-2 rounded-lg bg-white/5 border border-white/10 hover:border-amber-400/40 text-zinc-300 hover:text-white transition-all flex items-center gap-1.5 text-xs font-mono"
              >
                {playing ? <Pause className="w-3.5 h-3.5 text-amber-400" /> : <Play className="w-3.5 h-3.5 text-amber-400" />}
                {playing ? "PAUSE" : "AUTO-SPIN"}
              </button>

              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase tracking-wider text-zinc-400 font-mono">Angle</span>
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={rotationAngle}
                  onChange={handleAngleChange}
                  className="w-24 sm:w-32 accent-amber-400 bg-zinc-800 rounded h-1 cursor-pointer"
                />
              </div>
            </div>

            {/* Live Metal Tone Switching */}
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-white/5 border border-white/10">
              <button
                id="turntable-metal-gold"
                onClick={() => setMetal("gold")}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                  metal === "gold"
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm"
                    : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                22K Gold
              </button>
              <button
                id="turntable-metal-silver"
                onClick={() => setMetal("silver")}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                  metal === "silver"
                    ? "bg-slate-300/20 text-slate-200 border border-slate-300/40 shadow-sm"
                    : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                Silver
              </button>
              <button
                id="turntable-metal-rosegold"
                onClick={() => setMetal("rose_gold")}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                  metal === "rose_gold"
                    ? "bg-rose-400/20 text-rose-300 border border-rose-400/40 shadow-sm"
                    : "text-zinc-400 hover:text-zinc-200"
                }`}
              >
                Rose Gold
              </button>
            </div>
          </div>

          {/* Action buttons — always visible */}
          <div className="flex items-center justify-end gap-3 pt-1">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-white/10 text-zinc-300 hover:text-white hover:bg-white/5 text-xs sm:text-sm font-medium transition-colors"
            >
              Back to Collection
            </button>
            <button
              id="turntable-tryon-live-btn"
              onClick={onTryOn}
              className="px-5 sm:px-6 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-semibold text-xs sm:text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 group cursor-pointer"
            >
              <Camera className="w-4 h-4 transition-transform group-hover:scale-110" />
              Try On Live in AR
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
