/**
 * Utility functions for validating and sorting photo-sequence uploads.
 */

export interface PhotoValidationResult {
  valid: boolean;
  error?: string;
  sortedFiles?: File[];
}

const VALID_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
const MAX_PHOTO_SIZE_BYTES = 5 * 1024 * 1024; // 5 MB per image
const MIN_PHOTOS = 24;
const MAX_PHOTOS = 36;

/**
 * Natural sort comparator for filenames (handles numeric segments correctly).
 * e.g. "img_2.jpg" < "img_10.jpg" (not lexicographic)
 */
export function naturalSortFilename(a: string, b: string): number {
  const re = /(\d+)/g;
  const aParts = a.split(re);
  const bParts = b.split(re);
  for (let i = 0; i < Math.max(aParts.length, bParts.length); i++) {
    const aPart = aParts[i] || "";
    const bPart = bParts[i] || "";
    const aNum = parseInt(aPart, 10);
    const bNum = parseInt(bPart, 10);
    if (!isNaN(aNum) && !isNaN(bNum)) {
      if (aNum !== bNum) return aNum - bNum;
    } else {
      if (aPart < bPart) return -1;
      if (aPart > bPart) return 1;
    }
  }
  return 0;
}

/**
 * Validates a photo sequence upload:
 * - Accepts only JPG, PNG, WebP
 * - Requires 24–36 images
 * - Max 5 MB each
 * - All images must have the same dimensions
 * Returns sorted files on success.
 */
export async function validatePhotoSequence(files: File[]): Promise<PhotoValidationResult> {
  if (files.length < MIN_PHOTOS) {
    return {
      valid: false,
      error: `Too few photos: you uploaded ${files.length}. A 360° sequence requires ${MIN_PHOTOS}–${MAX_PHOTOS} images (one every 10–15°).`,
    };
  }

  if (files.length > MAX_PHOTOS) {
    return {
      valid: false,
      error: `Too many photos: you uploaded ${files.length}. Maximum is ${MAX_PHOTOS} images. Please select exactly ${MIN_PHOTOS}–${MAX_PHOTOS} frames.`,
    };
  }

  // Type and size checks
  for (const file of files) {
    if (!VALID_IMAGE_TYPES.includes(file.type)) {
      return {
        valid: false,
        error: `"${file.name}" has an unsupported format (${file.type || "unknown"}). Only JPG, PNG, and WebP images are accepted.`,
      };
    }
    if (file.size > MAX_PHOTO_SIZE_BYTES) {
      const sizeMB = (file.size / 1024 / 1024).toFixed(1);
      return {
        valid: false,
        error: `"${file.name}" is too large (${sizeMB} MB). Maximum per image is 5 MB. Reduce the export quality or resolution.`,
      };
    }
  }

  // Natural-sort by filename
  const sorted = [...files].sort((a, b) => naturalSortFilename(a.name, b.name));

  // Dimension consistency check — sample first and last 3 files
  const samplesToCheck = [
    sorted[0],
    sorted[Math.floor(sorted.length / 2)],
    sorted[sorted.length - 1],
  ];

  const dimensions = await Promise.all(
    samplesToCheck.map(
      (f) =>
        new Promise<{ width: number; height: number }>((resolve, reject) => {
          const url = URL.createObjectURL(f);
          const img = new Image();
          img.onload = () => {
            URL.revokeObjectURL(url);
            resolve({ width: img.naturalWidth, height: img.naturalHeight });
          };
          img.onerror = () => {
            URL.revokeObjectURL(url);
            reject(new Error(`Could not load image: ${f.name}`));
          };
          img.src = url;
        })
    )
  );

  const refWidth = dimensions[0].width;
  const refHeight = dimensions[0].height;
  for (let i = 1; i < dimensions.length; i++) {
    if (dimensions[i].width !== refWidth || dimensions[i].height !== refHeight) {
      return {
        valid: false,
        error:
          `Images have mismatched dimensions. ` +
          `"${samplesToCheck[0].name}" is ${refWidth}×${refHeight}px but ` +
          `"${samplesToCheck[i].name}" is ${dimensions[i].width}×${dimensions[i].height}px. ` +
          `All photos must be the same resolution (same camera, same export settings).`,
      };
    }
  }

  return { valid: true, sortedFiles: sorted };
}

/**
 * Creates object URLs for all files in the sequence and preloads the images.
 * Calls onProgress(loadedCount, total) as each image loads.
 * Returns a cleanup function to revoke all URLs.
 */
export async function preloadPhotoSequence(
  files: File[],
  onProgress?: (loaded: number, total: number) => void
): Promise<{ urls: string[]; cleanup: () => void }> {
  const urls = files.map((f) => URL.createObjectURL(f));
  let loaded = 0;

  await Promise.all(
    urls.map(
      (url) =>
        new Promise<void>((resolve) => {
          const img = new Image();
          img.onload = () => {
            loaded++;
            onProgress?.(loaded, urls.length);
            resolve();
          };
          img.onerror = () => {
            loaded++;
            onProgress?.(loaded, urls.length);
            resolve(); // Don't reject on single failed frame
          };
          img.src = url;
        })
    )
  );

  const cleanup = () => urls.forEach((u) => URL.revokeObjectURL(u));
  return { urls, cleanup };
}
