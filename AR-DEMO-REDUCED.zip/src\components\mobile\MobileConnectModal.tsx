"use client";

import React, { useState, useEffect, useMemo } from "react";
import { generateQRCodeMatrix } from "@/lib/qrCode";

interface MobileConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function MobileConnectModal({ isOpen, onClose }: MobileConnectModalProps) {
  const [networkIp, setNetworkIp] = useState<string>("localhost");
  const [copied, setCopied] = useState<boolean>(false);
  const [protocol, setProtocol] = useState<string>("http:");
  const [port, setPort] = useState<string>("3000");

  useEffect(() => {
    if (typeof window !== "undefined") {
      setProtocol(window.location.protocol);
      setPort(window.location.port || (window.location.protocol === "https:" ? "443" : "80"));
    }

    fetch("/api/network-ip")
      .then((res) => res.json())
      .then((data) => {
        if (data?.ip) setNetworkIp(data.ip);
      })
      .catch((err) => {
        console.warn("[MobileConnect] Could not fetch network IP:", err);
      });
  }, []);

  const mobileUrl = useMemo(() => {
    const portStr = port && port !== "80" && port !== "443" ? `:${port}` : "";
    return `${protocol}//${networkIp}${portStr}`;
  }, [protocol, networkIp, port]);

  const qrMatrix = useMemo(() => {
    try {
      return generateQRCodeMatrix(mobileUrl);
    } catch (e) {
      console.warn("[MobileConnect] QR generation fallback:", e);
      return null;
    }
  }, [mobileUrl]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(mobileUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const isHttps = protocol === "https:";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md rounded-3xl bg-gradient-to-b from-neutral-900 via-neutral-950 to-black border border-[#D4AF37]/35 p-6 shadow-2xl text-white">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-neutral-400 hover:text-white transition cursor-pointer"
        >
          ✕
        </button>

        {/* Header */}
        <div className="text-center mb-5">
          <span className="text-[10px] uppercase font-bold tracking-[0.25em] text-[#D4AF37]">
            Seamless Cross-Device AR
          </span>
          <h2 className="text-xl font-serif font-bold text-white mt-1">
            Try on Mobile & Laptop
          </h2>
          <p className="text-xs text-neutral-400 mt-1 max-w-xs mx-auto">
            Scan to experience live AR virtual try-on directly using your smartphone camera.
          </p>
        </div>

        {/* QR Code Container */}
        <div className="flex flex-col items-center justify-center my-4">
          <div className="p-3 bg-white rounded-2xl shadow-xl shadow-[#D4AF37]/15 border border-[#D4AF37]/40">
            {qrMatrix ? (
              <svg
                width="180"
                height="180"
                viewBox={`0 0 ${qrMatrix.length} ${qrMatrix.length}`}
                className="w-44 h-44 rounded-lg"
              >
                {qrMatrix.map((row, r) =>
                  row.map((cell, c) =>
                    cell ? (
                      <rect
                        key={`${r}-${c}`}
                        x={c}
                        y={r}
                        width="1"
                        height="1"
                        fill="#0f0f11"
                      />
                    ) : null
                  )
                )}
              </svg>
            ) : (
              <div className="w-44 h-44 flex items-center justify-center bg-neutral-100 text-neutral-700 text-xs">
                QR Code
              </div>
            )}
          </div>
          <span className="text-[11px] text-neutral-400 mt-2 font-mono">
            Scan with iPhone Camera or Android Lens
          </span>
        </div>

        {/* Direct Link & Copy */}
        <div className="mt-3 bg-neutral-900/90 border border-white/10 rounded-2xl p-2.5 flex items-center justify-between gap-2">
          <div className="truncate text-xs font-mono text-[#F5E1A4] px-2 select-all">
            {mobileUrl}
          </div>
          <button
            onClick={handleCopy}
            className="flex-shrink-0 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#F5E1A4] to-[#D4AF37] text-neutral-950 text-xs font-bold shadow-md hover:brightness-110 active:scale-95 transition cursor-pointer"
          >
            {copied ? "Copied! ✓" : "Copy"}
          </button>
        </div>

        {/* Step-by-Step Instructions */}
        <div className="mt-4 space-y-2 text-[11px] text-neutral-300 bg-white/5 border border-white/5 rounded-2xl p-3.5">
          <div className="flex items-start gap-2">
            <span className="text-[#D4AF37] font-bold">1.</span>
            <span>Make sure your phone is connected to the same Wi-Fi network as this laptop.</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-[#D4AF37] font-bold">2.</span>
            <span>Scan the QR code or paste the link into Safari (iOS) or Chrome (Android).</span>
          </div>
          <div className="flex items-start gap-2">
            <span className="text-[#D4AF37] font-bold">3.</span>
            <span>
              {isHttps ? (
                <>Tap <strong>&quot;Advanced&quot; → &quot;Proceed&quot;</strong> once to accept the self-signed certificate and allow camera access.</>
              ) : (
                <>For mobile camera access, run <strong><code className="text-[#F5E1A4]">npm run dev:https</code></strong> on your laptop so HTTPS is active!</>
              )}
            </span>
          </div>
        </div>

        {/* Done / Close Button */}
        <button
          onClick={onClose}
          className="w-full mt-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-medium text-neutral-300 hover:text-white transition cursor-pointer"
        >
          Got it
        </button>
      </div>
    </div>
  );
}

