"use client";

import React, { useEffect, useRef, useState, useCallback } from "react";
import { Play, Pause, ChevronLeft, ChevronRight, Camera, Loader2 } from "lucide-react";

interface PhotoSequenceViewerProps {
  /** Pre-sorted object URLs for all frames */
  frameUrls: string[];
  onClose: () => void;
  onConfirm?: () => void;
}

const AUTO_PLAY_FPS = 10; // frames per second during auto-play

export function PhotoSequenceViewer({
  frameUrls,
  onClose,
  onConfirm,
}: PhotoSequenceViewerProps) {
  const [currentFrame, setCurrentFrame] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [loaded, setLoaded] = useState(0);
  const [allLoaded, setAllLoaded] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartX = useRef<number>(0);
  const dragStartFrame = useRef<number>(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef<number>(0);
  const lastFrameTime = useRef<number>(0);

  const total = frameUrls.length;

  // Preload all frames
  useEffect(() => {
    let loadedCount = 0;
    setLoaded(0);
    setAllLoaded(false);

    const images = frameUrls.map((url) => {
      const img = new Image();
      img.onload = img.onerror = () => {
        loadedCount++;
        setLoaded(loadedCount);
        if (loadedCount === frameUrls.length) {
          setAllLoaded(true);
        }
      };
      img.src = url;
      return img;
    });

    return () => {
      images.forEach((img) => {
        img.onload = null;
        img.onerror = null;
        img.src = "";
      });
    };
  }, [frameUrls]);

  // Auto-play loop
  useEffect(() => {
    if (!playing || !allLoaded) {
      cancelAnimationFrame(rafRef.current);
      return;
    }

    const interval = 1000 / AUTO_PLAY_FPS;

    const tick = (time: number) => {
      rafRef.current = requestAnimationFrame(tick);
      if (time - lastFrameTime.current >= interval) {
        lastFrameTime.current = time;
        setCurrentFrame((f) => (f + 1) % total);
      }
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [playing, allLoaded, total]);

  // Drag-to-scrub
  const handlePointerDown = useCallback(
    (e: React.PointerEvent) => {
      if (!allLoaded) return;
      setIsDragging(true);
      setPlaying(false);
      dragStartX.current = e.clientX;
      dragStartFrame.current = currentFrame;
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    },
    [allLoaded, currentFrame]
  );

  const handlePointerMove = useCallback(
    (e: React.PointerEvent) => {
      if (!isDragging || !containerRef.current) return;
      const containerWidth = containerRef.current.clientWidth;
      const dx = e.clientX - dragStartX.current;
      // Dragging full container width = full 360° cycle
      const frameDelta = Math.round((dx / containerWidth) * total);
      const newFrame = ((dragStartFrame.current + frameDelta) % total + total) % total;
      setCurrentFrame(newFrame);
    },
    [isDragging, total]
  );

  const handlePointerUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const goFrame = (delta: number) => {
    setPlaying(false);
    setCurrentFrame((f) => ((f + delta) % total + total) % total);
  };

  const progressPct = allLoaded ? 100 : Math.round((loaded / total) * 100);

  return (
    <div className="flex flex-col w-full gap-3">
      {/* Loading bar (shown until all frames preloaded) */}
      {!allLoaded && (
        <div className="space-y-2 py-2">
          <div className="flex items-center justify-between text-xs text-zinc-400 font-mono">
            <span className="flex items-center gap-1.5">
              <Loader2 className="w-3 h-3 animate-spin text-amber-400" />
              Preloading frames…
            </span>
            <span>
              {loaded} / {total}
            </span>
          </div>
          <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full transition-all duration-150"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      )}

      {/* Image frame display */}
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className={`relative w-full aspect-square max-h-[360px] rounded-xl overflow-hidden bg-[radial-gradient(#252528_1px,transparent_1px)] [background-size:16px_16px] bg-[#141417] border border-white/10 flex items-center justify-center ${
          allLoaded ? "cursor-ew-resize" : "cursor-default"
        }`}
        style={{ touchAction: "none" }}
      >
        {frameUrls.map((url, i) => (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            key={url}
            src={url}
            alt={`Frame ${i + 1}`}
            className="absolute inset-0 w-full h-full object-contain transition-opacity duration-75"
            style={{
              opacity: i === currentFrame && allLoaded ? 1 : 0,
              pointerEvents: "none",
            }}
            draggable={false}
          />
        ))}

        {!allLoaded && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-10 h-10 border-2 border-amber-400/30 border-t-amber-400 rounded-full animate-spin" />
          </div>
        )}

        {/* Frame indicator */}
        {allLoaded && (
          <div className="absolute bottom-3 right-3 text-[10px] font-mono text-zinc-400 bg-black/50 px-2 py-0.5 rounded backdrop-blur pointer-events-none">
            {currentFrame + 1} / {total}
          </div>
        )}

        {/* Drag hint */}
        {allLoaded && (
          <div className="absolute bottom-3 left-3 pointer-events-none text-[10px] tracking-wider text-zinc-400 font-mono bg-black/40 px-2 py-1 rounded backdrop-blur">
            DRAG LEFT/RIGHT TO ROTATE
          </div>
        )}
      </div>

      {/* Frame slider */}
      {allLoaded && (
        <input
          type="range"
          min="0"
          max={total - 1}
          value={currentFrame}
          onChange={(e) => {
            setPlaying(false);
            setCurrentFrame(parseInt(e.target.value));
          }}
          className="w-full accent-amber-400 bg-zinc-800 rounded h-1 cursor-pointer"
        />
      )}

      {/* Controls */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <button
            onClick={() => goFrame(-1)}
            disabled={!allLoaded}
            className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-zinc-300 hover:text-white disabled:opacity-40 transition"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => setPlaying((p) => !p)}
            disabled={!allLoaded}
            className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:border-amber-400/40 text-zinc-300 hover:text-white transition-all flex items-center gap-1.5 text-xs font-mono disabled:opacity-40"
          >
            {playing ? (
              <Pause className="w-3.5 h-3.5 text-amber-400" />
            ) : (
              <Play className="w-3.5 h-3.5 text-amber-400" />
            )}
            {playing ? "PAUSE" : "PLAY"}
          </button>
          <button
            onClick={() => goFrame(1)}
            disabled={!allLoaded}
            className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-zinc-300 hover:text-white disabled:opacity-40 transition"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <span className="text-[11px] text-zinc-500 font-mono ml-1">
            {AUTO_PLAY_FPS} fps
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-white/10 text-zinc-300 hover:text-white hover:bg-white/5 text-sm font-medium transition-colors"
          >
            Choose Different
          </button>
          {onConfirm && (
            <button
              id="photo-sequence-confirm"
              onClick={onConfirm}
              disabled={!allLoaded}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-semibold text-sm shadow-lg shadow-amber-500/20 transition-all disabled:opacity-50"
            >
              <Camera className="w-4 h-4" />
              Add to Catalog
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
