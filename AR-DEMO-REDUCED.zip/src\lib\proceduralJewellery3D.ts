import * as THREE from "three";

export type MetalColorType = "gold" | "silver" | "rose_gold";

export const LUXURY_METALS: Record<MetalColorType, { color: number; roughness: number; metalness: number }> = {
  gold: { color: 0xd4af37, roughness: 0.18, metalness: 1.0 },
  silver: { color: 0xc0c0c0, roughness: 0.22, metalness: 1.0 },
  rose_gold: { color: 0xb76e79, roughness: 0.20, metalness: 1.0 },
};

/**
 * Creates faceted brilliant-cut round diamond geometry.
 * Flat shading, distinct crown, table, girdle and pavilion.
 */
export function createBrilliantCutDiamondGeometry(radius = 0.22): THREE.BufferGeometry {
  const geom = new THREE.CylinderGeometry(radius * 0.65, radius, radius * 0.45, 8, 1);
  const bottomCone = new THREE.ConeGeometry(radius, radius * 0.85, 8);
  bottomCone.rotateX(Math.PI);
  bottomCone.translate(0, -radius * 0.425, 0);
  geom.translate(0, radius * 0.225, 0);

  // Merge crown and pavilion
  // Using Octahedron with detail 1 creates a stunning brilliant diamond facet structure
  const octa = new THREE.OctahedronGeometry(radius, 1);
  octa.scale(1.15, 0.9, 1.15);
  return octa;
}

/**
 * Creates luxury PBR materials for metals and gemstones.
 */
export function createJewelleryMaterials(metal: MetalColorType = "gold") {
  const metalCfg = LUXURY_METALS[metal] || LUXURY_METALS.gold;

  const goldMat = new THREE.MeshPhysicalMaterial({
    color: metalCfg.color,
    metalness: metalCfg.metalness,
    roughness: metalCfg.roughness,
    clearcoat: 0.3,
    clearcoatRoughness: 0.1,
    envMapIntensity: 1.4,
  });

  const diamondMat = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    metalness: 0.0,
    roughness: 0.0,
    transmission: 0.9,
    ior: 2.4,
    thickness: 0.5,
    clearcoat: 1.0,
    clearcoatRoughness: 0.05,
    envMapIntensity: 1.4,
    transparent: true,
  });

  const rubyMat = new THREE.MeshPhysicalMaterial({
    color: 0xcc1133,
    metalness: 0.0,
    roughness: 0.0,
    transmission: 0.90,
    ior: 1.77,
    thickness: 0.5,
    clearcoat: 0.8,
    envMapIntensity: 1.4,
    transparent: true,
  });

  const emeraldMat = new THREE.MeshPhysicalMaterial({
    color: 0x11aa55,
    metalness: 0.0,
    roughness: 0.1,
    transmission: 0.88,
    ior: 1.58,
    thickness: 0.6,
    clearcoat: 0.8,
    envMapIntensity: 2.8,
    transparent: true,
  });

  const sapphireMat = new THREE.MeshPhysicalMaterial({
    color: 0x1144dd,
    metalness: 0.0,
    roughness: 0.08,
    transmission: 0.92,
    ior: 1.77,
    thickness: 0.6,
    clearcoat: 0.8,
    envMapIntensity: 2.8,
    transparent: true,
  });

  const pearlMat = new THREE.MeshPhysicalMaterial({
    color: 0xfcf8ee,
    metalness: 0.1,
    roughness: 0.25,
    clearcoat: 0.9,
    clearcoatRoughness: 0.15,
    envMapIntensity: 2.2,
  });

  return { goldMat, diamondMat, rubyMat, emeraldMat, sapphireMat, pearlMat };
}

/**
 * Builds 3D procedural finger ring tailored to the chosen style.
 */
export function buildProceduralRing(
  style: string,
  goldMat: THREE.Material,
  diamondMat: THREE.Material,
  auxMats?: { rubyMat: THREE.Material; emeraldMat: THREE.Material; sapphireMat: THREE.Material; pearlMat: THREE.Material }
): THREE.Group {
  const root = new THREE.Group();
  root.name = "proceduralRing";

  const normStyle = (style || "solitaire").toLowerCase();

  // 1. Base Ring Band (Torus in XY plane, hole along Z)
  if (normStyle.includes("twisted")) {
    // Intertwined double torus
    const torusA = new THREE.Mesh(new THREE.TorusGeometry(0.50, 0.05, 24, 64), goldMat);
    torusA.rotation.x = 0.08;
    root.add(torusA);
    const torusB = new THREE.Mesh(new THREE.TorusGeometry(0.50, 0.05, 24, 64), goldMat);
    torusB.rotation.x = -0.08;
    root.add(torusB);
  } else {
    // Standard luxury rounded comfort band
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.50, 0.085, 32, 64), goldMat);
    root.add(band);
  }

  // 2. Setting Group on top (Y = +0.50)
  const setting = new THREE.Group();
  setting.name = "ringSetting";
  setting.position.set(0, 0.50, 0);

  if (normStyle.includes("heritage") || normStyle.includes("navratna")) {
    // AUTHENTIC HERITAGE NAVRATNA RING:
    // Large ornate gold medallion with central stone + 8 surrounding stones in petal bezels
    const basePlate = new THREE.Mesh(new THREE.CylinderGeometry(0.30, 0.24, 0.08, 16), goldMat);
    setting.add(basePlate);

    // Central ruby / diamond
    const centerGem = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.14, 1),
      auxMats?.rubyMat || diamondMat
    );
    centerGem.position.set(0, 0.06, 0);
    setting.add(centerGem);

    // 8 Navratna perimeter gems
    const navMats = auxMats
      ? [
          auxMats.emeraldMat,
          diamondMat,
          auxMats.sapphireMat,
          auxMats.pearlMat,
          auxMats.rubyMat,
          diamondMat,
          auxMats.emeraldMat,
          auxMats.sapphireMat,
        ]
      : [diamondMat];

    for (let i = 0; i < 8; i++) {
      const a = (i * Math.PI) / 4;
      const gx = 0.21 * Math.cos(a);
      const gz = 0.21 * Math.sin(a);

      // Gold cup bezel
      const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.065, 0.05, 0.06, 8), goldMat);
      cup.position.set(gx, 0.05, gz);
      setting.add(cup);

      // Navratna gem
      const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.06, 1), navMats[i % navMats.length]);
      gem.position.set(gx, 0.09, gz);
      setting.add(gem);
    }
  } else if (normStyle.includes("cluster") || normStyle.includes("flower")) {
    // Floral Cluster: Center diamond + 6 halo diamonds
    const centerGem = new THREE.Mesh(new THREE.OctahedronGeometry(0.16, 1), diamondMat);
    centerGem.position.set(0, 0.08, 0);
    setting.add(centerGem);

    for (let i = 0; i < 6; i++) {
      const a = (i * Math.PI) / 3;
      const hGem = new THREE.Mesh(new THREE.OctahedronGeometry(0.10, 1), diamondMat);
      hGem.position.set(0.18 * Math.cos(a), 0.06, 0.18 * Math.sin(a));
      setting.add(hGem);

      const prong = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.12, 6), goldMat);
      prong.position.set(0.24 * Math.cos(a), 0.06, 0.24 * Math.sin(a));
      setting.add(prong);
    }
  } else if (normStyle.includes("three_stone") || normStyle.includes("trilogy")) {
    // 3 Stone: Large center + 2 flanking diamonds
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.14, 0.08, 16), goldMat);
    setting.add(collar);

    const centerGem = new THREE.Mesh(new THREE.OctahedronGeometry(0.22, 1), diamondMat);
    centerGem.position.set(0, 0.12, 0);
    setting.add(centerGem);

    // Left and right stones
    for (const sx of [-0.22, 0.22]) {
      const sideCollar = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.10, 0.06, 12), goldMat);
      sideCollar.position.set(sx, -0.02, 0);
      setting.add(sideCollar);

      const sideGem = new THREE.Mesh(new THREE.OctahedronGeometry(0.13, 1), diamondMat);
      sideGem.position.set(sx, 0.05, 0);
      setting.add(sideGem);
    }
  } else if (normStyle.includes("signet")) {
    // Solid gold signet ring with engraved beveled crest
    const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.20, 0.14, 8), goldMat);
    plate.position.set(0, 0.05, 0);
    setting.add(plate);

    // Inner relief monogram diamond
    const monogram = new THREE.Mesh(new THREE.OctahedronGeometry(0.09, 1), diamondMat);
    monogram.position.set(0, 0.13, 0);
    setting.add(monogram);
  } else if (normStyle.includes("eternity")) {
    // Eternity band: Diamonds set around perimeter
    for (let i = 0; i < 18; i++) {
      const a = (i * Math.PI * 2) / 18;
      const ex = 0.50 * Math.sin(a);
      const ey = 0.50 * Math.cos(a);
      const eGem = new THREE.Mesh(new THREE.OctahedronGeometry(0.065, 1), diamondMat);
      eGem.position.set(ex, ey, 0);
      root.add(eGem);
    }
  } else {
    // Classic Solitaire / Cathedral / Halo: Gallery collar + 4 prongs + brilliant diamond
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.14, 0.08, 16), goldMat);
    collar.position.set(0, 0.04, 0);
    setting.add(collar);

    const prongDist = 0.11;
    for (const [px, pz] of [
      [-prongDist, -prongDist],
      [prongDist, -prongDist],
      [-prongDist, prongDist],
      [prongDist, prongDist],
    ]) {
      const prong = new THREE.Mesh(new THREE.CylinderGeometry(0.024, 0.018, 0.18, 8), goldMat);
      prong.position.set(px, 0.09, pz);
      prong.rotation.x = pz > 0 ? -0.1 : 0.1;
      prong.rotation.z = px > 0 ? 0.1 : -0.1;
      setting.add(prong);
    }

    const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.22, 1), diamondMat);
    gem.position.set(0, 0.14, 0);
    gem.scale.set(1.15, 0.9, 1.15);
    setting.add(gem);
  }

  root.add(setting);
  return root;
}

/**
 * Builds 3D procedural bangles / kada.
 */
export function buildProceduralBangle(style: string, goldMat: THREE.Material): THREE.Group {
  const root = new THREE.Group();
  root.name = "proceduralBangle";

  const norm = (style || "").toLowerCase();
  if (norm.includes("twisted")) {
    // Intertwined kada
    const m1 = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.038, 24, 64), goldMat);
    m1.scale.set(1, 1, 0.75);
    m1.rotation.z = 0.1;
    root.add(m1);
    const m2 = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.038, 24, 64), goldMat);
    m2.scale.set(1, 1, 0.75);
    m2.rotation.z = -0.1;
    root.add(m2);
  } else if (norm.includes("carved")) {
    // Carved ridge kada
    const main = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.055, 12, 64), goldMat);
    main.scale.set(1, 1, 0.70);
    root.add(main);
    // Outer engraved ridge
    const ridge = new THREE.Mesh(new THREE.TorusGeometry(0.50, 0.015, 8, 64), goldMat);
    root.add(ridge);
  } else {
    // Solid luxury flat-edged kada
    const mesh = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.048, 28, 64), goldMat);
    mesh.scale.set(1, 1, 0.75);
    root.add(mesh);
  }

  return root;
}

/**
 * Builds 3D procedural earrings (Jhumka / Chandbali / Stud).
 */
export function buildProceduralEarrings(
  style: string,
  goldMat: THREE.Material,
  diamondMat: THREE.Material,
  auxMats?: { pearlMat: THREE.Material; rubyMat: THREE.Material }
): THREE.Group {
  const root = new THREE.Group();
  root.name = "proceduralEarring";
  const norm = (style || "").toLowerCase();

  if (norm.includes("jhumk") || norm.includes("chandbali") || norm.includes("drop")) {
    // Top Stud
    const topStud = new THREE.Mesh(new THREE.OctahedronGeometry(0.10, 1), diamondMat);
    topStud.position.set(0, 0.35, 0);
    root.add(topStud);

    // Connecting link
    const link = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.15, 8), goldMat);
    link.position.set(0, 0.22, 0);
    root.add(link);

    // Bell dome (Jhumka)
    const domeGeom = new THREE.SphereGeometry(0.24, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.55);
    const dome = new THREE.Mesh(domeGeom, goldMat);
    dome.position.set(0, 0.05, 0);
    root.add(dome);

    // Rim of dome
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.02, 16, 32), goldMat);
    rim.position.set(0, 0.05, 0);
    rim.rotation.x = Math.PI / 2;
    root.add(rim);

    // Hanging pearl latkan beads along rim
    const pearlMat = auxMats?.pearlMat || goldMat;
    for (let i = 0; i < 7; i++) {
      const a = (i * Math.PI * 2) / 7;
      const bead = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 12), pearlMat);
      bead.position.set(0.23 * Math.cos(a), -0.04, 0.23 * Math.sin(a));
      root.add(bead);
    }
  } else {
    // Solitaire stud with prong basket
    const basket = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.08, 0.06, 12), goldMat);
    root.add(basket);

    const stone = new THREE.Mesh(new THREE.OctahedronGeometry(0.16, 1), diamondMat);
    stone.position.set(0, 0.04, 0);
    root.add(stone);
  }

  return root;
}

/**
 * Builds 3D procedural necklace (CatmullRom chain with links + pendant).
 */
export function buildProceduralNecklace(
  goldMat: THREE.Material,
  gemMat: THREE.Material,
  auxMats?: { rubyMat: THREE.Material }
): THREE.Group {
  const root = new THREE.Group();
  root.name = "proceduralNecklace";

  // CatmullRom Curve along neckline
  const points = [
    new THREE.Vector3(-0.85, 0.65, -0.15),
    new THREE.Vector3(-0.60, 0.20, 0.0),
    new THREE.Vector3(-0.30, -0.25, 0.15),
    new THREE.Vector3(0.0, -0.45, 0.20), // lowest point / pendant
    new THREE.Vector3(0.30, -0.25, 0.15),
    new THREE.Vector3(0.60, 0.20, 0.0),
    new THREE.Vector3(0.85, 0.65, -0.15),
  ];
  const curve = new THREE.CatmullRomCurve3(points);

  // Chain tube
  const tubeGeom = new THREE.TubeGeometry(curve, 64, 0.032, 12, false);
  const chainMesh = new THREE.Mesh(tubeGeom, goldMat);
  root.add(chainMesh);

  // Pendant Medallion at (0, -0.45, 0.20)
  const pendGroup = new THREE.Group();
  pendGroup.position.set(0, -0.45, 0.20);

  const bail = new THREE.Mesh(new THREE.TorusGeometry(0.06, 0.015, 12, 24), goldMat);
  bail.position.set(0, 0.04, 0);
  pendGroup.add(bail);

  const medGeom = new THREE.CylinderGeometry(0.22, 0.18, 0.06, 16);
  const medallion = new THREE.Mesh(medGeom, goldMat);
  medallion.rotation.x = Math.PI / 2;
  medallion.position.set(0, -0.15, 0);
  pendGroup.add(medallion);

  const stone = new THREE.Mesh(new THREE.OctahedronGeometry(0.14, 1), auxMats?.rubyMat || gemMat);
  stone.position.set(0, -0.15, 0.05);
  pendGroup.add(stone);

  root.add(pendGroup);
  return root;
}

/**
 * Builds 3D procedural nose ring (Nath or Hoop or Stud).
 */
export function buildProceduralNoseRing(
  style: string,
  goldMat: THREE.Material,
  diamondMat: THREE.Material
): THREE.Group {
  const root = new THREE.Group();
  root.name = "proceduralNoseRing";
  const norm = (style || "").toLowerCase();

  if (norm.includes("nath")) {
    // Large hoop with gem cluster
    const hoop = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.02, 16, 48), goldMat);
    root.add(hoop);

    const cluster = new THREE.Mesh(new THREE.OctahedronGeometry(0.10, 1), diamondMat);
    cluster.position.set(-0.25, -0.18, 0);
    root.add(cluster);
  } else if (norm.includes("hoop")) {
    // Small gold hoop
    const hoop = new THREE.Mesh(new THREE.TorusGeometry(0.20, 0.025, 16, 48), goldMat);
    root.add(hoop);
  } else {
    // Solitaire stud
    const stud = new THREE.Mesh(new THREE.OctahedronGeometry(0.12, 1), diamondMat);
    root.add(stud);
    const prongs = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.05, 0.04, 8), goldMat);
    root.add(prongs);
  }

  return root;
}

/**
 * Builds a thick photo-relief 3D mesh for 2D cutout jewellery images.
 * Has front and back textured planes with metallic bevel and side rim so it has real depth and parallax.
 */
export function buildExtrudedReliefJewellery(
  tex: THREE.Texture,
  goldMat: THREE.Material,
  aspect: number,
  thickness = 0.045
): THREE.Group {
  const group = new THREE.Group();
  group.name = "photoRelief3DMesh";

  const w = Math.min(1.4, aspect >= 1 ? 1.2 : 1.2 * aspect);
  const h = aspect >= 1 ? 1.2 / aspect : 1.2;

  // Gold core box for depth/rim
  const rimBox = new THREE.Mesh(new THREE.BoxGeometry(w * 0.98, h * 0.98, thickness), goldMat);
  group.add(rimBox);

  // Front textured face
  const frontPlaneMat = new THREE.MeshStandardMaterial({
    map: tex,
    transparent: true,
    alphaTest: 0.06,
    metalness: 0.85,
    roughness: 0.22,
    envMapIntensity: 2.2,
    side: THREE.FrontSide,
  });
  const frontPlane = new THREE.Mesh(new THREE.PlaneGeometry(w, h), frontPlaneMat);
  frontPlane.position.z = thickness / 2 + 0.001;
  group.add(frontPlane);

  // Back textured face
  const backPlaneMat = new THREE.MeshStandardMaterial({
    map: tex,
    transparent: true,
    alphaTest: 0.06,
    metalness: 0.85,
    roughness: 0.22,
    envMapIntensity: 2.2,
    side: THREE.BackSide,
  });
  const backPlane = new THREE.Mesh(new THREE.PlaneGeometry(w, h), backPlaneMat);
  backPlane.position.z = -thickness / 2 - 0.001;
  group.add(backPlane);

  return group;
}
