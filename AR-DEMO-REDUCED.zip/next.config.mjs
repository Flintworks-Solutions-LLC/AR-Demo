/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    largePageDataBytes: 256 * 1024, // 256 KB
    serverComponentsExternalPackages: [
      "@imgly/background-removal",
      "onnxruntime-web",
      "@mediapipe/tasks-vision",
      "@huggingface/transformers",
    ],
  },
  webpack: (config, { isServer }) => {
    // Allow @imgly/background-removal to load its WASM assets at runtime
    config.resolve.fallback = {
      ...config.resolve.fallback,
      fs: false,
      path: false,
      crypto: false,
    };

    // Treat .wasm files as assets so they are served from /_next/static
    config.module.rules.push({
      test: /\.wasm$/,
      type: "asset/resource",
    });

    // Disable Webpack from treating `new URL(..., import.meta.url)` as asset modules
    // which causes it to dump .mjs files into static/media and fail during minification
    config.module.parser = {
      ...config.module.parser,
      javascript: {
        ...config.module.parser?.javascript,
        url: false,
      },
    };

    return config;
  },
};

export default nextConfig;
