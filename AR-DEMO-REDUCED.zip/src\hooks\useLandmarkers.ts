"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import type {
  FaceLandmarker as FaceLandmarkerType,
  HandLandmarker as HandLandmarkerType,
  PoseLandmarker as PoseLandmarkerType,
  FaceLandmarkerResult,
  HandLandmarkerResult,
  PoseLandmarkerResult,
} from "@mediapipe/tasks-vision";

export type LandmarkerCategory =
  | "earrings"
  | "nose_ring"
  | "noserings"
  | "necklace"
  | "necklaces"
  | "bangles"
  | "finger_ring"
  | "rings"
  | "sets"
  | null;

/** @deprecated use LandmarkerCategory — kept for backward compatibility */
export type ExtendedCategory = LandmarkerCategory;

export function useLandmarkers() {
  const [isFaceLoaded, setIsFaceLoaded] = useState(false);
  const [isHandLoaded, setIsHandLoaded] = useState(false);
  const [isPoseLoaded, setIsPoseLoaded] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);

  const faceRef = useRef<FaceLandmarkerType | null>(null);
  const handRef = useRef<HandLandmarkerType | null>(null);
  const poseRef = useRef<PoseLandmarkerType | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const visionRef = useRef<any>(null);

  const retryInit = useCallback(() => {
    setIsLoading(true);
    setError(null);
    setIsReady(false);
    setIsFaceLoaded(false);
    setIsHandLoaded(false);
    setIsPoseLoaded(false);
    setRetryCount((c) => c + 1);
  }, []);

  useEffect(() => {
    let isMounted = true;
    let timeoutId: NodeJS.Timeout | null = null;

    async function init() {
      setIsLoading(true);
      setError(null);

      // 15-second timeout on model/wasm loading
      timeoutId = setTimeout(() => {
        if (!isMounted) return;
        const msg = "AR tracking models timed out after 15 seconds. Please check your connection and retry.";
        console.error(`[AR Init] ${msg}`);
        setError(msg);
        setIsLoading(false);
      }, 15000);

      try {
        console.info("[AR Init] Step 1: Dynamically importing @mediapipe/tasks-vision on client...");
        const visionModule = await import("@mediapipe/tasks-vision");
        const { FilesetResolver, FaceLandmarker, HandLandmarker, PoseLandmarker } = visionModule;

        if (!isMounted) return;

        // Resolve WASM assets: try local /wasm first, fallback to jsdelivr CDN
        if (!visionRef.current) {
          try {
            console.info("[AR Init] Resolving WASM binaries from local /wasm...");
            visionRef.current = await FilesetResolver.forVisionTasks("/wasm");
          } catch (wasmErr) {
            console.warn("[AR Init] Local /wasm failed, falling back to CDN:", wasmErr);
            visionRef.current = await FilesetResolver.forVisionTasks(
              "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
            );
          }
        }
        const vision = visionRef.current;
        console.info("[AR Init] Step 2: FilesetResolver ready. Initializing landmarker models...");

        const tryCreate = async <T>(
          createFn: (delegate: "GPU" | "CPU") => Promise<T>,
          setLoaded: (v: boolean) => void,
          ref: { current: T | null },
          label: string
        ) => {
          for (const delegate of ["GPU", "CPU"] as const) {
            try {
              const inst = await createFn(delegate);
              if (!isMounted) {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                (inst as any)?.close?.();
                return;
              }
              ref.current = inst;
              setLoaded(true);
              console.info(`[AR Init] ${label} successfully loaded on ${delegate}`);
              return;
            } catch (e) {
              console.warn(`[AR Init] ${label} creation failed on ${delegate}:`, e);
            }
          }
          console.error(`[AR Init] ${label} FAILED on all delegates`);
        }

        // Initialize Face, Hand, and Pose models in parallel
        await Promise.all([
          tryCreate(
            (d) =>
              FaceLandmarker.createFromOptions(vision, {
                baseOptions: {
                  modelAssetPath: "/models/face_landmarker.task",
                  delegate: d,
                },
                runningMode: "VIDEO",
                numFaces: 1,
                outputFaceBlendshapes: false,
                outputFacialTransformationMatrixes: false,
              }),
            setIsFaceLoaded,
            faceRef,
            "FaceLandmarker"
          ),
          tryCreate(
            (d) =>
              HandLandmarker.createFromOptions(vision, {
                baseOptions: {
                  modelAssetPath: "/models/hand_landmarker.task",
                  delegate: d,
                },
                runningMode: "VIDEO",
                numHands: 2,
              }),
            setIsHandLoaded,
            handRef,
            "HandLandmarker"
          ),
          tryCreate(
            (d) =>
              PoseLandmarker.createFromOptions(vision, {
                baseOptions: {
                  modelAssetPath: "/models/pose_landmarker_lite.task",
                  delegate: d,
                },
                runningMode: "VIDEO",
                numPoses: 1,
              }),
            setIsPoseLoaded,
            poseRef,
            "PoseLandmarker"
          ),
        ]);

        if (timeoutId) clearTimeout(timeoutId);

        if (isMounted) {
          setIsReady(true);
          setIsLoading(false);
          console.info("[AR Init] Step 3: All tracking models initialized successfully!");
        }
      } catch (err) {
        if (timeoutId) clearTimeout(timeoutId);
        const errorMsg = (err as Error)?.message || "Failed to load MediaPipe tracking models.";
        console.error("[AR Init] Fatal model load error:", err);
        if (isMounted) {
          setError(errorMsg);
          setIsLoading(false);
        }
      }
    }

    init();

    return () => {
      isMounted = false;
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [retryCount]);

  const detect = useCallback(
    (
      videoElement: HTMLVideoElement,
      timestamp: number,
      category: ExtendedCategory | string | null
    ): {
      faceResult: FaceLandmarkerResult | null;
      handResult: HandLandmarkerResult | null;
      poseResult: PoseLandmarkerResult | null;
    } => {
      let faceResult: FaceLandmarkerResult | null = null;
      let handResult: HandLandmarkerResult | null = null;
      let poseResult: PoseLandmarkerResult | null = null;

      const cat = category || "";
      const isNecklace = cat === "necklace" || cat === "necklaces";
      const isEarrings = cat === "earrings";
      const isNoseRing = cat === "nose_ring" || cat === "noserings";
      const isBangles = cat === "bangles";
      const isRing = cat === "finger_ring" || cat === "rings";
      const isSet = cat === "sets";

      const needsFace = isEarrings || isNoseRing || isNecklace || isSet;
      const needsHand = isBangles || isRing;
      const needsPose = isNecklace || isSet;

      try {
        if (needsFace && faceRef.current && isFaceLoaded) {
          faceResult = faceRef.current.detectForVideo(videoElement, timestamp);
        }
        if (needsHand && handRef.current && isHandLoaded) {
          handResult = handRef.current.detectForVideo(videoElement, timestamp);
        }
        if (needsPose && poseRef.current && isPoseLoaded) {
          poseResult = poseRef.current.detectForVideo(videoElement, timestamp);
        }
      } catch (e) {
        console.warn("[Landmarkers] Detection error:", e);
      }

      return { faceResult, handResult, poseResult };
    },
    [isFaceLoaded, isHandLoaded, isPoseLoaded]
  );

  return {
    isReady,
    isLoading,
    isFaceLoaded,
    isHandLoaded,
    isPoseLoaded,
    error,
    retryInit,
    detect,
  };
}
