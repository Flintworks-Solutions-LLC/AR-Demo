import { NextRequest, NextResponse } from "next/server";
import { spawn } from "child_process";
import path from "path";

export const maxDuration = 60; // 60 seconds max

export async function POST(req: NextRequest) {
  try {
    let imageBase64 = "";
    let category = "necklace";
    let model = "birefnet-general";
    let feather = 1.0;
    let padding = 8;

    const contentType = req.headers.get("content-type") || "";

    if (contentType.includes("application/json")) {
      const body = await req.json();
      imageBase64 = body.image || "";
      if (body.category) category = body.category;
      if (body.model) model = body.model;
      if (typeof body.feather === "number") feather = body.feather;
      if (typeof body.padding === "number") padding = body.padding;
    } else if (contentType.includes("multipart/form-data")) {
      const formData = await req.formData();
      const file = formData.get("file") as File | null;
      if (file) {
        const buffer = await file.arrayBuffer();
        imageBase64 = Buffer.from(buffer).toString("base64");
      }
      if (formData.get("category")) category = formData.get("category") as string;
      if (formData.get("model")) model = formData.get("model") as string;
      if (formData.get("feather")) feather = parseFloat(formData.get("feather") as string) || 1.0;
      if (formData.get("padding")) padding = parseInt(formData.get("padding") as string) || 8;
    }

    if (!imageBase64) {
      return NextResponse.json(
        { error: "No image provided. Pass 'image' base64 or 'file' formData." },
        { status: 400 }
      );
    }

    // Strip data URL prefix if present
    if (imageBase64.includes(",")) {
      imageBase64 = imageBase64.split(",")[1];
    }

    const scriptPath = path.join(process.cwd(), "scripts", "remove_background.py");

    // Spawn Python pipeline
    const pythonProcess = spawn(
      "python",
      [
        scriptPath,
        "-",
        "--category",
        category,
        "--model",
        model,
        "--feather",
        String(feather),
        "--padding",
        String(padding),
        "--json",
      ],
      {
        cwd: process.cwd(),
      }
    );

    let stdoutData = "";
    let stderrData = "";

    pythonProcess.stdout.on("data", (chunk) => {
      stdoutData += chunk.toString();
    });

    pythonProcess.stderr.on("data", (chunk) => {
      stderrData += chunk.toString();
    });

    const exitCode = await new Promise<number>((resolve) => {
      pythonProcess.on("close", resolve);
      pythonProcess.on("error", (err) => {
        console.error("[API remove-background] Process error:", err);
        resolve(1);
      });
      // Send image to stdin
      pythonProcess.stdin.write(imageBase64);
      pythonProcess.stdin.end();
    });

    if (exitCode !== 0) {
      console.error("[API remove-background] Python stderr:", stderrData);
      return NextResponse.json(
        { error: "Background removal failed.", details: stderrData },
        { status: 500 }
      );
    }

    try {
      const result = JSON.parse(stdoutData.trim());
      return NextResponse.json(result);
    } catch (parseErr) {
      console.error("[API remove-background] JSON parse error:", parseErr, stdoutData);
      return NextResponse.json(
        { error: "Invalid JSON response from processing pipeline.", details: stdoutData },
        { status: 500 }
      );
    }
  } catch (err: unknown) {
    const error = err as Error;
    console.error("[API remove-background] Server error:", error);
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: 500 }
    );
  }
}
