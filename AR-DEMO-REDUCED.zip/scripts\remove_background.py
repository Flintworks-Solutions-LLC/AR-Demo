#!/usr/bin/env python3
"""
scripts/remove_background.py
============================
High-precision Jewellery Background Removal Pipeline.

STEP 1: Model-based Segmentation (birefnet-general with fallback)
STEP 2: Jewellery-specific Mask Cleanup
  a. Binarize core (alpha > 0.5 -> 1.0)
  b. Fill holes (< 0.2% image area)
  c. Keep largest component + components > 1.5% of largest (drops specks, peacock feathers)
  d. Morphological close (3x3) & small open (3x3)
  e. Color decontamination / edge bleed fix
  f. Premultiplied alpha edge + 1px feather
STEP 3: Background-aware adaptive fallback (LAB flood-fill if model output invalid)
STEP 4: Auto-crop with 8px padding, min 1200px long side preserved, anchor detection
STEP 5: Quality gate (coverage %, warnings)
"""

import sys
import os
import json
import base64
import argparse
from io import BytesIO
from typing import Dict, Any, Tuple, Optional

import numpy as np
from PIL import Image
import scipy.ndimage as ndimage


def rgb_to_lab(rgb: np.ndarray) -> np.ndarray:
    """
    Fast RGB to LAB color space conversion (input in [0, 255]).
    """
    # Normalize RGB to [0, 1]
    r = rgb[..., 0] / 255.0
    g = rgb[..., 1] / 255.0
    b = rgb[..., 2] / 255.0

    # sRGB to linear RGB
    r = np.where(r > 0.04045, ((r + 0.055) / 1.055) ** 2.4, r / 12.92)
    g = np.where(g > 0.04045, ((g + 0.055) / 1.055) ** 2.4, g / 12.92)
    b = np.where(b > 0.04045, ((b + 0.055) / 1.055) ** 2.4, b / 12.92)

    # Observer. = 2°, Illuminant = D65
    X = r * 0.4124564 + g * 0.3575761 + b * 0.1804375
    Y = r * 0.2126729 + g * 0.7151522 + b * 0.0721750
    Z = r * 0.0193339 + g * 0.1191920 + b * 0.9503041

    X = X / 0.95047
    Y = Y / 1.00000
    Z = Z / 1.08883

    fx = np.where(X > 0.008856, X ** (1.0 / 3.0), (7.787 * X) + (16.0 / 116.0))
    fy = np.where(Y > 0.008856, Y ** (1.0 / 3.0), (7.787 * Y) + (16.0 / 116.0))
    fz = np.where(Z > 0.008856, Z ** (1.0 / 3.0), (7.787 * Z) + (16.0 / 116.0))

    L = (116.0 * fy) - 16.0
    A = 500.0 * (fx - fy)
    B = 200.0 * (fy - fz)

    return np.stack([L, A, B], axis=-1)


def upscale_if_needed(img: Image.Image, min_long_side: int = 1500) -> Tuple[Image.Image, float]:
    """
    Step 1: Upscale small images first (2x Lanczos) before segmentation.
    """
    w, h = img.size
    long_side = max(w, h)
    if long_side < min_long_side:
        scale = max(2.0, min_long_side / long_side)
        new_w = int(round(w * scale))
        new_h = int(round(h * scale))
        upscaled = img.resize((new_w, new_h), Image.Resampling.LANCZOS)
        return upscaled, scale
    return img, 1.0


def segment_with_model(img: Image.Image, preferred_model: str = "birefnet-general") -> np.ndarray:
    """
    Step 1: Segmentation with real neural network model (birefnet-general or fallback).
    Never uses brightness or color keying. White diamonds stay completely solid.
    Returns: 2D uint8 mask [0..255]
    """
    import rembg

    session = None
    models_to_try = [preferred_model, "isnet-general-use", "u2net"]
    for m in models_to_try:
        try:
            session = rembg.new_session(m)
            break
        except Exception as e:
            print(f"[pipeline] Could not load model '{m}': {e}", file=sys.stderr)

    if session is None:
        try:
            session = rembg.new_session("u2net")
        except Exception:
            session = None

    if session is not None:
        # Run model segmentation
        res_rgba = rembg.remove(img, session=session)
        alpha = np.array(res_rgba.split()[-1])
        return alpha
    else:
        # If no session available, return default full mask
        return np.full((img.height, img.width), 255, dtype=np.uint8)


def step2_mask_cleanup(
    rgb_arr: np.ndarray,
    raw_mask: np.ndarray,
    binarize_thresh: int = 128,
    feather_px: float = 1.0
) -> Tuple[np.ndarray, np.ndarray]:
    """
    STEP 2: Jewellery-specific post-processing
    a. Binarize core: alpha > 0.5 (128) becomes 1.0 (255) for interior.
    b. Fill holes: enclosed background regions < 0.2% of image area become foreground.
    c. Connected components: keep largest + any > 1.5% of largest; remove specks & feather bits.
    d. Morphological close (3x3) to reconnect links, then small open (3x3) to delete noise.
    e. Edge decontamination: replace edge pixels with nearest solid foreground color.
    f. 1px feather for smooth composite.
    
    Returns: (cleaned_rgba, final_mask)
    """
    h, w = raw_mask.shape
    total_area = h * w

    # a. Binarize the core: interior pixels become solid
    core = (raw_mask >= binarize_thresh).astype(np.uint8)

    # b. Fill holes: background pixels fully enclosed by foreground
    # Invert core: background = 1, foreground = 0
    bg = (core == 0).astype(np.uint8)
    lbl_bg, num_bg = ndimage.label(bg)

    if num_bg > 0:
        # Find labels that touch any border of the image
        border_labels = set(np.unique(lbl_bg[0, :])) \
                      | set(np.unique(lbl_bg[-1, :])) \
                      | set(np.unique(lbl_bg[:, 0])) \
                      | set(np.unique(lbl_bg[:, -1]))
        border_labels.discard(0)

        # Enclosed holes do not touch border
        hole_counts = ndimage.sum(bg, lbl_bg, range(1, num_bg + 1))
        max_hole_area = 0.002 * total_area  # 0.2% image area threshold

        for label_idx in range(1, num_bg + 1):
            if label_idx not in border_labels:
                area = hole_counts[label_idx - 1]
                if area <= max_hole_area:
                    core[lbl_bg == label_idx] = 1  # Fill enclosed diamond/stone/prong gap

    # c. Connected components on foreground
    lbl_fg, num_fg = ndimage.label(core)
    if num_fg > 0:
        fg_counts = ndimage.sum(core, lbl_fg, range(1, num_fg + 1))
        max_fg_area = np.max(fg_counts)
        min_keep_area = max(16.0, 0.015 * max_fg_area)  # 1.5% of largest component

        cleaned_core = np.zeros_like(core)
        for label_idx in range(1, num_fg + 1):
            if fg_counts[label_idx - 1] >= min_keep_area:
                cleaned_core[lbl_fg == label_idx] = 1
        core = cleaned_core

    # d. Morphological close (3x3, 1-2 iter) to reconnect thin chain links,
    # then small open (3x3) to delete 1-2px noise without eroding thin chain.
    struct3 = np.ones((3, 3), dtype=bool)
    core_closed = ndimage.binary_closing(core.astype(bool), structure=struct3, iterations=1)
    core_opened = ndimage.binary_opening(core_closed, structure=struct3, iterations=1)
    core = core_opened.astype(np.uint8)

    # e. Edge decontamination (color bleed fix):
    # Find boundary pixels of the foreground mask and replace their RGB
    # with the color from the nearest solid interior foreground pixel.
    solid_interior = ndimage.binary_erosion(core, structure=struct3, iterations=2)
    if np.any(solid_interior):
        # Distance transform to find nearest solid interior foreground pixel
        indices = ndimage.distance_transform_edt(~solid_interior, return_indices=True)[1]
        decontaminated_rgb = rgb_arr[indices[0], indices[1]]
        
        # Only decontaminate near boundaries (within 4px of edge)
        dist_to_bg = ndimage.distance_transform_edt(core)
        edge_zone = (core == 1) & (dist_to_bg <= 3.5)
        
        final_rgb = rgb_arr.copy()
        # Smoothly blend decontaminated color at the extreme edge
        blend_factor = np.clip((4.0 - dist_to_bg) / 3.0, 0.0, 1.0)[:, :, np.newaxis]
        final_rgb = np.where(edge_zone[:, :, np.newaxis], 
                             (1.0 - blend_factor) * rgb_arr + blend_factor * decontaminated_rgb, 
                             rgb_arr).astype(np.uint8)
    else:
        final_rgb = rgb_arr.copy()

    # f. 1px feather for a smooth, anti-aliased edge
    smooth_mask = ndimage.gaussian_filter(core.astype(np.float32), sigma=feather_px * 0.6)
    final_alpha = np.clip(smooth_mask * 255.0, 0.0, 255.0).astype(np.uint8)

    # Construct RGBA
    cleaned_rgba = np.dstack([final_rgb, final_alpha])
    return cleaned_rgba, final_alpha


def step3_background_aware_fallback(
    rgb_arr: np.ndarray,
    tol: float = 28.0
) -> np.ndarray:
    """
    STEP 3: Background-aware fallback
    Detects dominant border color in LAB space, flood-fills from all outer borders.
    Unreached interior pixels stay foreground (preserves white diamonds on white bg).
    """
    h, w, _ = rgb_arr.shape
    lab_arr = rgb_to_lab(rgb_arr)

    # Sample outer border strip (5px thick)
    borders = np.concatenate([
        lab_arr[:5, :, :].reshape(-1, 3),
        lab_arr[-5:, :, :].reshape(-1, 3),
        lab_arr[:, :5, :].reshape(-1, 3),
        lab_arr[:, -5:, :].reshape(-1, 3),
    ], axis=0)

    # Dominant border color = median in LAB space
    bg_lab = np.median(borders, axis=0)

    # Delta E Euclidean distance in LAB space
    delta_e = np.sqrt(np.sum((lab_arr - bg_lab) ** 2, axis=-1))

    # Seed flood fill from borders where delta_e <= tol
    visited = np.zeros((h, w), dtype=bool)
    is_bg_candidate = delta_e <= tol

    queue = []
    # Seed top and bottom borders
    for x in range(w):
        if is_bg_candidate[0, x]:
            visited[0, x] = True
            queue.append((0, x))
        if is_bg_candidate[h - 1, x]:
            visited[h - 1, x] = True
            queue.append((h - 1, x))
    # Seed left and right borders
    for y in range(h):
        if is_bg_candidate[y, 0]:
            visited[y, 0] = True
            queue.append((y, 0))
        if is_bg_candidate[y, w - 1]:
            visited[y, w - 1] = True
            queue.append((y, w - 1))

    # BFS flood fill
    head = 0
    while head < len(queue):
        cy, cx = queue[head]
        head += 1

        for dy, dx in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            ny, nx = cy + dy, cx + dx
            if 0 <= ny < h and 0 <= nx < w and not visited[ny, nx]:
                if is_bg_candidate[ny, nx]:
                    visited[ny, nx] = True
                    queue.append((ny, nx))

    # Foreground = pixels not reached by border flood-fill
    fg_mask = (~visited).astype(np.uint8) * 255
    return fg_mask


def auto_crop_with_padding(rgba_arr: np.ndarray, padding: int = 8) -> Tuple[np.ndarray, Tuple[int, int, int, int]]:
    """
    Crop tightly to the bounding box of non-transparent pixels, with padding.
    """
    alpha = rgba_arr[..., 3]
    opaque_y, opaque_x = np.where(alpha > 15)

    if len(opaque_x) == 0 or len(opaque_y) == 0:
        return rgba_arr, (0, 0, rgba_arr.shape[1], rgba_arr.shape[0])

    min_x = max(0, int(np.min(opaque_x)) - padding)
    max_x = min(rgba_arr.shape[1] - 1, int(np.max(opaque_x)) + padding)
    min_y = max(0, int(np.min(opaque_y)) - padding)
    max_y = min(rgba_arr.shape[0] - 1, int(np.max(opaque_y)) + padding)

    cropped = rgba_arr[min_y : max_y + 1, min_x : max_x + 1]
    return cropped, (min_x, min_y, max_x, max_y)


def detect_anchors(rgba_arr: np.ndarray, category: str = "necklace") -> Dict[str, Any]:
    """
    Auto-detect anchor points from the cropped transparent PNG.
    """
    h, w = rgba_arr.shape[:2]
    alpha = rgba_arr[..., 3]

    if category == "necklace":
        # Scan top 20% of rows for outermost opaque pixels (strand ends)
        top_zone = max(1, int(round(h * 0.20)))
        top_alpha = alpha[:top_zone, :]
        opaque_y, opaque_x = np.where(top_alpha > 30)

        if len(opaque_x) > 0:
            left_idx = np.argmin(opaque_x)
            right_idx = np.argmax(opaque_x)
            left_end = {"x": float(opaque_x[left_idx]) / w, "y": float(opaque_y[left_idx]) / h}
            right_end = {"x": float(opaque_x[right_idx]) / w, "y": float(opaque_y[right_idx]) / h}
        else:
            left_end = {"x": 0.14, "y": 0.05}
            right_end = {"x": 0.86, "y": 0.05}

        # Pendant center: center of mass of lower 50%
        lower_alpha = alpha[int(h * 0.4):, :]
        ly, lx = np.where(lower_alpha > 30)
        if len(lx) > 0:
            pendant_cx = float(np.mean(lx)) / w
            pendant_cy = (float(np.mean(ly)) + int(h * 0.4)) / h
        else:
            pendant_cx, pendant_cy = 0.5, 0.75

        # Bottommost pixel
        all_y, all_x = np.where(alpha > 30)
        bottom_y = float(np.max(all_y)) / h if len(all_y) > 0 else 0.95

        return {
            "anchor": {"x": 50.0, "y": 0.0},
            "necklaceAnchors": {
                "leftEnd": left_end,
                "rightEnd": right_end,
                "pendantCenter": {"x": pendant_cx, "y": pendant_cy},
                "bottomCenter": {"x": 0.5, "y": bottom_y},
            }
        }

    elif category == "earrings":
        all_y, all_x = np.where(alpha > 30)
        if len(all_y) > 0:
            top_idx = np.argmin(all_y)
            return {"anchor": {"x": float(all_x[top_idx]) / w * 100.0, "y": float(all_y[top_idx]) / h * 100.0}}
        return {"anchor": {"x": 50.0, "y": 10.0}}

    return {"anchor": {"x": 50.0, "y": 50.0}}


def process_jewellery_image(
    input_image: Image.Image,
    category: str = "necklace",
    model_name: str = "birefnet-general",
    feather: float = 1.0,
    crop_padding: int = 8
) -> Dict[str, Any]:
    """
    Complete end-to-end background removal pipeline.
    """
    orig_w, orig_h = input_image.size

    # 1. Upscale if needed to preserve fine chain links and diamonds
    working_img, scale_factor = upscale_if_needed(input_image, min_long_side=1500)
    rgb_arr = np.array(working_img.convert("RGB"))
    h, w, _ = rgb_arr.shape
    total_area = w * h

    # 2. Run model segmentation
    model_mask = segment_with_model(working_img, preferred_model=model_name)

    # 3. Check quality of model output:
    fg_pixels = np.count_nonzero(model_mask > 128)
    coverage = fg_pixels / total_area

    # Check border touch
    border_pixels = np.concatenate([
        model_mask[0, :], model_mask[-1, :], model_mask[:, 0], model_mask[:, -1]
    ])
    border_touch_ratio = np.count_nonzero(border_pixels > 128) / len(border_pixels)

    used_fallback = False
    warning = None

    if coverage < 0.03 or coverage > 0.90 or border_touch_ratio > 0.25:
        # Step 3: Trigger background-aware LAB flood-fill fallback
        used_fallback = True
        raw_mask = step3_background_aware_fallback(rgb_arr, tol=28.0)
    else:
        raw_mask = model_mask

    # 4. Step 2 Mask Cleanup (Jewellery-specific)
    cleaned_rgba, clean_mask = step2_mask_cleanup(
        rgb_arr, raw_mask, binarize_thresh=128, feather_px=feather
    )

    # 5. Quality gate evaluation
    clean_fg_count = np.count_nonzero(clean_mask > 20)
    clean_coverage_pct = round((clean_fg_count / total_area) * 100.0, 1)

    clean_border_pixels = np.concatenate([
        clean_mask[0, :], clean_mask[-1, :], clean_mask[:, 0], clean_mask[:, -1]
    ])
    clean_border_touch_pct = round((np.count_nonzero(clean_border_pixels > 20) / len(clean_border_pixels)) * 100.0, 1)

    if clean_coverage_pct < 2.0:
        warning = "Foreground coverage is very low (< 2%). Use the brush tool to restore missing areas."
    elif clean_coverage_pct > 85.0:
        warning = "Background may not be fully removed (> 85% solid). Use the erase brush to clean up."
    elif clean_border_touch_pct > 20.0:
        warning = "Cutout touches outer borders. Background may not be fully removed, use the brush."

    # 6. Auto-crop to bounding box with padding
    cropped_rgba, bbox = auto_crop_with_padding(cleaned_rgba, padding=crop_padding)

    # Preserve resolution >= 1200px on long side
    crop_h, crop_w = cropped_rgba.shape[:2]
    result_img = Image.fromarray(cropped_rgba, mode="RGBA")

    # Detect anchors from cropped cutout
    anchors = detect_anchors(cropped_rgba, category=category)

    # Encode to PNG base64
    out_buf = BytesIO()
    result_img.save(out_buf, format="PNG", optimize=True)
    out_bytes = out_buf.getvalue()
    b64_png = "data:image/png;base64," + base64.b64encode(out_bytes).decode("ascii")

    return {
        "success": True,
        "dataUrl": b64_png,
        "originalWidth": orig_w,
        "originalHeight": orig_h,
        "croppedWidth": crop_w,
        "croppedHeight": crop_h,
        "aspectRatio": round(crop_w / max(1, crop_h), 4),
        "coveragePercent": clean_coverage_pct,
        "usedFallback": used_fallback,
        "warning": warning,
        **anchors,
    }


def main():
    parser = argparse.ArgumentParser(description="Jewellery Background Removal Pipeline")
    parser.add_argument("input", help="Path to input image file or '-' for stdin base64")
    parser.add_argument("--output", "-o", help="Path to output PNG file (optional)")
    parser.add_argument("--category", "-c", default="necklace", help="Jewellery category")
    parser.add_argument("--model", "-m", default="birefnet-general", help="Model name")
    parser.add_argument("--feather", "-f", type=float, default=1.0, help="Feather radius in px")
    parser.add_argument("--padding", "-p", type=int, default=8, help="Bounding box padding in px")
    parser.add_argument("--json", action="store_true", help="Output JSON result with metadata")
    args = parser.parse_args()

    if args.input == "-":
        data = sys.stdin.read().strip()
        if data.startswith("data:image"):
            data = data.split(",", 1)[1]
        img_bytes = base64.b64decode(data)
        img = Image.open(BytesIO(img_bytes))
    else:
        img = Image.open(args.input)

    result = process_jewellery_image(
        input_image=img,
        category=args.category,
        model_name=args.model,
        feather=args.feather,
        crop_padding=args.padding
    )

    if args.output:
        # Decode base64 and save to file
        raw_b64 = result["dataUrl"].split(",", 1)[1]
        with open(args.output, "wb") as f:
            f.write(base64.b64decode(raw_b64))
        print(f"[pipeline] Saved output to {args.output}", file=sys.stderr)

    if args.json:
        # Output JSON to stdout
        print(json.dumps(result))
    else:
        print(f"Success: {result['croppedWidth']}x{result['croppedHeight']}, coverage: {result['coveragePercent']}%")


if __name__ == "__main__":
    main()
