# Product Upload Requirements & Specifications

This document defines the technical specifications, formatting rules, and optimization guidelines for uploading custom jewellery products to the AR Jewellery Try-On and 360° Turntable viewer platform.

---

## 1. Overview & Upload Modes

The platform supports two distinct product upload workflows:

| Feature | Primary: 3D GLB Model | Fallback: 360° Photo Sequence |
| :--- | :--- | :--- |
| **Experience** | Full 3D rotation, real-time lighting, interactive zoom, live AR face/neck/hand tracking | Interactive 360° turntable spin, scrub timeline |
| **Material Swapping** | Dynamic real-time metal switching (18k Gold, Platinum/Silver, Rose Gold) | Fixed captured studio color |
| **Input Files** | Single binary `.glb` (or single embedded `.gltf`) | 24 to 36 sequential photographs |
| **Max File Size** | 20 MB total | 5 MB per image |

---

## 2. GLB 3D Model Technical Specifications (Primary)

### 2.1 File Format & Packaging
- **Accepted File Extensions:** `.glb` (preferred) or `.gltf`.
- **Packaging:** All geometry, animations, and textures must be embedded into a single `.glb` binary container. External `.bin` buffers or separate image files referenced via relative URIs are not supported.
- **Maximum File Size:** **20 MB**. (Models larger than 20 MB will be rejected by both client and server validators).

### 2.2 Geometry & Polygon Budget
- **Recommended Triangle Count:** Under **200,000 triangles** (tris).
  - WebGL real-time AR runs on mobile devices alongside computer vision landmark detectors. High polygon counts cause frame drops and thermal throttling.
  - A client warning badge will appear if the loaded model exceeds 200,000 triangles.
- **Pivot Point & Origin:**
  - The model must be centered at `(0, 0, 0)` in local space.
  - The viewer automatically applies a bounding-box calculation (`THREE.Box3`) to center the piece and auto-fit camera distance, but an accurate origin ensures rotation pivots around the jewel's visual center.
- **Orientation:**
  - Standard GLTF convention: **+Y is UP**, **+Z is FRONT**.

### 2.3 Textures & Materials
- **PBR Workflow:** Standard PBR Metallic-Roughness workflow (`MeshStandardMaterial` / `MeshPhysicalMaterial`).
- **Texture Resolutions:**
  - Maximum dimension: **2048 × 2048 pixels** (2K).
  - Recommended dimension: **1024 × 1024 pixels** (1K) for mobile AR optimization.
  - Textures larger than 2048px will trigger an optimization warning.
- **DRACO Geometry Compression:**
  - Models compressed with DRACO (`KHR_draco_mesh_compression`) are natively decoded via the integrated WebAssembly DRACO loader. DRACO typically reduces file size by 70–85%.

### 2.4 Dynamic Metal Switching Convention
The platform provides instant metal switching (18k Yellow Gold, Silver/Platinum, Rose Gold). To ensure your custom model responds to metal switching while preserving gemstones:

1. **Metal Meshes:**
   - The material name assigned to precious metals MUST contain one of the following lowercase keywords:
     - `metal`
     - `gold`
     - `silver`
   - *Example material names:* `Metal_YellowGold`, `gold_base`, `ring_silver_band`.
2. **Gemstones & Enamel:**
   - Gemstones, diamonds, pearls, or colored enamels MUST use a distinct material name that does NOT contain "metal", "gold", or "silver".
   - *Example material names:* `Diamond_Cut`, `Gem_Ruby`, `Emerald_Pave`, `Pearl_Center`.
   - The turntable engine will preserve your refractive crystal/diamond shaders when the customer switches metal finishes.

---

## 3. 360° Photo Sequence Specifications (Fallback)

For vendors who do not yet possess 3D CAD or photogrammetry assets, the system accepts a high-resolution turntable photograph sequence.

### 3.1 Image Count & Angles
- **Required Quantity:** Exactly **24 to 36 images**.
  - 24 frames = 15° rotation per frame.
  - 36 frames = 10° rotation per frame (smoothest rotation).
- Uploads with fewer than 24 or more than 36 images are rejected to guarantee turntable consistency.

### 3.2 Dimensions & Uniformity
- **Formats:** JPG, PNG, or WebP.
- **Max File Size:** 5 MB per image.
- **Resolution Matching:** **All frames in the sequence must share the exact same pixel dimensions** (e.g. all 1200×1200 px). The validator inspects the width and height of every image and will reject mismatched frames.

### 3.3 Natural File Naming
The client sorts images using natural alphanumeric ordering. Name files sequentially:
```text
product_01.jpg
product_02.jpg
...
product_36.jpg
```
*(Natural sort ensures `product_10.jpg` correctly follows `product_9.jpg` rather than `product_1.jpg`).*

### 3.4 Studio Photography Guidelines
- Place jewellery on an automated revolving turntable with centered alignment.
- Lock camera exposure, white balance, and manual focus so brightness does not flicker between frames.
- Use diffused white softbox lighting to minimize harsh hot spots on polished metals.
- A clean, isolated background (pure white `#FFFFFF` or alpha transparent PNG) delivers the best visual presentation.

---

## 4. Security & Server-Side Validation Pipeline

To protect the platform against malicious uploads or corrupted files:

1. **Magic Header Inspection:**
   - `.glb` uploads are read into a memory buffer and the first 4 bytes are inspected for the mandatory ASCII glTF magic number: `0x67 0x6C 0x54 0x46` (`glTF` in little-endian `0x46546C67`).
   - Renamed executables (`.exe`, `.dll`, `.sh`, `.pdf`) renamed to `.glb` are immediately blocked.
2. **Sanitized Storage:**
   - The original filename is discarded during server persistence. A cryptographically secure random UUID (`crypto.randomUUID()`) is assigned to prevent path traversal and collision attacks.
3. **Local Object URLs for Instant Interactivity:**
   - The client creates a temporary `URL.createObjectURL(file)` so the user can interactively test the 3D turntable viewer and verify metal switching before committing the item to their catalog.
   - The item is then registered into IndexedDB for persistent catalog storage.

---

## 5. 3D Scanning & AI Photogrammetry Service

If you only possess raw catalog images or non-standard angle shots, contact our concierge 3D team:
- **Automated Photogrammetry:** Convert 24–36 studio photos into a textured 3D `.glb` mesh.
- **Background Separation:** High-accuracy boundary segmentation for clean jewellery silhouettes.
- **Jewellery CAD Retopology:** Optimization of dense CAD models down to the <200K triangle AR budget.
