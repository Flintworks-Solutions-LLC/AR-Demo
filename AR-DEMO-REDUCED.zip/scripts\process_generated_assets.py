import os
from PIL import Image
import numpy as np

images = [
    (r"C:\Users\KIRAN\.gemini\antigravity-ide\brain\67cb87b9-4d39-4ea1-b430-9426bdd3326c\gold_nose_stud_1793074493273.jpg", r"public\catalog\nose_ring\gold_nose_ring_04.png"),
    (r"C:\Users\KIRAN\.gemini\antigravity-ide\brain\67cb87b9-4d39-4ea1-b430-9426bdd3326c\gold_pearl_stud_1793074574707.jpg", r"public\catalog\nose_ring\gold_nose_ring_02.png"),
    (r"C:\Users\KIRAN\.gemini\antigravity-ide\brain\67cb87b9-4d39-4ea1-b430-9426bdd3326c\gold_nose_hoop_1793074608631.jpg", r"public\catalog\nose_ring\gold_nose_ring_05.png"),
]

for src, dst in images:
    if not os.path.exists(src):
        print(f"Not found: {src}")
        continue
    img = Image.open(src).convert("RGBA")
    arr = np.array(img, dtype=np.float32)
    
    # White background removal
    # Check brightness / distance from pure white (255, 255, 255)
    diff = np.sqrt(np.sum((255.0 - arr[..., :3])**2, axis=-1))
    
    # Smooth alpha transition between diff=15 and diff=45
    alpha = np.clip((diff - 15.0) / 30.0, 0.0, 1.0) * 255.0
    arr[..., 3] = alpha
    
    out = Image.fromarray(arr.astype(np.uint8))
    # Crop to bounding box with padding
    bbox = out.getbbox()
    if bbox:
        out = out.crop(bbox)
        # Pad to square
        w, h = out.size
        dim = max(w, h) + 40
        padded = Image.new("RGBA", (dim, dim), (0, 0, 0, 0))
        padded.paste(out, ((dim - w) // 2, (dim - h) // 2))
        out = padded.resize((512, 512), Image.Resampling.LANCZOS)
    
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    out.save(dst, "PNG")
    print(f"Saved: {dst}")
