#!/usr/bin/env node
/**
 * scripts/fetch-catalog.mjs
 * Downloads images from Hugging Face dataset Tarunhugging/ai-tool-pool-jewelry-vision
 * for folders Necklace, Earrings, Ring, Bracelet via datasets-server API & HF tree.
 * Filters by yellow/gold dominant hue.
 * Runs background removal with rembg matting model.
 * Produces transparent PNGs in public/catalog/<category>/ and public/catalog/catalog.json.
 */

import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');
const PUBLIC_DIR = path.join(ROOT_DIR, 'public');
const CATALOG_DIR = path.join(PUBLIC_DIR, 'catalog');
const TEMP_DIR = path.join(ROOT_DIR, '.cache_temp_catalog');

const TARGET_PER_CATEGORY = 16; // 12 to 20 per category

const CATEGORIES = [
  {
    folder: 'Necklace',
    catalogId: 'necklace',
    subdirs: ['necklace'],
    namePrefix: 'Gold Necklace',
    luxNames: [
      'Royal Kundan Choker', 'Temple Heritage Necklace', '22K Gold Filigree Collar',
      'Emerald Bloom Gold Necklace', 'Classic Gold Bead Mala', 'Floral Cascade Gold Necklace',
      'Artisan Gold Rope Chain', 'Imperial Queen Gold Choker', 'Polki Pendant Gold Chain',
      'Maharani Gold Hasli', 'Celestial Gold Layered Chain', 'Peacock Crest Gold Necklace',
      'Vintage Gold Medallion', 'Contemporary Sleek Gold Choker'
    ],
    anchor: { x: 0.5, y: 0.0 },
    widthRatio: 0.8,
    yOffset: 0.0,
    scaleFactor: 1.0,
    priceBase: 125000
  },
  {
    folder: 'Earrings',
    catalogId: 'earrings',
    subdirs: ['earrings'],
    namePrefix: 'Gold Earrings',
    luxNames: [
      'Temple Gold Jhumka', 'Gold Chandbali Drops', 'Classic Diamond Studs',
      'Floral Gold Danglers', 'Royal Pearl Drop Earrings', 'Geometric Gold Hoops',
      'Heritage Gold Bali', 'Cascading Dewdrop Earrings', 'Filigree Chandelier Earrings',
      'Solitaire Halo Studs', 'Lotus Motif Gold Drops', 'Art Deco Gold Danglers',
      'Traditional Gold Jhumki', 'Sleek Teardrop Gold Earrings'
    ],
    anchor: { x: 0.5, y: 0.1 },
    widthRatio: 0.18,
    yOffset: 0.0,
    scaleFactor: 0.14,
    priceBase: 48000
  },
  {
    folder: 'Ring',
    catalogId: 'finger_ring',
    subdirs: ['finger_ring', 'ring'],
    namePrefix: 'Gold Ring',
    luxNames: [
      'Solitaire Diamond Ring', 'Royal Crown Gold Band', 'Floral Cluster Diamond Ring',
      'Vintage Signet Gold Ring', 'Infinity Twisted Gold Ring', 'Pavé Eternity Diamond Band',
      'Emerald Cut Gold Ring', 'Heritage Navratna Ring', 'Three-Stone Trilogy Ring',
      'Cathedral Diamond Solitaire', 'Sleek 22K Gold Band', 'Marquise Diamond Gold Ring',
      'Artisanal Braided Gold Ring', 'Contemporary Tension Ring'
    ],
    anchor: { x: 0.5, y: 0.5 },
    widthRatio: 0.22,
    yOffset: 0.0,
    scaleFactor: 0.22,
    priceBase: 35000
  },
  {
    folder: 'Bracelet',
    catalogId: 'bangles',
    subdirs: ['bangles', 'bracelet'],
    namePrefix: 'Gold Bracelet',
    luxNames: [
      'Royal Gold Kada', 'Filigree Bangle Bracelet', '22K Gold Link Chain Bracelet',
      'Temple Carved Gold Bangle', 'Diamond Tennis Bracelet', 'Twisted Wire Gold Kada',
      'Peacock Motif Gold Bangle', 'Classic Sleek Gold Cuff', 'Heritage Meenakari Bangle',
      'Embossed Floral Gold Kada', 'Charm Link Gold Bracelet', 'Geometric Open Gold Cuff',
      'Twin Serpent Gold Kada', 'Eternity Pavé Gold Bangle'
    ],
    anchor: { x: 0.5, y: 0.5 },
    widthRatio: 0.95,
    yOffset: 0.0,
    scaleFactor: 0.95,
    priceBase: 88000
  }
];

// Ensure output dirs exist
fs.mkdirSync(TEMP_DIR, { recursive: true });
fs.mkdirSync(CATALOG_DIR, { recursive: true });
for (const cat of CATEGORIES) {
  for (const s of cat.subdirs) {
    fs.mkdirSync(path.join(CATALOG_DIR, s), { recursive: true });
  }
}

class PythonMatteWorker {
  constructor() {
    this.process = null;
    this.callbacks = [];
  }

  async start() {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(__dirname, 'matte_worker.py');
      this.process = spawn('python', [scriptPath], {
        stdio: ['pipe', 'pipe', 'inherit'],
      });

      let buffer = '';
      this.process.stdout.on('data', (chunk) => {
        buffer += chunk.toString();
        const lines = buffer.split('\n');
        buffer = lines.pop(); // keep remainder
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          const cb = this.callbacks.shift();
          if (cb) {
            try {
              cb.resolve(JSON.parse(trimmed));
            } catch (err) {
              cb.reject(err);
            }
          }
        }
      });

      this.process.on('error', reject);
      this.process.on('exit', (code) => {
        if (code !== 0) {
          console.error(`Python worker exited with code ${code}`);
        }
      });

      // Warm up
      resolve();
    });
  }

  async processImage(inputPath, outputPath, minGoldRatio = 0.10) {
    return new Promise((resolve, reject) => {
      this.callbacks.push({ resolve, reject });
      const req = JSON.stringify({ inputPath, outputPath, minGoldRatio }) + '\n';
      this.process.stdin.write(req);
    });
  }

  close() {
    if (this.process) {
      this.process.stdin.end();
      this.process.kill();
    }
  }
}

async function fetchJSON(url) {
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (AR-Jewellery-TryOn)' } });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
  return res.json();
}

async function downloadBuffer(url) {
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (AR-Jewellery-TryOn)' } });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
  const ab = await res.arrayBuffer();
  return Buffer.from(ab);
}

async function getCandidateUrlsForCategory(folder) {
  const urls = [];
  // 1. Try HF tree endpoint for the folder
  try {
    const treeUrl = `https://huggingface.co/api/datasets/Tarunhugging/ai-tool-pool-jewelry-vision/tree/main/train/${folder}`;
    const files = await fetchJSON(treeUrl);
    if (Array.isArray(files)) {
      for (const f of files) {
        if (f.type === 'file' && (f.path.endsWith('.jpg') || f.path.endsWith('.png') || f.path.endsWith('.jpeg'))) {
          urls.push(`https://huggingface.co/datasets/Tarunhugging/ai-tool-pool-jewelry-vision/resolve/main/${f.path}`);
        }
      }
    }
  } catch (err) {
    console.warn(`[HF tree warning] Could not list ${folder}:`, err.message);
  }

  // 2. Also try datasets-server API rows
  try {
    const labelMap = { Bracelet: 0, Earrings: 1, Necklace: 2, Ring: 4 };
    const targetLabel = labelMap[folder];
    if (targetLabel !== undefined) {
      const offsets = [0, 100, 200, 500, 1000, 1500, 2000, 2500, 3000, 3500];
      for (const off of offsets) {
        if (urls.length >= 80) break;
        try {
          const rowsUrl = `https://datasets-server.huggingface.co/rows?dataset=Tarunhugging/ai-tool-pool-jewelry-vision&config=default&split=train&offset=${off}&length=100`;
          const data = await fetchJSON(rowsUrl);
          if (data.rows) {
            for (const r of data.rows) {
              if (r.row?.label === targetLabel && r.row?.image?.src) {
                urls.push(r.row.image.src);
              }
            }
          }
        } catch {
          // ignore page errors
        }
      }
    }
  } catch (err) {
    console.warn(`[datasets-server warning] Error for ${folder}:`, err.message);
  }

  return urls;
}

async function main() {
  console.log('💎 Starting Real Catalog Data Fetcher & Matting Pipeline...');
  const worker = new PythonMatteWorker();
  await worker.start();

  const catalogOutput = {
    categories: [],
    items: []
  };

  for (const cat of CATEGORIES) {
    console.log(`\n📂 Processing category: ${cat.folder} (targeting ${TARGET_PER_CATEGORY} items)...`);
    const candidates = await getCandidateUrlsForCategory(cat.folder);
    console.log(`   Found ${candidates.length} candidate images for ${cat.folder}`);

    const acceptedItems = [];
    const seenHashes = new Set();
    let candidateIdx = 0;

    while (acceptedItems.length < TARGET_PER_CATEGORY && candidateIdx < candidates.length) {
      const candidateUrl = candidates[candidateIdx++];
      const tempPath = path.join(TEMP_DIR, `temp_${cat.catalogId}_${candidateIdx}.jpg`);
      const itemNum = acceptedItems.length + 1;
      const primarySubdir = cat.subdirs[0];
      const targetFilename = `gold_${cat.catalogId}_${String(itemNum).padStart(2, '0')}.png`;
      const targetOutPath = path.join(CATALOG_DIR, primarySubdir, targetFilename);

      try {
        const buf = await downloadBuffer(candidateUrl);
        fs.writeFileSync(tempPath, buf);

        const res = await worker.processImage(tempPath, targetOutPath, 0.12);
        fs.unlinkSync(tempPath);

        if (res.success && res.hash) {
          if (seenHashes.has(res.hash)) {
            console.log(`   [Duplicate] Item shares hash ${res.hash.slice(0, 8)}, skipping...`);
            fs.unlinkSync(targetOutPath);
            continue;
          }

          seenHashes.add(res.hash);

          // Copy to alias subdirs if any (e.g. ring/ -> finger_ring/, bracelet/ -> bangles/)
          for (let i = 1; i < cat.subdirs.length; i++) {
            const aliasPath = path.join(CATALOG_DIR, cat.subdirs[i], targetFilename);
            fs.copyFileSync(targetOutPath, aliasPath);
          }

          const luxName = cat.luxNames[acceptedItems.length] || `${cat.namePrefix} #${itemNum}`;
          const price = `₹${(cat.priceBase + itemNum * 3500).toLocaleString('en-IN')}`;

          const itemObj = {
            id: `${cat.catalogId}_${itemNum}`,
            name: luxName,
            category: cat.catalogId,
            src: `/catalog/${primarySubdir}/${targetFilename}`,
            anchor: cat.anchor,
            widthRatio: cat.widthRatio,
            yOffset: cat.yOffset,
            scaleFactor: cat.scaleFactor,
            imageHash: res.hash,
            goldRatio: res.goldRatio,
            price: price,
            type: cat.catalogId === 'necklace' ? (itemNum % 2 === 0 ? 'choker' : 'long') : cat.catalogId,
          };

          acceptedItems.push(itemObj);
          console.log(`   ✓ [${acceptedItems.length}/${TARGET_PER_CATEGORY}] Kept "${luxName}" (gold ratio: ${res.goldRatio})`);
        } else {
          // console.log(`   ✗ Skipped: ${res.reason || res.error}`);
        }
      } catch (err) {
        // Candidate failed, move to next
      }
    }

    catalogOutput.categories.push({
      id: cat.catalogId,
      name: cat.folder,
      items: acceptedItems
    });
    catalogOutput.items.push(...acceptedItems);
  }

  worker.close();

  // Write public/catalog/catalog.json
  const catalogJsonPath = path.join(CATALOG_DIR, 'catalog.json');
  fs.writeFileSync(catalogJsonPath, JSON.stringify(catalogOutput, null, 2), 'utf-8');
  console.log(`\n🎉 Success! Generated ${catalogJsonPath} with ${catalogOutput.items.length} items total.`);

  // Cleanup temp dir
  try {
    fs.rmSync(TEMP_DIR, { recursive: true, force: true });
  } catch {}
}

main().catch((err) => {
  console.error('Fatal error in fetch-catalog:', err);
  process.exit(1);
});
