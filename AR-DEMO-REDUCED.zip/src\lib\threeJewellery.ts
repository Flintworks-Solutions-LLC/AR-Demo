import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OneEuroFilter } from "@/lib/jewelleryMath";
import { JewelleryItem } from "@/config/jewellery.config";
import { getJewelConfigById, buildBracelet, buildRing } from "@/jewels";

export type MetalType = "gold" | "silver" | "rose_gold";

export const METAL_PROPERTIES: Record<MetalType, { color: number; roughness: number; metalness: number }> = {
  gold: { color: 0xd4af37, roughness: 0.18, metalness: 1.0 },
  silver: { color: 0xc0c0c0, roughness: 0.22, metalness: 1.0 },
  rose_gold: { color: 0xb76e79, roughness: 0.20, metalness: 1.0 },
};

const METAL_COLORS: Record<MetalType, number> = {
  gold: 0xd4af37,
  silver: 0xc0c0c0,
  rose_gold: 0xb76e79,
};

function getMaterialColor(material: THREE.Material): THREE.Color | null {
  return "color" in material && material.color instanceof THREE.Color ? material.color : null;
}

export interface HandLandmark3D {
  x: number;
  y: number;
  z: number;
}

export interface BangleDebugInfo {
  center: THREE.Vector3;
  forearmDir: THREE.Vector3;
  wristShift: number;
  radius: number;
  occluderRadius: number;
  occluderLength: number;
}

export interface RingDebugInfo {
  position: THREE.Vector3;
  fingerAxis: THREE.Vector3;
  topDir: THREE.Vector3;
  palmNormal: THREE.Vector3;
  isBackOfHand: boolean;
  handedness: string;
  fingerWidth: number;
}

export class ThreeJewelleryManager {
  private canvas: HTMLCanvasElement;
  private scene: THREE.Scene;
  private camera: THREE.OrthographicCamera;
  private renderer: THREE.WebGLRenderer;
  private onAssetLoaded?: (productId: string, url: string) => void;
  private onAssetError?: (productId: string, url: string) => void;

  // Gold jewellery material (reused across meshes)
  private jewelMaterial: THREE.MeshPhysicalMaterial;
  private gemMaterial: THREE.MeshPhysicalMaterial;
  private occluderMaterial: THREE.MeshBasicMaterial;
  private wireframeMaterial: THREE.MeshBasicMaterial;

  // Bangle objects
  private bangleGroup: THREE.Group;
  private bangleOccluder: THREE.Mesh;
  private bangleDebugWireframe: THREE.Mesh;
  private bangleTemplate: THREE.Group | THREE.Mesh | null = null;

  // Ring objects
  private ringGroup: THREE.Group;
  private ringOccluder: THREE.Mesh;
  private ringDebugWireframe: THREE.Mesh;
  private ringTemplate: THREE.Group | null = null;
  private is2DRing = false;

  // Adaptive smoothing filters for finger ring
  private ringFilterX = new OneEuroFilter(0.8, 0.015, 1.0);
  private ringFilterY = new OneEuroFilter(0.8, 0.015, 1.0);
  private ringFilterZ = new OneEuroFilter(0.8, 0.015, 1.0);
  private ringFilterScale = new OneEuroFilter(0.8, 0.015, 1.0);
  private ringPrevQuat = new THREE.Quaternion();
  private ringHasPrevQuat = false;

  // Fade management (150ms fade)
  private handDetected = false;
  private currentOpacity = 0;
  private lastTime = performance.now();

  // Debug info holders
  public bangleDebugInfo: BangleDebugInfo | null = null;
  public ringDebugInfo: RingDebugInfo | null = null;

  constructor(
    canvas: HTMLCanvasElement,
    onAssetLoaded?: (productId: string, url: string) => void,
    onAssetError?: (productId: string, url: string) => void
  ) {
    this.canvas = canvas;
    this.onAssetLoaded = onAssetLoaded;
    this.onAssetError = onAssetError;

    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      preserveDrawingBuffer: true,
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    // Scene & Orthographic Camera in pixel coordinates
    this.scene = new THREE.Scene();
    const w = canvas.width || 1280;
    const h = canvas.height || 720;
    this.camera = new THREE.OrthographicCamera(0, w, h, 0, -2000, 2000);
    this.camera.position.set(0, 0, 1000);
    this.camera.lookAt(0, 0, 0);

    // Environment Lighting via RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    pmremGenerator.compileEquirectangularShader();
    const roomEnv = new RoomEnvironment();
    this.scene.environment = pmremGenerator.fromScene(roomEnv).texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    // Directional light & ambient light
    const dirLight = new THREE.DirectionalLight(0xffffff, 2.0);
    dirLight.position.set(0.5, 1, 1).normalize();
    this.scene.add(dirLight);

    const ambLight = new THREE.AmbientLight(0xffffff, 0.4);
    this.scene.add(ambLight);

    // Materials
    const goldProps = METAL_PROPERTIES.gold;
    this.jewelMaterial = new THREE.MeshPhysicalMaterial({
      color: goldProps.color,
      metalness: goldProps.metalness,
      roughness: goldProps.roughness,
      envMapIntensity: 1.4,
      transparent: true,
      opacity: 0,
    });

    this.gemMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      metalness: 0.0,
      roughness: 0.0,
      transmission: 0.9,
      ior: 2.4,
      thickness: 0.5,
      envMapIntensity: 1.4,
      transparent: true,
      opacity: 0,
    });

    // Occluder: colorWrite = false, depthWrite = true, renderOrder = 0
    this.occluderMaterial = new THREE.MeshBasicMaterial({
      colorWrite: false,
      depthWrite: true,
      side: THREE.DoubleSide,
    });

    this.wireframeMaterial = new THREE.MeshBasicMaterial({
      color: 0x00ffff,
      wireframe: true,
      transparent: true,
      opacity: 0.5,
    });

    // Bangle Group
    this.bangleGroup = new THREE.Group();
    this.bangleGroup.renderOrder = 1;
    this.scene.add(this.bangleGroup);

    // Bangle Occluder (Cylinder along Y axis originally)
    const bangleCylGeom = new THREE.CylinderGeometry(1, 1, 1, 32);
    this.bangleOccluder = new THREE.Mesh(bangleCylGeom, this.occluderMaterial);
    this.bangleOccluder.renderOrder = 0;
    this.scene.add(this.bangleOccluder);

    this.bangleDebugWireframe = new THREE.Mesh(bangleCylGeom, this.wireframeMaterial);
    this.bangleDebugWireframe.renderOrder = 2;
    this.bangleDebugWireframe.visible = false;
    this.scene.add(this.bangleDebugWireframe);

    // Ring Group
    this.ringGroup = new THREE.Group();
    this.ringGroup.renderOrder = 1;
    this.scene.add(this.ringGroup);

    // Ring Occluder (Cylinder along Z/Y axis)
    const ringCylGeom = new THREE.CylinderGeometry(1, 1, 1, 32);
    this.ringOccluder = new THREE.Mesh(ringCylGeom, this.occluderMaterial);
    this.ringOccluder.renderOrder = 0;
    this.scene.add(this.ringOccluder);

    this.ringDebugWireframe = new THREE.Mesh(ringCylGeom, this.wireframeMaterial);
    this.ringDebugWireframe.renderOrder = 2;
    this.ringDebugWireframe.visible = false;
    this.scene.add(this.ringDebugWireframe);

  }

  public resize(w: number, h: number) {
    if (w <= 0 || h <= 0) return;
    this.canvas.width = w;
    this.canvas.height = h;
    this.camera.left = 0;
    this.camera.right = w;
    this.camera.top = h;
    this.camera.bottom = 0;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  private currentRingItem: JewelleryItem | null = null;
  private currentBangleItem: JewelleryItem | null = null;

  public setMetal(metal: MetalType) {
    const props = METAL_PROPERTIES[metal] || METAL_PROPERTIES.gold;
    this.jewelMaterial.color.setHex(props.color);
    this.jewelMaterial.metalness = props.metalness;
    this.jewelMaterial.roughness = props.roughness;
    this.jewelMaterial.envMapIntensity = 1.4;
    this.jewelMaterial.needsUpdate = true;
    if (this.currentRingItem) {
      this.setRingItem(this.currentRingItem);
    }
    if (this.currentBangleItem) {
      this.setBangleItem(this.currentBangleItem);
    }
  }

  public setItem(item: JewelleryItem, category: string) {
    if (category === "finger_ring" || item.category === "finger_ring") {
      this.setRingItem(item);
    } else if (category === "bangles" || item.category === "bangles") {
      this.setBangleItem(item);
    }
  }

  public async setRingItem(item: JewelleryItem) {
    this.currentRingItem = item;
    // Dispose previous template
    if (this.ringTemplate) {
      this.ringTemplate.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          mesh.geometry?.dispose();
        }
      });
      this.ringTemplate = null;
    }

    const currentMetal = this.getCurrentMetalName();
    const modelUrl = item.modelUrl;
    if (modelUrl) {
      try {
        const loader = new GLTFLoader();
        const gltf = await loader.loadAsync(modelUrl);
        const root = gltf.scene;
        if (
          this.currentRingItem?.id !== item.id ||
          this.currentRingItem?.modelUrl !== modelUrl ||
          this.getCurrentMetalName() !== currentMetal
        ) return;

        root.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) {
            const mesh = child as THREE.Mesh;
            const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
            materials.forEach((material) => {
              material.side = THREE.DoubleSide;
              if (!material.name.toLowerCase().includes("gem")) {
                getMaterialColor(material)?.multiply(new THREE.Color(METAL_COLORS[currentMetal]));
              }
              material.needsUpdate = true;
            });
          }
        });

        const box = new THREE.Box3().setFromObject(root);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z) || 1;
        root.position.sub(center);
        root.scale.multiplyScalar(1 / maxDim);
        this.ringTemplate = root;
        this.is2DRing = false;
        this.onAssetLoaded?.(item.id, modelUrl);
        return;
      } catch (err) {
        console.error("[ThreeJewellery] Failed loading GLB ring:", err);
        this.onAssetError?.(item.id, modelUrl);
        return;
      }
    }

    // 2. Catalog Parametric 3D Ring Model (Solitaire Cathedral, Halo, Trilogy, Signet, etc.)
    const config = getJewelConfigById(item.id);
    if (config) {
      try {
        const root = buildRing({ ...config, metalTone: currentMetal });
        if (
          this.currentRingItem?.id !== item.id ||
          this.getCurrentMetalName() !== currentMetal
        ) return;

        root.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) {
            const mesh = child as THREE.Mesh;
            const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
            materials.forEach((material) => {
              material.side = THREE.DoubleSide;
              material.needsUpdate = true;
            });
          }
        });

        const box = new THREE.Box3().setFromObject(root);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z) || 1;
        root.position.sub(center);
        root.scale.multiplyScalar(1 / maxDim);
        this.ringTemplate = root;
        this.is2DRing = false;
        this.onAssetLoaded?.(item.id, config.id);
        return;
      } catch (err) {
        console.warn("[ThreeJewellery] Could not build catalog 3D ring:", err);
      }
    }

    if (!item.src) {
      this.onAssetError?.(item.id, "");
      return;
    }

    try {
      const texture = await this.loadProductTexture(item.src);
      if (
        this.currentRingItem?.id !== item.id ||
        this.currentRingItem?.src !== item.src ||
        this.getCurrentMetalName() !== currentMetal
      ) {
        texture.dispose();
        return;
      }
      texture.colorSpace = THREE.SRGBColorSpace;
      const image = texture.image as HTMLImageElement;
      const aspect = (image.naturalHeight || image.height) / (image.naturalWidth || image.width);
      const material = new THREE.MeshBasicMaterial({
        map: texture,
        color: currentMetal === "gold" ? 0xffffff : currentMetal === "silver" ? 0xd8dce2 : 0xf0c3c0,
        transparent: true,
        alphaTest: 0.02,
        side: THREE.DoubleSide,
        depthWrite: false,
        depthTest: false,
      });
      const plane = new THREE.Mesh(new THREE.PlaneGeometry(1, aspect), material);
      plane.renderOrder = 999;
      this.ringTemplate = new THREE.Group();
      this.ringTemplate.add(plane);
      this.is2DRing = true;
      this.onAssetLoaded?.(item.id, item.src);
    } catch (err) {
      console.error("[ThreeJewellery] Failed loading ring asset:", err);
      this.onAssetError?.(item.id, item.src);
    }
  }

  public async setBangleItem(item: JewelleryItem) {
    this.currentBangleItem = item;
    if (this.bangleTemplate) {
      this.bangleTemplate.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          mesh.geometry?.dispose();
        }
      });
      this.bangleTemplate = null;
    }

    const currentMetal = this.getCurrentMetalName();
    const modelUrl = item.modelUrl;
    if (modelUrl) {
      try {
        const loader = new GLTFLoader();
        const gltf = await loader.loadAsync(modelUrl);
        const root = gltf.scene;
        if (
          this.currentBangleItem?.id !== item.id ||
          this.currentBangleItem?.modelUrl !== modelUrl ||
          this.getCurrentMetalName() !== currentMetal
        ) return;

        root.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) {
            const mesh = child as THREE.Mesh;
            const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
            materials.forEach((material) => {
              material.side = THREE.DoubleSide;
              if (!material.name.toLowerCase().includes("gem")) {
                getMaterialColor(material)?.multiply(new THREE.Color(METAL_COLORS[currentMetal]));
              }
              material.needsUpdate = true;
            });
          }
        });

        const box = new THREE.Box3().setFromObject(root);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDiameter = Math.max(size.x, size.y) || Math.max(size.x, size.z) || 1;
        root.position.sub(center);
        root.scale.multiplyScalar(1 / maxDiameter);

        this.bangleTemplate = root;
        this.onAssetLoaded?.(item.id, modelUrl);
        return;
      } catch (err) {
        console.error("[ThreeJewellery] Failed loading GLB bangle:", err);
        this.onAssetError?.(item.id, modelUrl);
        return;
      }
    }

    // 2. Catalog Parametric 3D Bracelet Model (Classic Polished Kada, Tennis Bangle, etc.)
    const config = getJewelConfigById(item.id);
    if (config) {
      try {
        const root = buildBracelet({ ...config, metalTone: currentMetal });
        if (
          this.currentBangleItem?.id !== item.id ||
          this.getCurrentMetalName() !== currentMetal
        ) return;

        root.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) {
            const mesh = child as THREE.Mesh;
            const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
            materials.forEach((material) => {
              material.side = THREE.DoubleSide;
              material.needsUpdate = true;
            });
          }
        });

        const box = new THREE.Box3().setFromObject(root);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDiameter = Math.max(size.x, size.y) || Math.max(size.x, size.z) || 1;
        root.position.sub(center);
        root.scale.multiplyScalar(1 / maxDiameter);

        this.bangleTemplate = root;
        this.onAssetLoaded?.(item.id, config.id);
        return;
      } catch (err) {
        console.warn("[ThreeJewellery] Could not build catalog 3D bracelet:", err);
      }
    }

    const imageUrl = item.src;
    if (imageUrl) {
      try {
        const group = await this.buildCustomImageBangle(imageUrl, currentMetal);
        if (
          this.currentBangleItem?.id !== item.id ||
          this.currentBangleItem?.src !== imageUrl ||
          this.getCurrentMetalName() !== currentMetal
        ) return;
        this.bangleTemplate = group;
        this.onAssetLoaded?.(item.id, imageUrl);
      } catch (err) {
        console.error("[ThreeJewellery] Failed loading bangle asset:", err);
        this.onAssetError?.(item.id, imageUrl);
      }
      return;
    }

    this.onAssetError?.(item.id, "");
  }

  private loadProductTexture(url: string): Promise<THREE.Texture> {
    return new Promise((resolve, reject) => {
      new THREE.TextureLoader().load(url, resolve, undefined, reject);
    });
  }

  /**
   * Builds a rich 3D bracelet wrapped around the wrist from a custom uploaded image/cutout.
   * Matches the active metal finish (Silver / Gold / Rose Gold).
   */
  private buildCustomImageBangle(imageUrl: string, metal: MetalType): Promise<THREE.Group> {
    return new Promise((resolve, reject) => {
      const group = new THREE.Group();
      group.name = "customImageBangle";

      const textureLoader = new THREE.TextureLoader();
      textureLoader.load(
        imageUrl,
        (texture) => {
          texture.colorSpace = THREE.SRGBColorSpace;
          texture.wrapS = THREE.RepeatWrapping;
          texture.wrapT = THREE.ClampToEdgeWrapping;

          const isSilver = metal === "silver";
          const isRose = metal === "rose_gold";

          // 1. Curved outer cylindrical cuff band wrapping around the wrist (radius 0.465)
          // Open-ended cylinder with axis rotated to Z, enforcing min height >= 0.35 x width
          const image = texture.image as HTMLImageElement;
          const imgAspect = image ? (image.naturalHeight || image.height) / (image.naturalWidth || image.width) : 0.35;
          const cuffHeight = Math.max(0.20, Math.min(0.50, Math.max(0.35, imgAspect) * 0.45));

          const cylGeom = new THREE.CylinderGeometry(0.465, 0.465, cuffHeight, 64, 1, true);
          cylGeom.rotateX(Math.PI / 2);

          const cuffMat = new THREE.MeshPhysicalMaterial({
            map: texture,
            color: isSilver ? 0xd8dce2 : isRose ? 0xf0c3c0 : 0xffffff,
            metalness: 0.95,
            roughness: isSilver ? 0.22 : 0.18,
            transparent: true,
            alphaTest: 0.05,
            side: THREE.DoubleSide,
            envMapIntensity: 1.5,
          });
          const cuffMesh = new THREE.Mesh(cylGeom, cuffMat);
          group.add(cuffMesh);

          // 2. Annular face ring in XY plane so top-down and 3/4 camera angles see the full cutout loop
          const ringThickness = Math.max(0.08, cuffHeight * 0.45);
          const ringGeom = new THREE.RingGeometry(0.465 - ringThickness, 0.465, 64);
          const faceMat = new THREE.MeshPhysicalMaterial({
            map: texture,
            color: isSilver ? 0xd8dce2 : isRose ? 0xf0c3c0 : 0xffffff,
            transparent: true,
            alphaTest: 0.05,
            metalness: 0.9,
            roughness: 0.22,
            side: THREE.DoubleSide,
            envMapIntensity: 1.4,
          });
          const faceMesh = new THREE.Mesh(ringGeom, faceMat);
          group.add(faceMesh);

          resolve(group);
        },
        undefined,
        reject
      );
    });
  }

  private getCurrentMetalName(): "gold" | "silver" | "rose_gold" {
    const hex = this.jewelMaterial.color.getHex();
    if (hex === METAL_COLORS.silver) return "silver";
    if (hex === METAL_COLORS.rose_gold) return "rose_gold";
    return "gold";
  }

  /**
   * Convert landmark to Three.js Orthographic space:
   * Supports both canvas pixel landmarks (from toCanvas) and normalized landmarks.
   */
  public toSceneCoord(lm: { x: number; y: number; z: number }, w: number, h: number): THREE.Vector3 {
    // If coordinate is > 1.5, it is already mapped to canvas pixel space
    const px = Math.abs(lm.x) > 1.5 ? lm.x : lm.x * w;
    const py = Math.abs(lm.y) > 1.5 ? lm.y : lm.y * h;
    const pz = Math.abs(lm.z) > 1.5 ? lm.z : lm.z * w;
    return new THREE.Vector3(px, h - py, -pz);
  }

  /**
   * Update Bangles:
   * - forearm direction f = normalize(lm0 - lm9) (towards elbow)
   * - centre C = lm0 + f * (0.25 * |lm0 - lm9|)
   * - hole axis = f (quaternion.setFromUnitVectors(Z, f))
   * - outer diameter = 0.95 * |lm5 - lm17| * fit.scale
   * - occluder: invisible cylinder, radius = 0.40 * |lm5 - lm17|, length = 1.6 * |lm0 - lm9|
   * - stack: 1 / 2 / 4 / 6 along f
   */
  public updateBangles(
    rawLMs: HandLandmark3D[] | null,
    w: number,
    h: number,
    fit: { scale: number; offsetX: number; offsetY: number },
    stackCount: 1 | 2 | 4 | 6 = 2,
    wristShiftRatio = 0.25,
    showDebug = false
  ) {
    if (!rawLMs || rawLMs.length < 21) {
      this.handDetected = false;
      this.bangleDebugInfo = null;
      return;
    }

    this.handDetected = true;

    const lm0 = this.toSceneCoord(rawLMs[0], w, h);
    const lm5 = this.toSceneCoord(rawLMs[5], w, h);
    const lm9 = this.toSceneCoord(rawLMs[9], w, h);
    const lm17 = this.toSceneCoord(rawLMs[17], w, h);

    // Forearm direction f = normalize(lm0 - lm9) (points towards elbow)
    const f = new THREE.Vector3().subVectors(lm0, lm9);
    const d09 = f.length();
    if (d09 < 1e-4) return;
    f.normalize();

    // Centre C = lm0 + f * (wristShiftRatio * d09)
    const C = new THREE.Vector3().copy(lm0).addScaledVector(f, wristShiftRatio * d09);
    C.x += fit.offsetX;
    C.y -= fit.offsetY; // Inverted for Three.js Y-up

    // Palm width |lm5 - lm17|
    const palmW = lm5.distanceTo(lm17);
    const maxSafeDiameter = Math.min(w * 0.28, h * 0.28, 160);
    const minSafeDiameter = 20;
    // Anatomical forearm wrist diameter is ~0.54 * knuckle width
    const wristWidth = palmW * 0.54;
    const outerDiameter = Math.max(minSafeDiameter, Math.min(maxSafeDiameter, wristWidth * fit.scale));
    const bangleRadius = outerDiameter / 2;
    const bangleThickness = bangleRadius * 0.12;

    // Hole orientation quaternion (Torus hole is along Z: (0, 0, 1))
    const holeQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), f);

    // 1. Update Occluder Cylinder (CylinderGeometry default axis is along Y: (0, 1, 0))
    const occluderRadius = Math.max(8, Math.min(maxSafeDiameter * 0.42, 0.24 * palmW * fit.scale));
    const occluderLength = Math.min(h * 0.5, 1.4 * d09);
    const cylQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), f);

    this.bangleOccluder.scale.set(occluderRadius, occluderLength, occluderRadius);
    this.bangleOccluder.position.copy(C);
    this.bangleOccluder.position.z += 0.01;
    this.bangleOccluder.quaternion.copy(cylQuat);
    this.bangleOccluder.visible = true;

    if (showDebug) {
      this.bangleDebugWireframe.scale.copy(this.bangleOccluder.scale);
      this.bangleDebugWireframe.position.copy(C);
      this.bangleDebugWireframe.quaternion.copy(cylQuat);
      this.bangleDebugWireframe.visible = true;
    } else {
      this.bangleDebugWireframe.visible = false;
    }

    // 2. Clear previous stack copies and instantiate N bangles
    while (this.bangleGroup.children.length > 0) {
      this.bangleGroup.remove(this.bangleGroup.children[0]);
    }

    if (!this.bangleTemplate) return;

    const spacing = bangleThickness * 1.15;
    for (let i = 0; i < stackCount; i++) {
      const offset = (i - (stackCount - 1) / 2) * spacing;
      const bPos = new THREE.Vector3().copy(C).addScaledVector(f, offset);

      const bangleMesh = this.bangleTemplate.clone(true);
      // Unit template has outer diameter = 1, so scale by outerDiameter
      bangleMesh.scale.setScalar(outerDiameter);
      bangleMesh.position.copy(bPos);
      bangleMesh.quaternion.copy(holeQuat);

      this.bangleGroup.add(bangleMesh);
    }
    this.bangleGroup.visible = true;

    // Record debug info
    this.bangleDebugInfo = {
      center: C,
      forearmDir: f,
      wristShift: wristShiftRatio,
      radius: bangleRadius,
      occluderRadius,
      occluderLength,
    };
  }

  /**
   * Update Finger Ring:
   * - position = midpoint(lm13, lm14) (ring finger proximal phalanx)
   * - finger axis a = normalize(lm14 - lm13)
   * - fingerWidth = d13_14 * 0.27 * fit.scale
   * - stone always sits on dorsal side of finger
   * - when palm faces camera: occluder hides stone behind finger, showing sleek gold band
   */
  public updateRing(
    rawLMs: HandLandmark3D[] | null,
    handedness: string | undefined,
    w: number,
    h: number,
    fit: { scale: number; offsetX: number; offsetY: number },
    fingerWidthRatio = 0.42,
    showDebug = false
  ) {
    if (!rawLMs || rawLMs.length < 21) {
      this.handDetected = false;
      this.ringDebugInfo = null;
      this.ringHasPrevQuat = false;
      this.ringFilterX.reset();
      this.ringFilterY.reset();
      this.ringFilterZ.reset();
      this.ringFilterScale.reset();
      return;
    }

    this.handDetected = true;
    const now = performance.now();

    const lm0 = this.toSceneCoord(rawLMs[0], w, h);
    const lm5 = this.toSceneCoord(rawLMs[5], w, h);
    const lm9 = this.toSceneCoord(rawLMs[9], w, h);
    const lm13 = this.toSceneCoord(rawLMs[13], w, h);
    const lm14 = this.toSceneCoord(rawLMs[14], w, h);
    const lm17 = this.toSceneCoord(rawLMs[17], w, h);

    // Finger axis a = normalize(lm14 - lm13) (along the ring finger towards tip)
    const a = new THREE.Vector3().subVectors(lm14, lm13);
    const d13_14 = a.length();
    if (d13_14 < 1e-4) return;
    a.normalize();

    // 1. Position: proximal-phalanx midpoint.
    const rawPos = new THREE.Vector3().lerpVectors(lm13, lm14, 0.5);
    rawPos.x += fit.offsetX;
    rawPos.y -= fit.offsetY; // Inverted for Three.js Y-up

    const pos = new THREE.Vector3(
      this.ringFilterX.filter(rawPos.x, now),
      this.ringFilterY.filter(rawPos.y, now),
      this.ringFilterZ.filter(rawPos.z, now)
    );

    // Estimate finger width from adjacent MCP spacing because the hand model has no side-edge landmarks.
    const sideSpacing = Math.min(lm13.distanceTo(lm9), lm13.distanceTo(lm17));
    const estimatedFingerWidth = Math.max(
      14,
      (sideSpacing * 0.55 || d13_14 * 0.27) * 0.9 * fit.scale * (fingerWidthRatio / 0.42)
    );
    const fingerWidth = this.ringFilterScale.filter(estimatedFingerWidth, now);

    // 3. Palm normal from landmarks 0 (wrist), 5 (index MCP), 17 (pinky MCP)
    const v05 = new THREE.Vector3().subVectors(lm5, lm0);
    const v017 = new THREE.Vector3().subVectors(lm17, lm0);
    const normal3D = new THREE.Vector3().crossVectors(v05, v017).normalize();

    const isRight = handedness ? handedness.toLowerCase() === "right" : true;
    const cross2D = v05.x * v017.y - v05.y * v017.x;
    const isBackOfHand = isRight ? cross2D < 0 : cross2D > 0;

    // Gemstone always sits on the dorsal side of the finger (away from palm)
    const dorsalAwayFromPalm = isRight ? normal3D.clone().negate() : normal3D.clone();

    // Project away-from-palm vector onto plane orthogonal to finger axis a
    const nDotA = dorsalAwayFromPalm.dot(a);
    const topDir = new THREE.Vector3()
      .subVectors(dorsalAwayFromPalm, a.clone().multiplyScalar(nDotA))
      .normalize();
    if (!isBackOfHand) topDir.negate();

    // Side direction completes orthonormal basis (sideDir, topDir, a)
    const sideDir = new THREE.Vector3().crossVectors(topDir, a).normalize();

    // Basis matrix: X = sideDir, Y = topDir (stone direction), Z = a (finger axis / hole)
    const rotMatrix = new THREE.Matrix4().makeBasis(sideDir, topDir, a);
    const targetQuat = new THREE.Quaternion().setFromRotationMatrix(rotMatrix);

    if (!this.ringHasPrevQuat) {
      this.ringPrevQuat.copy(targetQuat);
      this.ringHasPrevQuat = true;
    } else {
      this.ringPrevQuat.slerp(targetQuat, 0.25);
    }
    const ringQuat = this.ringPrevQuat;

    // 4. Occluder Cylinder around finger (cylinder axis along Y: (0, 1, 0))
    // Hides the back half of the ring wrapping behind the finger
    const occluderRadius = (fingerWidth / 2) * 0.94;
    const occluderLength = d13_14 * 1.15;
    const cylQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), a);

    this.ringOccluder.scale.set(occluderRadius, occluderLength, occluderRadius);
    this.ringOccluder.position.copy(pos);
    this.ringOccluder.position.z += 0.01;
    this.ringOccluder.quaternion.copy(cylQuat);
    this.ringOccluder.visible = !this.is2DRing;

    if (showDebug && !this.is2DRing) {
      this.ringDebugWireframe.scale.copy(this.ringOccluder.scale);
      this.ringDebugWireframe.position.copy(pos);
      this.ringDebugWireframe.quaternion.copy(cylQuat);
      this.ringDebugWireframe.visible = true;
    } else {
      this.ringDebugWireframe.visible = false;
    }

    // 5. Update Ring Mesh
    while (this.ringGroup.children.length > 0) {
      this.ringGroup.remove(this.ringGroup.children[0]);
    }

    if (this.ringTemplate) {
      const ringMesh = this.ringTemplate.clone(true);
      if (this.is2DRing) {
        const ringScale = fingerWidth * 1.5;
        ringMesh.scale.set(ringScale, ringScale, 1);
        ringMesh.position.copy(pos);
        ringMesh.position.z += 5.0;
        // In 2D, the ring photo is upright. Rotate around Z to align with finger axis `a` on screen.
        const angleOnScreen = Math.atan2(a.y, a.x) - Math.PI / 2;
        ringMesh.rotation.set(0, 0, angleOnScreen);
        ringMesh.renderOrder = 999;
      } else {
        ringMesh.scale.setScalar(fingerWidth);
        ringMesh.position.copy(pos);
        ringMesh.position.addScaledVector(topDir, fingerWidth * 0.08);
        ringMesh.quaternion.copy(ringQuat);

        // Stone and setting are always kept visible in the model, properly oriented
        const settingObj = ringMesh.getObjectByName("ringSetting");
        if (settingObj) {
          settingObj.visible = true;
        }
      }

      this.ringGroup.add(ringMesh);
    }
    this.ringGroup.visible = true;

    // Record debug info
    this.ringDebugInfo = {
      position: pos,
      fingerAxis: a,
      topDir,
      palmNormal: dorsalAwayFromPalm,
      isBackOfHand,
      handedness: handedness || "Right",
      fingerWidth,
    };
  }

  /**
   * Hide meshes when not on hand categories
   */
  public hideAll() {
    this.bangleGroup.visible = false;
    this.bangleOccluder.visible = false;
    this.bangleDebugWireframe.visible = false;
    this.ringGroup.visible = false;
    this.ringOccluder.visible = false;
    this.ringDebugWireframe.visible = false;
    this.handDetected = false;
    this.bangleDebugInfo = null;
    this.ringDebugInfo = null;
    this.ringHasPrevQuat = false;
    this.ringFilterX.reset();
    this.ringFilterY.reset();
    this.ringFilterZ.reset();
    this.ringFilterScale.reset();
  }

  /**
   * Render frame with 150ms fade
   */
  public render() {
    const now = performance.now();
    const dt = Math.min(0.1, (now - this.lastTime) / 1000);
    this.lastTime = now;

    // 150ms smooth fade
    const targetOpacity = this.handDetected ? 1.0 : 0.0;
    const fadeSpeed = 1.0 / 0.15; // reach in 150ms
    if (this.currentOpacity < targetOpacity) {
      this.currentOpacity = Math.min(targetOpacity, this.currentOpacity + fadeSpeed * dt);
    } else if (this.currentOpacity > targetOpacity) {
      this.currentOpacity = Math.max(targetOpacity, this.currentOpacity - fadeSpeed * dt);
    }

    this.jewelMaterial.opacity = this.currentOpacity;
    this.gemMaterial.opacity = this.currentOpacity;

    const isVisible = this.currentOpacity > 0.01;
    this.bangleGroup.visible = isVisible && this.bangleGroup.visible;
    this.ringGroup.visible = isVisible && this.ringGroup.visible;

    this.renderer.render(this.scene, this.camera);
  }



  public dispose() {
    this.renderer.dispose();
  }
}
