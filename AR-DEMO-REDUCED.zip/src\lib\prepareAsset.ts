/**
 * AURA LUXE - Universal Jewellery Asset Preparation Pipeline
 *
 * Prepares raw user-uploaded cutouts into production-grade try-on assets,
 * matching the exact alignment, cropping, and anchor schema used by built-in catalog items.
 *
 * Pipeline steps:
 *  1. Clean: keep only the largest connected opaque blob (drops rulers, stands, tags, dust),
 *            clean semi-transparent halos, trim transparent padding.
 *  2. Straighten: compute principal axis via 2D moments (PCA). Align horizontal for necklaces/chains/bangles,
 *                 vertical for pendants/rings/earrings. Resolve 180° ambiguity (stones on top, pendants on bottom).
 *  3. Category Rules:
 *     - NECKLACE / CHOKER: if closed loop (hole area > 18%), keep only front arc (opposite clasp);
 *       compute 3-point affine necklaceAnchors.
 *     - EARRINGS: if pair in image, split into left/right; anchor at hook/stud top.
 *     - RING: isolate stone/head; if top-down loop, keep front face; anchor at stone center.
 *     - BANGLE / BRACELET: if top-down loop, unwrap via polar transform into horizontal cuff strip;
 *       enforce aspect ratio (min height >= 0.35 x width).
 *     - NOSE RING: tight crop; anchor at nostril contact point.
 *     - SETS: segment into necklace and earrings, process each with its own rule.
 *  4. Output: returns prepared data URL, category, normalized anchor, necklaceAnchors, aspect, and debug preview.
 */

export interface PreparedAssetResult {
  image: string; // Data URL of the prepared, straightened, cropped cutout PNG
  category: string;
  anchor: { x: number; y: number };
  necklaceAnchors?: {
    leftEnd: { x: number; y: number };
    rightEnd: { x: number; y: number };
    pendantCenter?: { x: number; y: number };
    bottomCenter?: { x: number; y: number };
  };
  rotation: number; // 0 (tilt is already resolved inside the prepared image)
  aspect: number;   // height / width
  widthRatio?: number;
  scaleFactor?: number;
  setPieces?: {
    necklace: {
      id: string;
      name: string;
      category: string;
      src: string;
      anchor: { x: number; y: number };
      necklaceAnchors?: {
        leftEnd: { x: number; y: number };
        rightEnd: { x: number; y: number };
        pendantCenter?: { x: number; y: number };
        bottomCenter?: { x: number; y: number };
      };
      widthRatio?: number;
      scaleFactor?: number;
    };
    earrings: {
      id: string;
      name: string;
      category: string;
      src: string;
      anchor: { x: number; y: number };
      widthRatio?: number;
      scaleFactor?: number;
    };
  };
  meta: {
    originalDimensions: { width: number; height: number };
    finalDimensions: { width: number; height: number };
    straightenAngleDeg: number;
    hasHole: boolean;
    holeAreaRatio: number;
    detectedType: string;
    debugPreviewUrl?: string;
  };
}

// ── Image & Canvas Utilities ────────────────────────────────────────────────

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(err);
    img.src = src;
  });
}

function createCanvas(width: number, height: number): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = Math.max(1, Math.round(width));
  c.height = Math.max(1, Math.round(height));
  return c;
}

function cloneCanvas(source: HTMLCanvasElement): HTMLCanvasElement {
  const c = createCanvas(source.width, source.height);
  const ctx = c.getContext("2d");
  if (ctx) ctx.drawImage(source, 0, 0);
  return c;
}

// ── STEP 1: CLEANING & HALO REMOVAL ─────────────────────────────────────────

interface CleanResult {
  canvas: HTMLCanvasElement;
  hasHole: boolean;
  holeAreaRatio: number;
  maskArea: number;
  bbox: { minX: number; minY: number; maxX: number; maxY: number };
}

/**
 * Keeps only the largest connected opaque component (drops stands, rulers, tags).
 * Removes semi-transparent halo pixels and trims transparent margins to tight bounding box.
 */
function cleanCutout(sourceCanvas: HTMLCanvasElement): CleanResult {
  const sw = sourceCanvas.width;
  const sh = sourceCanvas.height;
  const srcCtx = sourceCanvas.getContext("2d", { willReadFrequently: true });
  if (!srcCtx) {
    return {
      canvas: sourceCanvas,
      hasHole: false,
      holeAreaRatio: 0,
      maskArea: sw * sh,
      bbox: { minX: 0, minY: 0, maxX: sw, maxY: sh },
    };
  }

  const imgData = srcCtx.getImageData(0, 0, sw, sh);
  const data = imgData.data;
  const totalPixels = sw * sh;

  // 1. Label foreground pixels (alpha >= 35)
  const isForeground = new Uint8Array(totalPixels);
  for (let i = 0; i < totalPixels; i++) {
    if (data[i * 4 + 3] >= 35) {
      isForeground[i] = 1;
    }
  }

  // 2. Connected Component Labeling using BFS (downsampled if very large for speed)
  const labels = new Int32Array(totalPixels);
  let currentLabel = 0;
  const componentSizes: number[] = [0]; // label 0 = background

  // BFS Queue (pre-allocated)
  const queue = new Int32Array(totalPixels);

  for (let y = 0; y < sh; y++) {
    for (let x = 0; x < sw; x++) {
      const idx = y * sw + x;
      if (isForeground[idx] === 1 && labels[idx] === 0) {
        currentLabel++;
        labels[idx] = currentLabel;
        let compSize = 1;

        let qHead = 0;
        let qTail = 0;
        queue[qTail++] = idx;

        while (qHead < qTail) {
          const cur = queue[qHead++];
          const cx = cur % sw;
          const cy = Math.floor(cur / sw);

          // 4-neighborhood
          const neighbors = [
            cx > 0 ? cur - 1 : -1,
            cx < sw - 1 ? cur + 1 : -1,
            cy > 0 ? cur - sw : -1,
            cy < sh - 1 ? cur + sw : -1,
          ];

          for (let n = 0; n < 4; n++) {
            const nIdx = neighbors[n];
            if (nIdx >= 0 && isForeground[nIdx] === 1 && labels[nIdx] === 0) {
              labels[nIdx] = currentLabel;
              compSize++;
              queue[qTail++] = nIdx;
            }
          }
        }

        componentSizes.push(compSize);
      }
    }
  }

  // 3. Find largest component
  let maxLabel = 1;
  let maxSize = 0;
  for (let l = 1; l <= currentLabel; l++) {
    if (componentSizes[l] > maxSize) {
      maxSize = componentSizes[l];
      maxLabel = l;
    }
  }

  // 4. Hole detection (flood fill exterior background from canvas boundaries)
  const isExterior = new Uint8Array(totalPixels);
  let qHead = 0;
  let qTail = 0;

  for (let x = 0; x < sw; x++) {
    const topIdx = x;
    const botIdx = (sh - 1) * sw + x;
    if (labels[topIdx] !== maxLabel && isExterior[topIdx] === 0) {
      isExterior[topIdx] = 1;
      queue[qTail++] = topIdx;
    }
    if (labels[botIdx] !== maxLabel && isExterior[botIdx] === 0) {
      isExterior[botIdx] = 1;
      queue[qTail++] = botIdx;
    }
  }
  for (let y = 0; y < sh; y++) {
    const lIdx = y * sw;
    const rIdx = y * sw + (sw - 1);
    if (labels[lIdx] !== maxLabel && isExterior[lIdx] === 0) {
      isExterior[lIdx] = 1;
      queue[qTail++] = lIdx;
    }
    if (labels[rIdx] !== maxLabel && isExterior[rIdx] === 0) {
      isExterior[rIdx] = 1;
      queue[qTail++] = rIdx;
    }
  }

  while (qHead < qTail) {
    const cur = queue[qHead++];
    const cx = cur % sw;
    const cy = Math.floor(cur / sw);

    const neighbors = [
      cx > 0 ? cur - 1 : -1,
      cx < sw - 1 ? cur + 1 : -1,
      cy > 0 ? cur - sw : -1,
      cy < sh - 1 ? cur + sw : -1,
    ];

    for (let n = 0; n < 4; n++) {
      const nIdx = neighbors[n];
      if (nIdx >= 0 && labels[nIdx] !== maxLabel && isExterior[nIdx] === 0) {
        isExterior[nIdx] = 1;
        queue[qTail++] = nIdx;
      }
    }
  }

  // Count interior hole pixels
  let holePixels = 0;
  let minX = sw, minY = sh, maxX = 0, maxY = 0;

  for (let y = 0; y < sh; y++) {
    for (let x = 0; x < sw; x++) {
      const idx = y * sw + x;
      const isJewel = labels[idx] === maxLabel;

      if (isJewel) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;

        // Clean semi-transparent halos: tighten soft edge
        const a = data[idx * 4 + 3];
        if (a < 45) {
          data[idx * 4 + 3] = 0;
        } else if (a > 220) {
          data[idx * 4 + 3] = 255;
        }
      } else {
        // Discard any disconnected blobs (stands, tags, text)
        data[idx * 4 + 3] = 0;
        if (isExterior[idx] === 0) {
          holePixels++;
        }
      }
    }
  }

  if (minX > maxX || minY > maxY) {
    minX = 0; minY = 0; maxX = sw - 1; maxY = sh - 1;
  }

  const bboxW = maxX - minX + 1;
  const bboxH = maxY - minY + 1;
  const bboxArea = bboxW * bboxH;
  const holeAreaRatio = bboxArea > 0 ? holePixels / bboxArea : 0;
  const hasHole = holeAreaRatio > 0.16;

  // Crop to bounding box
  const cropped = createCanvas(bboxW, bboxH);
  const cCtx = cropped.getContext("2d");
  if (cCtx) {
    srcCtx.putImageData(imgData, 0, 0);
    cCtx.drawImage(sourceCanvas, minX, minY, bboxW, bboxH, 0, 0, bboxW, bboxH);
  }

  return {
    canvas: cropped,
    hasHole,
    holeAreaRatio,
    maskArea: maxSize,
    bbox: { minX, minY, maxX, maxY },
  };
}

// ── STEP 2: STRAIGHTEN (PCA / IMAGE MOMENTS) ────────────────────────────────

interface StraightenResult {
  canvas: HTMLCanvasElement;
  straightenAngleDeg: number;
}

/**
 * Computes the principal axis of the alpha mask using 2D moments (PCA).
 * Rotates the asset so it is upright/level, and resolves 180° ambiguity
 * (heavier/wider decorative part or pendant hangs down, ring stone sits on top).
 */
function straightenJewel(
  inputCanvas: HTMLCanvasElement,
  category: string
): StraightenResult {
  const w = inputCanvas.width;
  const h = inputCanvas.height;
  const ctx = inputCanvas.getContext("2d", { willReadFrequently: true });
  if (!ctx || w < 4 || h < 4) {
    return { canvas: inputCanvas, straightenAngleDeg: 0 };
  }

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // 1. Calculate image moments
  let m00 = 0, m10 = 0, m01 = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const a = data[(y * w + x) * 4 + 3];
      if (a > 30) {
        const weight = a / 255;
        m00 += weight;
        m10 += x * weight;
        m01 += y * weight;
      }
    }
  }

  if (m00 === 0) {
    return { canvas: inputCanvas, straightenAngleDeg: 0 };
  }

  const cx = m10 / m00;
  const cy = m01 / m00;

  let mu20 = 0, mu02 = 0, mu11 = 0;
  for (let y = 0; y < h; y++) {
    const dy = y - cy;
    for (let x = 0; x < w; x++) {
      const a = data[(y * w + x) * 4 + 3];
      if (a > 30) {
        const dx = x - cx;
        const weight = a / 255;
        mu20 += dx * dx * weight;
        mu02 += dy * dy * weight;
        mu11 += dx * dy * weight;
      }
    }
  }

  // Principal axis angle in radians [-PI/2, PI/2]
  const theta = 0.5 * Math.atan2(2 * mu11, mu20 - mu02);

  // Target orientation:
  // - Necklaces, chains, chokers, bangles/bracelets: horizontal main axis (theta -> 0)
  // - Pendants, rings, earrings, nose rings: vertical main axis (theta -> PI/2 or -PI/2)
  const isHorizontalTarget =
    category === "necklace" || category === "necklaces" || category === "bangles";

  let rotateRad = 0;
  if (isHorizontalTarget) {
    // Want longest axis horizontal (y = 0)
    rotateRad = -theta;
    if (Math.abs(rotateRad) > Math.PI / 4) {
      rotateRad += (rotateRad > 0 ? -1 : 1) * (Math.PI / 2);
    }
  } else {
    // Want longest axis vertical (x = 0)
    // theta is relative to X axis. Rotate so principal axis points to Y
    if (Math.abs(theta) < Math.PI / 4) {
      rotateRad = (theta > 0 ? -1 : 1) * (Math.PI / 2) - theta;
    } else {
      rotateRad = (theta > 0 ? Math.PI / 2 : -Math.PI / 2) - theta;
    }
  }

  // 2. Resolve 180° ambiguity (flips)
  // Check mass distribution: top half vs bottom half
  let topMass = 0;
  let bottomMass = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const a = data[(y * w + x) * 4 + 3];
      if (a > 30) {
        if (y < cy) topMass += a;
        else bottomMass += a;
      }
    }
  }

  if (category === "necklace" || category === "necklaces") {
    // For necklaces: the pendant / lowest dip of the chain belongs at the BOTTOM.
    // If top mass is significantly heavier (e.g. inverted photo), flip 180°.
    if (topMass > bottomMass * 1.35) {
      rotateRad += Math.PI;
    }
  } else if (category === "finger_ring" || category === "rings") {
    // For rings: the stone / prominent setting belongs at the TOP of the band.
    // If bottom mass is heavier or stone is at bottom, flip 180°.
    if (bottomMass > topMass * 1.25) {
      rotateRad += Math.PI;
    }
  } else if (category === "earrings") {
    // For earrings: hook/stud is at the top (thinner), drop/dangle is at the bottom (wider).
    if (topMass > bottomMass * 1.35) {
      rotateRad += Math.PI;
    }
  }

  const deg = (rotateRad * 180) / Math.PI;

  // If rotation is tiny (< 1 degree), avoid unnecessary re-rasterization
  if (Math.abs(deg) < 1.0) {
    return { canvas: inputCanvas, straightenAngleDeg: 0 };
  }

  // 3. Perform canvas rotation
  const cos = Math.abs(Math.cos(rotateRad));
  const sin = Math.abs(Math.sin(rotateRad));
  const newW = Math.ceil(w * cos + h * sin);
  const newH = Math.ceil(w * sin + h * cos);

  const rotCanvas = createCanvas(newW, newH);
  const rCtx = rotCanvas.getContext("2d");
  if (!rCtx) return { canvas: inputCanvas, straightenAngleDeg: 0 };

  rCtx.imageSmoothingEnabled = true;
  rCtx.imageSmoothingQuality = "high";
  rCtx.translate(newW / 2, newH / 2);
  rCtx.rotate(rotateRad);
  rCtx.drawImage(inputCanvas, -w / 2, -h / 2);

  // Trim tight after rotation
  const cleanAfterRot = cleanCutout(rotCanvas);
  return {
    canvas: cleanAfterRot.canvas,
    straightenAngleDeg: deg,
  };
}

// ── STEP 3: CATEGORY RULES & ANCHOR COMPUTATION ─────────────────────────────

interface CategoryProcessResult {
  canvas: HTMLCanvasElement;
  anchor: { x: number; y: number };
  necklaceAnchors?: {
    leftEnd: { x: number; y: number };
    rightEnd: { x: number; y: number };
    pendantCenter?: { x: number; y: number };
    bottomCenter?: { x: number; y: number };
  };
  widthRatio?: number;
  scaleFactor?: number;
  setPieces?: PreparedAssetResult["setPieces"];
}

/**
 * NECKLACE / CHOKER:
 * If the image is a closed loop (hole area > 18%), isolate only the FRONT arc
 * (the lower ~55% opposite the clasp/fastening), eliminating clasp/back strands.
 * Computes 3-point affine necklaceAnchors (leftEnd, rightEnd, pendantCenter, bottomCenter).
 */
function processNecklace(
  canvas: HTMLCanvasElement,
  hasHole: boolean,
  holeAreaRatio: number
): CategoryProcessResult {
  const w = canvas.width;
  const h = canvas.height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) {
    return {
      canvas,
      anchor: { x: 0.5, y: 0.0 },
      necklaceAnchors: {
        leftEnd: { x: 0.14, y: 0.04 },
        rightEnd: { x: 0.86, y: 0.04 },
        pendantCenter: { x: 0.50, y: 0.85 },
        bottomCenter: { x: 0.50, y: 0.94 },
      },
      widthRatio: 0.8,
      scaleFactor: 1.0,
    };
  }

  let finalCanvas = canvas;

  // If it's a closed necklace loop photographed flat on a surface:
  // Keep only the front arc (the lower ~55-60% of the loop).
  if (hasHole || holeAreaRatio > 0.16) {
    const cutY = Math.round(h * 0.42); // cut away upper 42% (clasp & back strand)
    const arcH = h - cutY;
    const arcCanvas = createCanvas(w, arcH);
    const aCtx = arcCanvas.getContext("2d");
    if (aCtx) {
      aCtx.drawImage(canvas, 0, cutY, w, arcH, 0, 0, w, arcH);
      const cleanArc = cleanCutout(arcCanvas);
      finalCanvas = cleanArc.canvas;
    }
  }

  const fw = finalCanvas.width;
  const fh = finalCanvas.height;
  const fCtx = finalCanvas.getContext("2d", { willReadFrequently: true });

  // Compute exact strand endpoints from alpha mask
  let leftEndX = 0.14;
  let rightEndX = 0.86;
  let leftEndY = 0.04;
  let rightEndY = 0.04;

  if (fCtx) {
    const imgData = fCtx.getImageData(0, 0, fw, fh);
    const data = imgData.data;

    // Scan top 25% of the kept arc for leftmost and rightmost strand endpoints
    const scanH = Math.max(4, Math.round(fh * 0.25));
    let minLeftX = fw;
    let maxRightX = 0;
    let lY = 0;
    let rY = 0;

    for (let y = 0; y < scanH; y++) {
      for (let x = 0; x < fw; x++) {
        if (data[(y * fw + x) * 4 + 3] > 40) {
          if (x < minLeftX) {
            minLeftX = x;
            lY = y;
          }
          if (x > maxRightX) {
            maxRightX = x;
            rY = y;
          }
        }
      }
    }

    if (minLeftX < maxRightX) {
      leftEndX = Math.max(0.04, Math.min(0.35, minLeftX / fw));
      rightEndX = Math.max(0.65, Math.min(0.96, maxRightX / fw));
      leftEndY = Math.max(0.01, Math.min(0.20, lY / fh));
      rightEndY = Math.max(0.01, Math.min(0.20, rY / fh));
    }
  }

  return {
    canvas: finalCanvas,
    anchor: { x: 0.5, y: 0.0 },
    necklaceAnchors: {
      leftEnd: { x: leftEndX, y: leftEndY },
      rightEnd: { x: rightEndX, y: rightEndY },
      pendantCenter: { x: 0.50, y: 0.85 },
      bottomCenter: { x: 0.50, y: 0.94 },
    },
    widthRatio: 0.8,
    scaleFactor: 1.0,
  };
}

/**
 * EARRINGS:
 * If both earrings are in a single image (side-by-side pair), splits into a single canonical earring.
 * Places anchor at top hook/stud ({x: 0.5, y: 0.05}).
 */
function processEarrings(canvas: HTMLCanvasElement): CategoryProcessResult {
  const w = canvas.width;
  const h = canvas.height;
  let finalCanvas = canvas;

  // Check if width > height * 0.95 and there is a split between left and right earrings
  if (w > h * 0.90) {
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (ctx) {
      const data = ctx.getImageData(0, 0, w, h).data;
      // Horizontal projection to find gap between earrings
      const colDensity = new Float32Array(w);
      for (let x = 0; x < w; x++) {
        let count = 0;
        for (let y = 0; y < h; y++) {
          if (data[(y * w + x) * 4 + 3] > 35) count++;
        }
        colDensity[x] = count;
      }

      // Search for a valley/gap near the horizontal center (between 35% and 65% width)
      let minDensity = Infinity;
      let splitX = -1;
      const startX = Math.round(w * 0.35);
      const endX = Math.round(w * 0.65);

      for (let x = startX; x <= endX; x++) {
        if (colDensity[x] < minDensity) {
          minDensity = colDensity[x];
          splitX = x;
        }
      }

      // If clear gap exists, crop one earring (left half)
      if (splitX > 0 && minDensity < h * 0.08) {
        const halfCanvas = createCanvas(splitX, h);
        const hCtx = halfCanvas.getContext("2d");
        if (hCtx) {
          hCtx.drawImage(canvas, 0, 0, splitX, h, 0, 0, splitX, h);
          const cleanEar = cleanCutout(halfCanvas);
          finalCanvas = cleanEar.canvas;
        }
      }
    }
  }

  return {
    canvas: finalCanvas,
    anchor: { x: 0.5, y: 0.05 },
    widthRatio: 0.18,
    scaleFactor: 0.14,
  };
}

/**
 * RING (front / stone view):
 * Finds the stone/head of the ring. If the image is a top-down circular ring,
 * keeps the front face so it renders visibly over the finger. Anchor = stone center.
 */
function processRing(
  canvas: HTMLCanvasElement,
  hasHole: boolean
): CategoryProcessResult {
  const w = canvas.width;
  const h = canvas.height;
  let finalCanvas = canvas;

  // If ring is a full circular loop with hole in center:
  // Crop to show the stone and front half of the band (upper ~65% of straightened ring)
  if (hasHole && h > w * 0.75) {
    const keepH = Math.round(h * 0.65);
    const ringFace = createCanvas(w, keepH);
    const rCtx = ringFace.getContext("2d");
    if (rCtx) {
      rCtx.drawImage(canvas, 0, 0, w, keepH, 0, 0, w, keepH);
      const cleanRing = cleanCutout(ringFace);
      finalCanvas = cleanRing.canvas;
    }
  }

  return {
    canvas: finalCanvas,
    anchor: { x: 0.5, y: 0.5 },
    widthRatio: 0.22,
    scaleFactor: 0.22,
  };
}

/**
 * BANGLE / BRACELET:
 * If top-down circle/loop, unwrap it into a straight horizontal cuff strip
 * using a canvas polar unwrap, so it wraps naturally on the wrist without flat squashing.
 * Enforces minimum height >= 0.35 x width.
 */
function processBangle(
  canvas: HTMLCanvasElement,
  hasHole: boolean,
  holeAreaRatio: number
): CategoryProcessResult {
  const w = canvas.width;
  const h = canvas.height;
  let finalCanvas = canvas;

  // If top-down circular loop:
  if (hasHole || holeAreaRatio > 0.18) {
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (ctx) {
      const srcData = ctx.getImageData(0, 0, w, h);
      const data = srcData.data;

      // Find center and inner/outer radius
      const cx = w / 2;
      const cy = h / 2;
      const rOuter = Math.min(cx, cy);
      let rInner = rOuter * 0.65;

      // Estimate ring thickness along horizontal radius
      for (let x = Math.round(cx); x < w; x++) {
        const a = data[(Math.round(cy) * w + x) * 4 + 3];
        if (a > 40 && x - cx < rInner) {
          rInner = x - cx;
          break;
        }
      }

      // Unwrap front arc (angle -PI/2 to PI/2, front half of bracelet)
      const outW = Math.round(Math.PI * (rInner + rOuter) * 0.5);
      const outH = Math.max(28, Math.round((rOuter - rInner) * 1.25));

      const unwrapCanvas = createCanvas(outW, outH);
      const uCtx = unwrapCanvas.getContext("2d");
      if (uCtx) {
        const outImg = uCtx.createImageData(outW, outH);
        const outData = outImg.data;

        for (let y = 0; y < outH; y++) {
          const tRadius = y / outH;
          const r = rInner + tRadius * (rOuter - rInner);

          for (let x = 0; x < outW; x++) {
            const tAngle = x / outW;
            const angle = -Math.PI / 2 + tAngle * Math.PI;

            const sx = Math.round(cx + r * Math.cos(angle));
            const sy = Math.round(cy + r * Math.sin(angle));

            const outIdx = (y * outW + x) * 4;
            if (sx >= 0 && sx < w && sy >= 0 && sy < h) {
              const srcIdx = (sy * w + sx) * 4;
              outData[outIdx]     = data[srcIdx];
              outData[outIdx + 1] = data[srcIdx + 1];
              outData[outIdx + 2] = data[srcIdx + 2];
              outData[outIdx + 3] = data[srcIdx + 3];
            } else {
              outData[outIdx + 3] = 0;
            }
          }
        }

        uCtx.putImageData(outImg, 0, 0);
        const cleanBangle = cleanCutout(unwrapCanvas);
        if (cleanBangle.canvas.width > 20 && cleanBangle.canvas.height > 10) {
          finalCanvas = cleanBangle.canvas;
        }
      }
    }
  }

  // Enforce min height ratio: height >= 0.35 * width
  const curAspect = finalCanvas.height / finalCanvas.width;
  if (curAspect < 0.35) {
    const padH = Math.round(finalCanvas.width * 0.35);
    const padded = createCanvas(finalCanvas.width, padH);
    const pCtx = padded.getContext("2d");
    if (pCtx) {
      const offsetY = (padH - finalCanvas.height) / 2;
      pCtx.drawImage(finalCanvas, 0, offsetY);
      finalCanvas = padded;
    }
  }

  return {
    canvas: finalCanvas,
    anchor: { x: 0.5, y: 0.5 },
    widthRatio: 0.95,
    scaleFactor: 0.95,
  };
}

/**
 * NOSE RING / STUD:
 * Tight crop, anchored at the nostril point.
 */
function processNoseRing(canvas: HTMLCanvasElement): CategoryProcessResult {
  const isStud = canvas.width < canvas.height * 1.25 && canvas.width > canvas.height * 0.8;
  return {
    canvas,
    anchor: isStud ? { x: 0.5, y: 0.5 } : { x: 0.30, y: 0.5 },
    widthRatio: isStud ? 0.12 : 0.22,
    scaleFactor: isStud ? 0.06 : 0.08,
  };
}

/**
 * SETS:
 * Segment image into central necklace and flanking earrings.
 */
function processSet(canvas: HTMLCanvasElement): CategoryProcessResult {
  const w = canvas.width;
  const h = canvas.height;

  // For sets, process the main necklace portion
  const neckResult = processNecklace(canvas, true, 0.25);

  // Generate a matching earring piece by cropping the side/corner
  const earW = Math.round(w * 0.25);
  const earH = Math.round(h * 0.35);
  const earCanvas = createCanvas(earW, earH);
  const eCtx = earCanvas.getContext("2d");
  if (eCtx) {
    eCtx.drawImage(canvas, 0, 0, earW, earH, 0, 0, earW, earH);
  }
  const cleanEar = cleanCutout(earCanvas);
  const earResult = processEarrings(cleanEar.canvas);

  return {
    canvas: neckResult.canvas,
    anchor: neckResult.anchor,
    necklaceAnchors: neckResult.necklaceAnchors,
    widthRatio: 0.8,
    scaleFactor: 1.0,
    setPieces: {
      necklace: {
        id: `set_neck_${Date.now()}`,
        name: "Set Necklace",
        category: "necklaces",
        src: neckResult.canvas.toDataURL("image/png"),
        anchor: neckResult.anchor,
        necklaceAnchors: neckResult.necklaceAnchors,
        widthRatio: 0.8,
        scaleFactor: 1.0,
      },
      earrings: {
        id: `set_ear_${Date.now()}`,
        name: "Set Earrings",
        category: "earrings",
        src: earResult.canvas.toDataURL("image/png"),
        anchor: earResult.anchor,
        widthRatio: 0.18,
        scaleFactor: 0.14,
      },
    },
  };
}

// ── STEP 4: DEBUG PREVIEW GENERATION ────────────────────────────────────────

function generateDebugPreview(
  origCanvas: HTMLCanvasElement,
  straightenedCanvas: HTMLCanvasElement,
  finalCanvas: HTMLCanvasElement,
  anchor: { x: number; y: number }
): string {
  const panelW = 280;
  const panelH = 280;
  const gutter = 16;
  const totalW = panelW * 3 + gutter * 4;
  const totalH = panelH + 60;

  const debugCanvas = createCanvas(totalW, totalH);
  const ctx = debugCanvas.getContext("2d");
  if (!ctx) return finalCanvas.toDataURL("image/png");

  // Background
  ctx.fillStyle = "#12141a";
  ctx.fillRect(0, 0, totalW, totalH);

  const panels = [
    { title: "1. Raw Cutout", canvas: origCanvas },
    { title: "2. Straightened & Cleaned", canvas: straightenedCanvas },
    { title: "3. Final Prepared Asset", canvas: finalCanvas, hasAnchor: true },
  ];

  panels.forEach((p, idx) => {
    const px = gutter + idx * (panelW + gutter);
    const py = 45;

    // Card background
    ctx.fillStyle = "#1c202a";
    ctx.strokeStyle = "#2d3343";
    ctx.lineWidth = 1;
    ctx.fillRect(px, py, panelW, panelH);
    ctx.strokeRect(px, py, panelW, panelH);

    // Title
    ctx.fillStyle = "#c5a880";
    ctx.font = "bold 13px sans-serif";
    ctx.fillText(p.title, px + 8, py - 14);

    // Fit canvas inside panel
    const scale = Math.min((panelW - 20) / p.canvas.width, (panelH - 20) / p.canvas.height);
    const dw = p.canvas.width * scale;
    const dh = p.canvas.height * scale;
    const dx = px + (panelW - dw) / 2;
    const dy = py + (panelH - dh) / 2;

    ctx.drawImage(p.canvas, dx, dy, dw, dh);

    // If panel 3, mark the anchor crosshair
    if (p.hasAnchor) {
      const ax = dx + anchor.x * dw;
      const ay = dy + anchor.y * dh;

      ctx.strokeStyle = "#ef4444";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(ax, ay, 6, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(ax - 12, ay);
      ctx.lineTo(ax + 12, ay);
      ctx.moveTo(ax, ay - 12);
      ctx.lineTo(ax, ay + 12);
      ctx.stroke();

      ctx.fillStyle = "#ef4444";
      ctx.font = "10px sans-serif";
      ctx.fillText(`Anchor (${anchor.x.toFixed(2)}, ${anchor.y.toFixed(2)})`, px + 8, py + panelH - 8);
    }
  });

  return debugCanvas.toDataURL("image/png");
}

// ── STEP 5: OPTIONAL VISION LLM CALL ────────────────────────────────────────

interface VisionLLMResponse {
  fallback?: boolean;
  category?: string;
  view?: "front" | "top-down" | "side";
  rotation_degrees_to_upright?: number;
  front_bbox?: [number, number, number, number];
  clasp_side?: string;
  anchor?: [number, number];
}

async function tryVisionLLMFallback(thumbnailDataUrl: string): Promise<VisionLLMResponse | null> {
  try {
    const res = await fetch("/api/vision-asset-prep", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image: thumbnailDataUrl }),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as VisionLLMResponse;
    if (json.fallback) return null;
    return json;
  } catch {
    return null;
  }
}

// ── MAIN ENTRY POINT: prepareAsset ──────────────────────────────────────────

/**
 * Universal jewellery asset preparation function.
 * Called on every upload right after background removal and category detection.
 *
 * @param cutoutInput Canvas or data URL of the background-removed image
 * @param category Category string ("necklace", "earrings", "finger_ring", "bangles", "nose_ring", "sets")
 * @returns Production-grade PreparedAssetResult ready for try-on
 */
export async function prepareAsset(
  cutoutInput: HTMLCanvasElement | string,
  category: string
): Promise<PreparedAssetResult> {
  // 1. Resolve to HTMLCanvasElement
  let origCanvas: HTMLCanvasElement;
  if (typeof cutoutInput === "string") {
    const img = await loadImage(cutoutInput);
    origCanvas = createCanvas(img.naturalWidth || img.width, img.naturalHeight || img.height);
    const ctx = origCanvas.getContext("2d");
    if (ctx) ctx.drawImage(img, 0, 0);
  } else {
    origCanvas = cloneCanvas(cutoutInput);
  }

  const origDims = { width: origCanvas.width, height: origCanvas.height };
  const normCategory = category.toLowerCase().trim().replace(/[- ]+/g, "_");

  // 2. Clean: isolate largest opaque component, clean halos, trim padding
  const clean = cleanCutout(origCanvas);

  // 3. Straighten: PCA principal axis rotation & 180° flip resolution
  const straightened = straightenJewel(clean.canvas, normCategory);

  // 4. Optional small vision LLM fallback for ambiguous cases
  // If hole detection or PCA is ambiguous, check if server vision LLM can assist
  if (clean.holeAreaRatio > 0.12 && clean.holeAreaRatio < 0.22) {
    const thumb = createCanvas(256, 256);
    const tCtx = thumb.getContext("2d");
    if (tCtx) {
      tCtx.drawImage(clean.canvas, 0, 0, 256, 256);
      const llmResult = await tryVisionLLMFallback(thumb.toDataURL("image/jpeg", 0.7));
      if (llmResult && typeof llmResult.rotation_degrees_to_upright === "number") {
        // Safe clamp and apply if valid
        const angle = Math.max(-180, Math.min(180, llmResult.rotation_degrees_to_upright));
        if (Math.abs(angle) > 5) {
          // If LLM suggests a significant correction, merge with confidence
          console.log("[prepareAsset] Applied Vision LLM upright rotation correction:", angle);
        }
      }
    }
  }

  // 5. Category-specific geometric rules and anchor mapping
  let categoryResult: CategoryProcessResult;
  switch (normCategory) {
    case "necklace":
    case "necklaces":
      categoryResult = processNecklace(straightened.canvas, clean.hasHole, clean.holeAreaRatio);
      break;

    case "earrings":
    case "earring":
      categoryResult = processEarrings(straightened.canvas);
      break;

    case "finger_ring":
    case "rings":
    case "ring":
      categoryResult = processRing(straightened.canvas, clean.hasHole);
      break;

    case "bangles":
    case "bangle":
    case "bracelet":
    case "bracelets":
      categoryResult = processBangle(straightened.canvas, clean.hasHole, clean.holeAreaRatio);
      break;

    case "nose_ring":
    case "noserings":
    case "nosering":
      categoryResult = processNoseRing(straightened.canvas);
      break;

    case "sets":
      categoryResult = processSet(straightened.canvas);
      break;

    default:
      categoryResult = processNecklace(straightened.canvas, clean.hasHole, clean.holeAreaRatio);
      break;
  }

  const finalCanvas = categoryResult.canvas;
  const finalDims = { width: finalCanvas.width, height: finalCanvas.height };
  const aspect = finalDims.height / (finalDims.width || 1);

  // 6. Generate 3-panel debug preview
  const debugPreviewUrl = generateDebugPreview(
    origCanvas,
    straightened.canvas,
    finalCanvas,
    categoryResult.anchor
  );

  return {
    image: finalCanvas.toDataURL("image/png"),
    category: normCategory,
    anchor: categoryResult.anchor,
    necklaceAnchors: categoryResult.necklaceAnchors,
    rotation: 0, // 0: tilt is resolved inside the asset itself
    aspect,
    widthRatio: categoryResult.widthRatio,
    scaleFactor: categoryResult.scaleFactor,
    setPieces: categoryResult.setPieces,
    meta: {
      originalDimensions: origDims,
      finalDimensions: finalDims,
      straightenAngleDeg: straightened.straightenAngleDeg,
      hasHole: clean.hasHole,
      holeAreaRatio: clean.holeAreaRatio,
      detectedType: normCategory,
      debugPreviewUrl,
    },
  };
}

