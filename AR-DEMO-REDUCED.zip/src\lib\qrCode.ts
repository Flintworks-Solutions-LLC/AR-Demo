/**
 * Lightweight, zero-dependency QR Code generator.
 * Generates an SVG path data string or 2D boolean grid for a given URL/text.
 */

// Simple Reed-Solomon polynomial math and QR Code generator for Version 2-4 (enough for URLs up to ~120 chars)
class QRByte {
  mode: number = 4; // 8-bit byte mode
  data: string;

  constructor(data: string) {
    this.data = data;
  }

  getLength(): number {
    return this.data.length;
  }

  write(buffer: QRBitBuffer): void {
    for (let i = 0; i < this.data.length; i++) {
      buffer.put(this.data.charCodeAt(i), 8);
    }
  }
}

class QRBitBuffer {
  buffer: number[] = [];
  length: number = 0;

  get(index: number): boolean {
    const bufIndex = Math.floor(index / 8);
    return ((this.buffer[bufIndex] >>> (7 - (index % 8))) & 1) === 1;
  }

  put(num: number, length: number): void {
    for (let i = 0; i < length; i++) {
      this.putBit(((num >>> (length - i - 1)) & 1) === 1);
    }
  }

  putBit(bit: boolean): void {
    const bufIndex = Math.floor(this.length / 8);
    if (this.buffer.length <= bufIndex) {
      this.buffer.push(0);
    }
    if (bit) {
      this.buffer[bufIndex] |= 0x80 >>> (this.length % 8);
    }
    this.length++;
  }
}

// Minimal Galois Field for QR Error Correction
const QRMath = {
  glog(n: number): number {
    if (n < 1) throw new Error("glog(" + n + ")");
    return LOG_TABLE[n];
  },
  gexp(n: number): number {
    while (n < 0) n += 255;
    while (n >= 255) n -= 255;
    return EXP_TABLE[n];
  },
};

const EXP_TABLE = new Array(256);
const LOG_TABLE = new Array(256);

for (let i = 0; i < 8; i++) EXP_TABLE[i] = 1 << i;
for (let i = 8; i < 256; i++) {
  EXP_TABLE[i] = EXP_TABLE[i - 4] ^ EXP_TABLE[i - 5] ^ EXP_TABLE[i - 6] ^ EXP_TABLE[i - 8];
}
for (let i = 0; i < 255; i++) {
  LOG_TABLE[EXP_TABLE[i]] = i;
}

class Polynomial {
  num: number[];
  constructor(num: number[], shift: number = 0) {
    let offset = 0;
    while (offset < num.length && num[offset] === 0) offset++;
    this.num = new Array(num.length - offset + shift);
    for (let i = 0; i < num.length - offset; i++) {
      this.num[i] = num[i + offset];
    }
    for (let i = num.length - offset; i < this.num.length; i++) {
      this.num[i] = 0;
    }
  }

  get(index: number): number {
    return this.num[index];
  }

  getLength(): number {
    return this.num.length;
  }

  multiply(e: Polynomial): Polynomial {
    const num = new Array(this.getLength() + e.getLength() - 1).fill(0);
    for (let i = 0; i < this.getLength(); i++) {
      for (let j = 0; j < e.getLength(); j++) {
        num[i + j] ^= QRMath.gexp(QRMath.glog(this.get(i)) + QRMath.glog(e.get(j)));
      }
    }
    return new Polynomial(num);
  }

  mod(e: Polynomial): Polynomial {
    if (this.getLength() - e.getLength() < 0) return this;
    const ratio = QRMath.glog(this.get(0)) - QRMath.glog(e.get(0));
    const num = new Array(this.getLength());
    for (let i = 0; i < this.getLength(); i++) num[i] = this.get(i);
    for (let i = 0; i < e.getLength(); i++) {
      num[i] ^= QRMath.gexp(QRMath.glog(e.get(i)) + ratio);
    }
    return new Polynomial(num).mod(e);
  }
}

function getErrorCorrectPolynomial(errorCorrectLength: number): Polynomial {
  let a = new Polynomial([1], 0);
  for (let i = 0; i < errorCorrectLength; i++) {
    a = a.multiply(new Polynomial([1, QRMath.gexp(i)], 0));
  }
  return a;
}

// QR Code Matrix generator (Version 3: 29x29, fits up to 70 ASCII chars at Medium EC)
export function generateQRCodeMatrix(text: string): boolean[][] {
  const version = text.length > 50 ? 4 : 3;
  const moduleCount = version * 4 + 17;
  const modules: (boolean | null)[][] = Array.from({ length: moduleCount }, () =>
    new Array(moduleCount).fill(null)
  );

  // Position detection patterns (7x7)
  function setupPositionProbePattern(row: number, col: number) {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        if (
          row + r < 0 ||
          moduleCount <= row + r ||
          col + c < 0 ||
          moduleCount <= col + c
        )
          continue;

        if (
          (0 <= r && r <= 6 && (c === 0 || c === 6)) ||
          (0 <= c && c <= 6 && (r === 0 || r === 6)) ||
          (2 <= r && r <= 4 && 2 <= c && c <= 4)
        ) {
          modules[row + r][col + c] = true;
        } else {
          modules[row + r][col + c] = false;
        }
      }
    }
  }

  setupPositionProbePattern(0, 0);
  setupPositionProbePattern(moduleCount - 7, 0);
  setupPositionProbePattern(0, moduleCount - 7);

  // Timing patterns
  for (let r = 8; r < moduleCount - 8; r++) {
    if (modules[r][6] === null) modules[r][6] = r % 2 === 0;
  }
  for (let c = 8; c < moduleCount - 8; c++) {
    if (modules[6][c] === null) modules[6][c] = c % 2 === 0;
  }

  // Alignment pattern for v3 (at 22, 22) or v4 (at 26, 26)
  const alignPos = version === 4 ? 26 : 22;
  for (let r = -2; r <= 2; r++) {
    for (let c = -2; c <= 2; c++) {
      if (
        Math.abs(r) === 2 ||
        Math.abs(c) === 2 ||
        (r === 0 && c === 0)
      ) {
        modules[alignPos + r][alignPos + c] = true;
      } else {
        modules[alignPos + r][alignPos + c] = false;
      }
    }
  }

  // Bit buffer for data
  const qrByte = new QRByte(text);
  const buffer = new QRBitBuffer();
  buffer.put(4, 4); // 8-bit byte mode indicator
  buffer.put(qrByte.getLength(), 8);
  qrByte.write(buffer);

  // Data capacities for Medium EC: v3 = 44 bytes, v4 = 64 bytes
  const totalDataBytes = version === 4 ? 64 : 44;
  const ecLength = version === 4 ? 36 : 26;

  // Add terminator and padding
  if (buffer.length + 4 <= totalDataBytes * 8) buffer.put(0, 4);
  while (buffer.length % 8 !== 0) buffer.putBit(false);
  while (buffer.length < totalDataBytes * 8) {
    buffer.put(0xec, 8);
    if (buffer.length < totalDataBytes * 8) buffer.put(0x11, 8);
  }

  // Compute error correction
  const dataBytes = new Array(totalDataBytes);
  for (let i = 0; i < totalDataBytes; i++) {
    let b = 0;
    for (let j = 0; j < 8; j++) {
      if (buffer.get(i * 8 + j)) b |= 1 << (7 - j);
    }
    dataBytes[i] = b;
  }

  const rsPoly = getErrorCorrectPolynomial(ecLength);
  const rawPoly = new Polynomial(dataBytes, rsPoly.getLength() - 1);
  const modPoly = rawPoly.mod(rsPoly);

  const finalBytes = [...dataBytes];
  for (let i = 0; i < rsPoly.getLength() - 1; i++) {
    const modIndex = i + modPoly.getLength() - (rsPoly.getLength() - 1);
    finalBytes.push(modIndex >= 0 ? modPoly.get(modIndex) : 0);
  }

  // Place data bits in matrix
  let byteIndex = 0;
  let bitIndex = 7;
  let dir = -1;
  let row = moduleCount - 1;
  let col = moduleCount - 1;

  while (col > 0) {
    if (col === 6) col--;
    while (true) {
      for (let c = 0; c < 2; c++) {
        const curCol = col - c;
        if (modules[row][curCol] === null) {
          let dark = false;
          if (byteIndex < finalBytes.length) {
            dark = ((finalBytes[byteIndex] >>> bitIndex) & 1) === 1;
            bitIndex--;
            if (bitIndex === -1) {
              byteIndex++;
              bitIndex = 7;
            }
          }
          // Mask pattern 0: (row + col) % 2 === 0
          const mask = (row + curCol) % 2 === 0;
          modules[row][curCol] = dark !== mask;
        }
      }
      row += dir;
      if (row < 0 || moduleCount <= row) {
        row -= dir;
        dir = -dir;
        break;
      }
    }
    col -= 2;
  }

  // Fill format information (Mask 0, Level M -> 101010000010010)
  const formatBits = [1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0];
  for (let i = 0; i < 15; i++) {
    const bit = formatBits[i] === 1;
    // Top-left
    if (i < 6) modules[i][8] = bit;
    else if (i < 8) modules[i + 1][8] = bit;
    else modules[moduleCount - 15 + i][8] = bit;

    // Top-right & bottom-left
    if (i < 8) modules[8][moduleCount - i - 1] = bit;
    else if (i < 9) modules[8][15 - i - 1 + 1] = bit;
    else modules[8][15 - i - 1] = bit;
  }
  modules[moduleCount - 8][8] = true;

  // Convert nulls to false
  return modules.map((r) => r.map((c) => Boolean(c)));
}

