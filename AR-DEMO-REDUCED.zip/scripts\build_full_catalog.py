import os, json

catalog = {
    "categories": [
        {
            "id": "necklace",
            "name": "Necklace",
            "items": []
        },
        {
            "id": "earrings",
            "name": "Earrings",
            "items": []
        },
        {
            "id": "finger_ring",
            "name": "Ring",
            "items": []
        },
        {
            "id": "bangles",
            "name": "Bracelet",
            "items": []
        },
        {
            "id": "nose_ring",
            "name": "Nose Ring",
            "items": []
        }
    ],
    "items": []
}

necklace_names = [
    'Royal Kundan Choker', 'Temple Heritage Necklace', '22K Gold Filigree Collar',
    'Emerald Bloom Gold Necklace', 'Classic Gold Bead Mala', 'Floral Cascade Gold Necklace',
    'Artisan Gold Rope Chain', 'Imperial Queen Gold Choker', 'Polki Pendant Gold Chain',
    'Maharani Gold Hasli', 'Celestial Gold Layered Chain', 'Peacock Crest Gold Necklace',
    'Vintage Gold Medallion', 'Contemporary Sleek Gold Choker', 'Navratna Statement Necklace',
    'Princess Diamond Collar'
]

earring_names = [
    'Temple Gold Jhumka', 'Gold Chandbali Drops', 'Classic Diamond Studs',
    'Floral Gold Danglers', 'Royal Pearl Drop Earrings', 'Geometric Gold Hoops',
    'Heritage Gold Bali', 'Cascading Dewdrop Earrings', 'Filigree Chandelier Earrings',
    'Solitaire Halo Studs', 'Lotus Motif Gold Drops', 'Art Deco Gold Danglers',
    'Traditional Gold Jhumki', 'Sleek Teardrop Gold Earrings', 'Polki Cluster Chandbali',
    'Emerald Royale Earrings'
]

ring_names = [
    'Solitaire Diamond Ring', 'Royal Crown Gold Band', 'Floral Cluster Diamond Ring',
    'Vintage Signet Gold Ring', 'Infinity Twisted Gold Ring', 'Pavé Eternity Diamond Band',
    'Emerald Cut Gold Ring', 'Heritage Navratna Ring', 'Three-Stone Trilogy Ring',
    'Cathedral Diamond Solitaire', 'Sleek 22K Gold Band', 'Marquise Diamond Gold Ring',
    'Artisanal Braided Gold Ring', 'Contemporary Tension Ring', 'Halo Cushion Diamond Ring',
    'Imperial Gold Signet'
]

bangle_names = [
    'Royal Gold Kada', 'Filigree Bangle Bracelet', '22K Gold Link Chain Bracelet',
    'Temple Carved Gold Bangle', 'Diamond Tennis Bracelet', 'Twisted Wire Gold Kada',
    'Peacock Motif Gold Bangle', 'Classic Sleek Gold Cuff', 'Heritage Meenakari Bangle',
    'Embossed Floral Gold Kada', 'Charm Link Gold Bracelet', 'Geometric Open Gold Cuff',
    'Twin Serpent Gold Kada', 'Eternity Pavé Gold Bangle'
]

nose_ring_names = [
    'Royal Kundan Nath', 'Classic Pearl Nose Stud', 'Solitaire Diamond Nose Pin',
    'Floral Cluster Nose Stud', 'Traditional Gold Bali Hoop', 'Beaded Gold Nose Ring',
    'Bridal Peacock Nath', 'Heritage Ruby Nose Stud', 'Filigree Gold Nose Hoop',
    'Emerald Flower Nose Pin', 'Celestial Star Nose Stud', 'Teardrop Kundan Nath',
    'Twisted Wire Gold Hoop', 'Marquise Diamond Nose Stud'
]

# Necklaces (16 items)
neck_cat = next(c for c in catalog["categories"] if c["id"] == "necklace")
for i, name in enumerate(necklace_names, start=1):
    fname = f"gold_necklace_{i:02d}.png"
    item = {
        "id": f"necklace_{i}",
        "name": name,
        "category": "necklace",
        "src": f"/catalog/necklace/{fname}",
        "anchor": {"x": 0.5, "y": 0.0},
        "type": "choker" if "Choker" in name or "Collar" in name or "Hasli" in name else "long",
        "widthRatio": 0.82 if i % 2 == 0 else 0.75,
        "yOffset": 0.0,
        "scaleFactor": 1.0,
        "price": f"₹{(120000 + i * 9500):,}",
        "necklaceAnchors": {
            "leftEnd": {"x": 0.14, "y": 0.04},
            "rightEnd": {"x": 0.86, "y": 0.04},
            "pendantCenter": {"x": 0.50, "y": 0.85},
            "bottomCenter": {"x": 0.50, "y": 0.94}
        }
    }
    neck_cat["items"].append(item)
    catalog["items"].append(item)

# Earrings (16 items)
ear_cat = next(c for c in catalog["categories"] if c["id"] == "earrings")
for i, name in enumerate(earring_names, start=1):
    fname = f"gold_earrings_{i:02d}.png"
    item_type = "jhumka" if "Jhumk" in name or "Chandbali" in name or "Drops" in name else ("stud" if "Stud" in name else "earrings")
    item = {
        "id": f"earrings_{i}",
        "name": name,
        "category": "earrings",
        "src": f"/catalog/earrings/{fname}",
        "anchor": {"x": 0.5, "y": 0.08 if item_type != "stud" else 0.5},
        "type": item_type,
        "widthRatio": 0.18 if item_type != "stud" else 0.09,
        "yOffset": 0.0,
        "scaleFactor": 0.14 if item_type != "stud" else 0.07,
        "price": f"₹{(45000 + i * 4500):,}"
    }
    ear_cat["items"].append(item)
    catalog["items"].append(item)

# Finger Ring (16 items)
ring_cat = next(c for c in catalog["categories"] if c["id"] == "finger_ring")
for i, name in enumerate(ring_names, start=1):
    fname = f"gold_finger_ring_{i:02d}.png"
    style = "solitaire"
    if "Crown" in name or "Signet" in name: style = "signet"
    elif "Cluster" in name: style = "cluster"
    elif "Twisted" in name: style = "twisted"
    elif "Eternity" in name or "Pavé" in name: style = "eternity"
    elif "Navratna" in name: style = "heritage"
    elif "Three-Stone" in name: style = "three_stone"
    elif "Cathedral" in name: style = "cathedral"

    item = {
        "id": f"finger_ring_{i}",
        "name": name,
        "category": "finger_ring",
        "src": f"/catalog/finger_ring/{fname}",
        "anchor": {"x": 0.5, "y": 0.5},
        "type": style,
        "widthRatio": 0.22,
        "yOffset": 0.0,
        "scaleFactor": 0.22,
        "price": f"₹{(35000 + i * 3800):,}"
    }
    ring_cat["items"].append(item)
    catalog["items"].append(item)

# Bangles (14 items)
bangles_cat = next(c for c in catalog["categories"] if c["id"] == "bangles")
for i, name in enumerate(bangle_names, start=1):
    fname = f"gold_bangles_{i:02d}.png"
    style = "kada" if "Kada" in name else ("twisted" if "Twisted" in name else ("carved" if "Carved" in name or "Embossed" in name else "thick"))
    item = {
        "id": f"bangles_{i}",
        "name": name,
        "category": "bangles",
        "src": f"/catalog/bangles/{fname}",
        "anchor": {"x": 0.5, "y": 0.5},
        "type": style,
        "widthRatio": 0.95,
        "yOffset": 0.0,
        "scaleFactor": 0.95,
        "price": f"₹{(75000 + i * 6500):,}"
    }
    bangles_cat["items"].append(item)
    catalog["items"].append(item)

# Nose Ring (14 items)
nose_cat = next(c for c in catalog["categories"] if c["id"] == "nose_ring")
for i, name in enumerate(nose_ring_names, start=1):
    fname = f"gold_nose_ring_{i:02d}.png"
    style = "nath" if "Nath" in name else ("hoop" if "Hoop" in name or "Ring" in name or "Bali" in name else "stud")
    item = {
        "id": f"nose_ring_{i}",
        "name": name,
        "category": "nose_ring",
        "src": f"/catalog/nose_ring/{fname}",
        "anchor": {"x": 0.15 if style == "nath" else (0.35 if style == "hoop" else 0.5), "y": 0.5},
        "type": style,
        "widthRatio": 0.35 if style == "nath" else (0.16 if style == "hoop" else 0.10),
        "yOffset": 0.0,
        "scaleFactor": 0.10 if style == "nath" else (0.07 if style == "hoop" else 0.05),
        "price": f"₹{(18000 + i * 2200):,}"
    }
    nose_cat["items"].append(item)
    catalog["items"].append(item)

out_file = "public/catalog/catalog.json"
with open(out_file, "w", encoding="utf-8") as f:
    json.dump(catalog, f, indent=2)

print(f"Built full catalog with {len(catalog['items'])} items across {len(catalog['categories'])} categories.")
for c in catalog["categories"]:
    print(f"  {c['name']} ({c['id']}): {len(c['items'])} items")
