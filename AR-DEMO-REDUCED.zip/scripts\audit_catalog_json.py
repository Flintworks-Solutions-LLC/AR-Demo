import os, json
from PIL import Image
import numpy as np

with open('public/catalog/catalog.json', 'r', encoding='utf-8') as f:
    cat = json.load(f)

for c in cat['categories']:
    print(f"=== Category: {c['id']} ({len(c['items'])} items) ===")
    for item in c['items']:
        src = item['src'].lstrip('/')
        p = os.path.join('public', src)
        item_id = item['id']
        name = item['name']
        
        # 1. Check exists
        if not os.path.exists(p):
            print(f"  [MISSING/404] {item_id} ({name}): {p}")
            continue
            
        # 2. Check anchor
        if 'anchor' not in item or not item['anchor']:
            print(f"  [MISSING ANCHOR] {item_id} ({name})")
        if c['id'] == 'necklace':
            if 'necklaceAnchors' not in item or not item['necklaceAnchors']:
                print(f"  [MISSING NECKLACE ANCHORS] {item_id} ({name})")
                
        # 3. Check Image & Transparency
        try:
            im = Image.open(p)
            if im.mode != 'RGBA':
                print(f"  [NOT RGBA] {item_id} ({name}): mode={im.mode}")
                continue
            arr = np.array(im)
            alpha = arr[..., 3]
            h, w = arr.shape[:2]
            corners = [int(alpha[0, 0]), int(alpha[0, -1]), int(alpha[-1, 0]), int(alpha[-1, -1])]
            bad_corners = [x for x in corners if x > 20]
            opaque = alpha > 20
            opaque_count = int(np.sum(opaque))
            total = h * w
            coverage = opaque_count / total
            
            if bad_corners:
                print(f"  [FAILED BG REMOVAL / CORNERS] {item_id} ({name}): corners={corners}")
            if coverage > 0.80:
                print(f"  [FAILED BG REMOVAL / SOLID] {item_id} ({name}): coverage={coverage:.2f}")
            elif coverage < 0.03:
                print(f"  [EMPTY/ALMOST TRANSPARENT] {item_id} ({name}): coverage={coverage:.2f}")
                
        except Exception as e:
            print(f"  [IMAGE OPEN ERROR] {item_id} ({name}): {e}")
