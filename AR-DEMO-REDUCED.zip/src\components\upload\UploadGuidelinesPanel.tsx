"use client";

import React, { useState } from "react";
import { 
  Box, 
  Images, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  Sparkles, 
  FileCheck,
  Palette,
  Maximize2
} from "lucide-react";

export function UploadGuidelinesPanel() {
  const [activeTab, setActiveTab] = useState<"glb" | "photos" | "checklist">("glb");

  return (
    <div className="flex flex-col gap-4 text-neutral-200">
      {/* Tab switcher */}
      <div className="flex p-1 bg-white/5 border border-white/10 rounded-xl">
        <button
          type="button"
          onClick={() => setActiveTab("glb")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold transition ${
            activeTab === "glb"
              ? "bg-[#D4AF37] text-neutral-950 shadow-md shadow-[#D4AF37]/20"
              : "text-neutral-400 hover:text-white"
          }`}
        >
          <Box className="w-4 h-4" />
          <span>3D GLB Model</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("photos")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold transition ${
            activeTab === "photos"
              ? "bg-[#D4AF37] text-neutral-950 shadow-md shadow-[#D4AF37]/20"
              : "text-neutral-400 hover:text-white"
          }`}
        >
          <Images className="w-4 h-4" />
          <span>Photo Sequence (360°)</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab("checklist")}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold transition ${
            activeTab === "checklist"
              ? "bg-[#D4AF37] text-neutral-950 shadow-md shadow-[#D4AF37]/20"
              : "text-neutral-400 hover:text-white"
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Quick Checklist</span>
        </button>
      </div>

      {/* Tab 1: GLB Rules */}
      {activeTab === "glb" && (
        <div className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs flex gap-2.5">
            <Sparkles className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
            <p>
              Primary format for real-time 3D interactive preview and live augmented reality try-on.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-white">
                <Box className="w-4 h-4 text-[#D4AF37]" />
                <span>Format & Packaging</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                Single binary <span className="text-neutral-200 font-mono">.glb</span> file (or self-contained .gltf with embedded buffer & textures). Maximum size: <strong className="text-white">20 MB</strong>.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-white">
                <Palette className="w-4 h-4 text-[#D4AF37]" />
                <span>Dynamic Metal Switching</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                To allow users to switch metals (Gold, Silver, Rose Gold), name metal materials containing <span className="text-[#D4AF37] font-mono">metal</span>, <span className="text-[#D4AF37] font-mono">gold</span>, or <span className="text-[#D4AF37] font-mono">silver</span>.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-white">
                <Maximize2 className="w-4 h-4 text-[#D4AF37]" />
                <span>Geometry & Origin</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                Center model at origin <span className="text-neutral-200 font-mono">(0, 0, 0)</span>. Keep polygon count under <strong className="text-white">200,000 triangles</strong> for lag-free mobile web performance.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-white">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>Textures & DRACO</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                Texture dimensions should not exceed <strong className="text-white">2048×2048 px</strong>. DRACO geometry compression is fully supported for smaller download sizes.
              </p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-zinc-900/80 border border-white/10 text-xs text-neutral-300">
            <span className="font-semibold text-white block mb-1">💎 Gemstone & Diamond Protection:</span>
            Keep gemstones on a separate material (e.g. named <code className="text-cyan-300">gem_diamond</code> or <code className="text-rose-300">ruby_cut</code>). This ensures precious gems retain their refractive glass look when customers cycle metal finishes.
          </div>
        </div>
      )}

      {/* Tab 2: Photos Rules */}
      {activeTab === "photos" && (
        <div className="space-y-4 max-h-[420px] overflow-y-auto pr-1">
          <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-200 text-xs flex gap-2.5">
            <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <p>
              Ideal for studio turntable photography sequences to provide an interactive 360° spin experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-white">
                <Images className="w-4 h-4 text-[#D4AF37]" />
                <span>Image Count</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                Requires <strong className="text-white">24 to 36 images</strong> covering 360 degrees (step intervals of 10° or 15° on a revolving turntable).
              </p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-white">
                <Maximize2 className="w-4 h-4 text-[#D4AF37]" />
                <span>Dimensions & Format</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                JPG, PNG, or WebP. <strong className="text-white">All frames must have identical pixel dimensions</strong> (e.g., 1000×1000 px). Max 5 MB per frame.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-white">
                <FileCheck className="w-4 h-4 text-[#D4AF37]" />
                <span>Natural File Naming</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                Name frames sequentially so they rotate seamlessly: <span className="font-mono text-neutral-200">frame_01.jpg</span>, <span className="font-mono text-neutral-200">frame_02.jpg</span>, ... <span className="font-mono text-neutral-200">frame_36.jpg</span>.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
              <div className="flex items-center gap-2 font-semibold text-white">
                <Sparkles className="w-4 h-4 text-[#D4AF37]" />
                <span>Consistent Lighting</span>
              </div>
              <p className="text-neutral-400 leading-relaxed">
                Use fixed softbox lighting and lock camera exposure/focus to eliminate flickering during rotation.
              </p>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-neutral-300">
            <span className="font-semibold text-emerald-300 block mb-1">✨ Need 3D Conversion or Background Removal?</span>
            <p className="text-neutral-400 leading-relaxed">
              If your images still have busy background clutter, our AI pipeline and scanning team can convert photo sequences into textured 3D GLB assets automatically. Contact support to request automated photogrammetry.
            </p>
          </div>
        </div>
      )}

      {/* Tab 3: Checklist */}
      {activeTab === "checklist" && (
        <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1 text-xs">
          <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-2">
            <p className="font-semibold text-white text-xs uppercase tracking-wider text-neutral-400">
              Before You Upload 3D GLB:
            </p>
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Exported as <strong className="text-white">.glb</strong> binary format with embedded textures</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>File size is within <strong className="text-white">20 MB</strong></span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Triangle budget is under <strong className="text-white">200,000 tris</strong></span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Textures are <strong className="text-white">2048×2048 px</strong> or lower</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Metal materials contain <code className="text-[#D4AF37]">metal</code> or <code className="text-[#D4AF37]">gold</code> in their name</span>
              </div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-2">
            <p className="font-semibold text-white text-xs uppercase tracking-wider text-neutral-400">
              Before You Upload Photos:
            </p>
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Exactly <strong className="text-white">24 to 36 images</strong> selected</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Every image has identical width and height</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Files are named in rotation order (e.g. 01.png, 02.png)</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Each photo is under 5 MB</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
