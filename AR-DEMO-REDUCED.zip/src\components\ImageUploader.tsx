"use client";

import React, { useRef, useState, useCallback } from "react";
import { LandmarkerCategory } from "@/hooks/useLandmarkers";
import { NecklaceAnchors } from "@/config/jewellery.config";
import {
  removeBackgroundCanvas,
  removeBackgroundAI,
  upscaleIfNeeded,
} from "@/lib/backgroundRemoval";
import { useJewelleryStore } from "@/context/JewelleryStoreContext";
import { StoredJewelleryItem } from "@/lib/indexedDb";

type UploadCategory = "necklace" | "earrings" | "nose_ring" | "bangles" | "finger_ring";

interface ImageUploaderProps {
  initialCategory?: LandmarkerCategory;
  onClose?: () => void;
  onItemAdded?: (cat: UploadCategory, item: StoredJewelleryItem) => void;
}

const CATEGORY_LABELS: Record<UploadCategory, string> = {
  necklace: "Necklace",
  earrings: "Earrings",
  nose_ring: "Nose Ring",
  bangles: "Bangles / Bracelet",
  finger_ring: "Finger Ring",
};

export function ImageUploader({ initialCategory, onClose, onItemAdded }: ImageUploaderProps) {
  const { addUploadedItem } = useJewelleryStore();

  const fileRef = useRef<HTMLInputElement>(null);
  const rawCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const processedCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const brushCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [step, setStep] = useState<"idle" | "processing" | "preview" | "brush" | "done">("idle");
  const [category, setCategory] = useState<UploadCategory>(
    (initialCategory as UploadCategory) || "necklace"
  );
  const [fileName, setFileName] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [progressMsg, setProgressMsg] = useState("");

  // GLB/GLTF model handling
  const [isGLB, setIsGLB] = useState(false);
  const [glbUrl, setGlbUrl] = useState<string | null>(null);

  // Background removal options
  const [bgMode, setBgMode] = useState<"ai" | "floodfill">("ai");
  const [tolerance] = useState<number>(28);
  const [feather] = useState<number>(1);
  const [cropPadding] = useState<number>(12); // ~4% padding

  // Split comparison slider (0 to 100)
  const [sliderPos, setSliderPos] = useState<number>(50);

  // Previews
  const [originalUrl, setOriginalUrl] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // Manual brush state
  const [brushMode, setBrushMode] = useState<"erase" | "restore">("erase");
  const [brushSize, setBrushSize] = useState<number>(20);
  const isDrawingRef = useRef(false);

  // Execute background removal
  const executeRemoval = useCallback(
    async (rawCanvas: HTMLCanvasElement, mode: "floodfill" | "ai", tol: number, fth: number, pad: number) => {
      setProgressMsg(mode === "ai" ? "Running AI neural background removal…" : "Applying precision flood-fill…");

      let cropped: HTMLCanvasElement;
      if (mode === "ai") {
        try {
          cropped = await removeBackgroundAI(rawCanvas, {
            cropPadding: pad,
            feather: fth,
            upscaleSmall: true,
          });
        } catch (err) {
          console.warn("AI background removal fallback to canvas flood-fill:", err);
          cropped = removeBackgroundCanvas(rawCanvas, {
            tolerance: tol,
            feather: fth,
            cropPadding: pad,
            closeRadius: 1,
            removeSpecks: true,
            upscaleSmall: true,
          });
        }
      } else {
        cropped = removeBackgroundCanvas(rawCanvas, {
          tolerance: tol,
          feather: fth,
          cropPadding: pad,
          closeRadius: 1,
          removeSpecks: true,
          upscaleSmall: true,
        });
      }

      processedCanvasRef.current = cropped;
      const dataUrl = cropped.toDataURL("image/png");
      setPreviewUrl(dataUrl);
      return dataUrl;
    },
    []
  );

  const processFile = useCallback(
    async (file: File) => {
      setStep("processing");
      setError(null);
      setFileName(file.name);

      const isModel = file.name.endsWith(".glb") || file.name.endsWith(".gltf");
      if (isModel) {
        setIsGLB(true);
        const url = URL.createObjectURL(file);
        setGlbUrl(url);
        setPreviewUrl("/jewellery/placeholder.png");
        setStep("preview");
        return;
      }

      setIsGLB(false);

      try {
        setProgressMsg("Inspecting image resolution & details…");
        const origUrl = URL.createObjectURL(file);
        const img = await new Promise<HTMLImageElement>((resolve, reject) => {
          const i = new Image();
          i.onload = () => resolve(i);
          i.onerror = reject;
          i.src = origUrl;
        });

        const src = document.createElement("canvas");
        src.width = img.naturalWidth;
        src.height = img.naturalHeight;
        const ctx = src.getContext("2d", { willReadFrequently: true });
        if (!ctx) throw new Error("Could not initialize 2D context");
        ctx.drawImage(img, 0, 0);

        const workingCanvas = upscaleIfNeeded(src);
        rawCanvasRef.current = workingCanvas;
        setOriginalUrl(workingCanvas.toDataURL("image/png"));

        await executeRemoval(workingCanvas, bgMode, tolerance, feather, cropPadding);
        setStep("preview");
      } catch (e) {
        const err = e as Error;
        console.error("[ImageUploader] Processing error:", err);
        setError(err.message || "Failed to process image.");
        setStep("idle");
      }
    },
    [bgMode, tolerance, feather, cropPadding, executeRemoval]
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    processFile(file);
  };

  const handleConfirm = async () => {
    if (!isGLB && (!processedCanvasRef.current || !previewUrl)) return;

    const itemName = fileName.replace(/\.[^.]+$/, "").replace(/[-_]/g, " ") || "Custom Jewel";
    const itemId = `upload_${Date.now()}`;

    let anchor = { x: 0.5, y: 0.5 };
    let widthRatio = 0.5;
    let scaleFactor = 0.5;
    let necklaceAnchors: NecklaceAnchors | undefined = undefined;

    if (category === "necklace") {
      anchor = { x: 0.5, y: 0.0 };
      widthRatio = 0.8;
      scaleFactor = 1.0;
      necklaceAnchors = {
        leftEnd: { x: 0.15, y: 0.04 },
        rightEnd: { x: 0.85, y: 0.04 },
        pendantCenter: { x: 0.50, y: 0.85 },
        bottomCenter: { x: 0.50, y: 0.94 },
      };
    } else if (category === "earrings") {
      anchor = { x: 0.5, y: 0.08 };
      widthRatio = 0.18;
      scaleFactor = 0.14;
    } else if (category === "finger_ring") {
      anchor = { x: 0.5, y: 0.5 };
      widthRatio = 0.22;
      scaleFactor = 0.22;
    } else if (category === "bangles") {
      anchor = { x: 0.5, y: 0.5 };
      widthRatio = 0.95;
      scaleFactor = 0.95;
    } else if (category === "nose_ring") {
      anchor = { x: 0.35, y: 0.5 };
      widthRatio = 0.18;
      scaleFactor = 0.08;
    }

    const newItem: StoredJewelleryItem = {
      id: itemId,
      name: itemName,
      category,
      price: "Bespoke Creation",
      src: previewUrl || "",
      originalSrc: originalUrl || undefined,
      modelUrl: glbUrl || undefined,
      type: "custom",
      anchor,
      necklaceAnchors,
      widthRatio,
      scaleFactor,
      createdAt: Date.now(),
    };

    await addUploadedItem(newItem);
    onItemAdded?.(category, newItem);
    onClose?.();
  };

  // Setup Manual Brush Canvas
  const openManualBrush = () => {
    if (!processedCanvasRef.current) return;
    setStep("brush");
    setTimeout(() => {
      const bc = brushCanvasRef.current;
      const pc = processedCanvasRef.current;
      if (!bc || !pc) return;
      bc.width = pc.width;
      bc.height = pc.height;
      const bCtx = bc.getContext("2d");
      if (bCtx) {
        bCtx.drawImage(pc, 0, 0);
      }
    }, 50);
  };

  const handleBrushDraw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const canvas = brushCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    ctx.save();
    if (brushMode === "erase") {
      ctx.globalCompositeOperation = "destination-out";
      ctx.beginPath();
      ctx.arc(x, y, brushSize * scaleX, 0, Math.PI * 2);
      ctx.fill();
    } else if (rawCanvasRef.current) {
      // Restore from raw canvas
      ctx.globalCompositeOperation = "source-over";
      ctx.save();
      ctx.beginPath();
      ctx.arc(x, y, brushSize * scaleX, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(rawCanvasRef.current, 0, 0, canvas.width, canvas.height);
      ctx.restore();
    }
    ctx.restore();
  };

  const saveBrushResult = () => {
    if (!brushCanvasRef.current) return;
    const bc = brushCanvasRef.current;
    processedCanvasRef.current = bc;
    setPreviewUrl(bc.toDataURL("image/png"));
    setStep("preview");
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200 select-none"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-[560px] bg-gradient-to-b from-[#18181b] via-[#101012] to-[#09090b] rounded-3xl border border-[#D4AF37]/35 shadow-2xl shadow-black/95 overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-5 pb-3 border-b border-white/5">
          <div>
            <span className="text-[10px] font-semibold tracking-widest text-[#D4AF37] uppercase">
              Bespoke Upload Studio
            </span>
            <h2 className="text-xl font-bold text-white font-serif tracking-wide">
              Upload Your Jewellery
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 text-white/60 hover:text-white flex items-center justify-center text-lg transition border border-white/10"
          >
            ✕
          </button>
        </div>

        {/* Category Choice */}
        <div className="px-6 pt-4 pb-2">
          <label className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold mb-2 block">
            Select Piece Category
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
            {(Object.keys(CATEGORY_LABELS) as UploadCategory[]).map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`py-2 px-1.5 rounded-xl text-center text-xs font-semibold transition border ${
                  category === cat
                    ? "bg-[#D4AF37] text-neutral-950 border-[#D4AF37] shadow-md shadow-[#D4AF37]/20"
                    : "bg-white/5 text-neutral-400 border-white/5 hover:border-white/20 hover:text-white"
                }`}
              >
                {CATEGORY_LABELS[cat].split(" ")[0]}
              </button>
            ))}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 pt-2">
          {step === "idle" && (
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              onClick={() => fileRef.current?.click()}
              className="border-2 border-dashed border-[#D4AF37]/40 hover:border-[#D4AF37] bg-white/[0.02] hover:bg-white/[0.04] rounded-2xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer transition text-center group"
            >
              <input
                ref={fileRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,.glb,.gltf"
                onChange={handleFileChange}
                className="hidden"
              />
              <div className="w-14 h-14 rounded-2xl bg-[#D4AF37]/10 flex items-center justify-center text-3xl group-hover:scale-110 transition">
                💎
              </div>
              <div>
                <p className="text-sm font-semibold text-white mb-1">
                  Drag & Drop or <span className="text-[#F5E1A4] underline">Browse File</span>
                </p>
                <p className="text-xs text-neutral-400">
                  Supports PNG, JPG, WEBP and 3D GLB/GLTF models
                </p>
              </div>
              <span className="text-[10px] px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Studio Alpha Matting & Defringing Included
              </span>
            </div>
          )}

          {step === "processing" && (
            <div className="py-14 flex flex-col items-center justify-center gap-4 text-center">
              <div className="w-12 h-12 rounded-full border-3 border-[#D4AF37] border-t-transparent animate-spin" />
              <div>
                <p className="text-sm font-bold text-white mb-1">Refining Jewellery Cutout</p>
                <p className="text-xs text-neutral-400">{progressMsg}</p>
              </div>
            </div>
          )}

          {step === "preview" && (
            <div className="flex flex-col gap-4">
              {/* Interactive Before/After Split Preview */}
              <div className="relative w-full aspect-square max-h-[300px] rounded-2xl overflow-hidden bg-[radial-gradient(#252528_1px,transparent_1px)] [background-size:16px_16px] bg-[#141417] border border-white/10 flex items-center justify-center">
                {originalUrl && previewUrl && (
                  <>
                    {/* Background Original Image */}
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={originalUrl}
                      alt="Original"
                      className="absolute inset-0 w-full h-full object-contain pointer-events-none"
                    />

                    {/* Foreground Cutout with clip-path based on slider */}
                    <div
                      className="absolute inset-0 overflow-hidden"
                      style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={previewUrl}
                        alt="Cutout"
                        className="w-full h-full object-contain pointer-events-none"
                      />
                    </div>

                    {/* Divider line */}
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-[#D4AF37] pointer-events-none shadow-[0_0_8px_#D4AF37]"
                      style={{ left: `${sliderPos}%` }}
                    >
                      <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-[#D4AF37] text-neutral-950 font-bold text-[10px] flex items-center justify-center shadow-lg">
                        ↔
                      </div>
                    </div>

                    {/* Split control input */}
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={sliderPos}
                      onChange={(e) => setSliderPos(parseFloat(e.target.value))}
                      className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full z-20"
                    />
                  </>
                )}
              </div>

              {/* Toolbar */}
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span className="text-[11px]">Slide left/right to compare cutout</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      if (rawCanvasRef.current) {
                        setBgMode((m) => (m === "ai" ? "floodfill" : "ai"));
                        executeRemoval(
                          rawCanvasRef.current,
                          bgMode === "ai" ? "floodfill" : "ai",
                          tolerance,
                          feather,
                          cropPadding
                        );
                      }
                    }}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-white border border-white/10 transition"
                  >
                    Mode: {bgMode === "ai" ? "AI Model" : "Flood Fill"}
                  </button>
                  <button
                    onClick={openManualBrush}
                    className="px-2.5 py-1 rounded-lg bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#F5E1A4] border border-[#D4AF37]/40 transition font-semibold"
                  >
                    🖌 Manual Brush
                  </button>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => setStep("idle")}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-semibold border border-white/10 transition"
                >
                  Choose Different
                </button>
                <button
                  id="confirm-jewel-upload"
                  onClick={handleConfirm}
                  className="flex-1 py-3 px-5 rounded-xl bg-gradient-to-r from-[#F5E1A4] via-[#E5C158] to-[#D4AF37] text-neutral-950 font-bold text-xs uppercase tracking-wider shadow-lg shadow-[#D4AF37]/25 hover:brightness-105 active:scale-[0.99] transition"
                >
                  Add to Catalog & Try On Live
                </button>
              </div>
            </div>
          )}

          {step === "brush" && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setBrushMode("erase")}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                      brushMode === "erase"
                        ? "bg-red-500 text-white"
                        : "bg-white/5 text-neutral-400 hover:text-white"
                    }`}
                  >
                    Erase
                  </button>
                  <button
                    onClick={() => setBrushMode("restore")}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                      brushMode === "restore"
                        ? "bg-emerald-500 text-white"
                        : "bg-white/5 text-neutral-400 hover:text-white"
                    }`}
                  >
                    Restore
                  </button>
                </div>
                <div className="flex items-center gap-2 text-xs text-neutral-400">
                  <span>Size:</span>
                  <input
                    type="range"
                    min="5"
                    max="60"
                    value={brushSize}
                    onChange={(e) => setBrushSize(parseInt(e.target.value))}
                    className="accent-[#D4AF37] w-24 h-1.5"
                  />
                </div>
              </div>

              <div className="relative w-full aspect-square max-h-[320px] rounded-2xl overflow-hidden bg-[#18181b] border border-white/10 flex items-center justify-center">
                <canvas
                  ref={brushCanvasRef}
                  onMouseDown={() => (isDrawingRef.current = true)}
                  onMouseUp={() => (isDrawingRef.current = false)}
                  onMouseLeave={() => (isDrawingRef.current = false)}
                  onMouseMove={handleBrushDraw}
                  className="w-full h-full object-contain cursor-crosshair"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={() => setStep("preview")}
                  className="px-4 py-2 rounded-xl bg-white/5 text-neutral-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={saveBrushResult}
                  className="flex-1 py-2 rounded-xl bg-[#D4AF37] text-neutral-950 font-bold text-xs uppercase"
                >
                  Save Brush Edits
                </button>
              </div>
            </div>
          )}

          {error && (
            <p className="mt-3 text-xs text-red-400 text-center font-medium bg-red-950/40 p-2 rounded-xl border border-red-500/20">
              {error}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
