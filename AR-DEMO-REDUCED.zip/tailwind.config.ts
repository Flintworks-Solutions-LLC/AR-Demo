import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        gold: {
          100: "#FDF8E2",
          200: "#FAF0BE",
          300: "#F5E1A4",
          400: "#E5C158",
          500: "#D4AF37",
          600: "#B89628",
          700: "#8C6F14",
        },
        noir: {
          950: "#060606",
          900: "#0B0B0C",
          850: "#111113",
          800: "#18181B",
          700: "#27272A",
        },
      },
      fontFamily: {
        serif: ["var(--font-playfair)", "Playfair Display", "Georgia", "serif"],
        sans: ["var(--font-inter)", "Inter", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;
