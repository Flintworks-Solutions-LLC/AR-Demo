export type CategoryType = 'necklace' | 'earrings' | 'finger_ring' | 'bangles' | 'nose_ring';
export type MetalColorType = 'gold' | 'silver' | 'rose_gold';
export type GemType = 'diamond' | 'ruby' | 'emerald' | 'sapphire' | 'pearl' | 'none';

export interface JewelDimensions {
  width: number;  // in cm
  height: number; // in cm
  depth: number;  // in cm
}

export interface WearAnchor {
  x: number; // Normalized anchor 0..1
  y: number;
  z?: number;
  scaleFactor?: number;
  widthRatio?: number;
}

export interface JewelConfig {
  id: string;
  name: string;
  category: CategoryType;
  style: string;
  metalTone: MetalColorType;
  gemType: GemType;
  gemCount: number;
  gemSize: number; // in cm
  motif: string;
  price: string;
  materialsDescription: string;
  dimensions: JewelDimensions;
  wearAnchor: WearAnchor;
  isCustom?: boolean;
  cutoutUrl?: string;
  modelUrl?: string;
}
