"use client";

import React, { useState, useCallback, useMemo, useEffect } from "react";
import { motion } from "framer-motion";
import { Stage } from "@/components/Stage";
import {
  useJewelleryStore,
  MetalType,
  JewelleryItem,
  JewelleryCategoryData,
} from "@/context/JewelleryStoreContext";
import { LandmarkerCategory } from "@/hooks/useLandmarkers";
import { getJewelConfigById } from "@/jewels";
import { getOrRenderThumbnail } from "@/jewels/thumbnailRenderer";
import { MobileConnectModal } from "@/components/mobile/MobileConnectModal";

const CATEGORY_ICONS: Record<string, string> = {
  necklace:   "📿",
  necklaces:  "📿",
  earrings:   "💎",
  nose_ring:  "💠",
  noserings:  "💠",
  bangles:    "🔮",
  finger_ring:"💍",
  rings:      "💍",
  sets:       "✨",
};

interface TryOnScreenProps {
  initialCategory: LandmarkerCategory;
  initialItemId: string;
  onBack: () => void;
  onItemAdded?: (cat: string, item: JewelleryItem) => void;
  extraCategories?: JewelleryCategoryData[];
}

/* Tiny thumbnail component that renders from model */
function MiniThumbnail({ itemId, alt, fallbackSrc }: { itemId: string; alt: string; fallbackSrc?: string }) {
  const [url, setUrl] = useState<string>(fallbackSrc || "");

  useEffect(() => {
    if (fallbackSrc) setUrl(fallbackSrc);
  }, [fallbackSrc]);

  useEffect(() => {
    if (fallbackSrc) {
      setUrl(fallbackSrc);
      return;
    }
    let cancelled = false;
    const config = getJewelConfigById(itemId);
    if (config) {
      getOrRenderThumbnail(config, "gold")
        .then((u) => {
          if (!cancelled && u) setUrl(u);
        })
        .catch(() => {});
    }
    return () => { cancelled = true; };
  }, [itemId, fallbackSrc]);

  return url ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={url}
      alt={alt}
      className="w-full h-full object-contain drop-shadow-[0_4px_8px_rgba(0,0,0,0.5)]"
      loading="lazy"
      onError={(e) => {
        (e.target as HTMLImageElement).style.opacity = "0.2";
      }}
    />
  ) : (
    <div className="w-full h-full flex items-center justify-center">
      <div className="w-5 h-5 border border-amber-400/30 border-t-amber-400 rounded-full animate-spin" />
    </div>
  );
}

export function TryOnScreen({
  initialCategory,
  initialItemId,
  onBack,
}: TryOnScreenProps) {
  const {
    selectedItem,
    activeItems,
    selectItem,
    allCategories,
    selectedCategory,
    setSelectedCategory,
    metal,
    setMetal,
    debugOverlayText,
  } = useJewelleryStore();

  const noseRingToggle = "left" as const;
  const [showDebug, setShowDebug] = useState(false);
  const [useOcclusion, setUseOcclusion] = useState(true);
  const [showMobileModal, setShowMobileModal] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Fullscreen toggle handler
  const handleToggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  }, []);

  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", handler);
    return () => document.removeEventListener("fullscreenchange", handler);
  }, []);

  // Set initial item
  useEffect(() => {
    if (initialCategory && initialItemId) {
      const cat = allCategories.find((c) => c.id === initialCategory);
      const item = cat?.items.find((i) => i.id === initialItemId);
      if (item) {
        selectItem(item, initialCategory);
      }
    }
  }, [initialCategory, initialItemId, allCategories, selectItem]);

  const currentCat = useMemo(() => {
    return allCategories.find((c) => c.id === selectedCategory) || allCategories[0];
  }, [allCategories, selectedCategory]);

  const handleSelectCategory = useCallback(
    (catId: LandmarkerCategory) => {
      if (catId) setSelectedCategory(catId);
    },
    [setSelectedCategory]
  );

  const handleSelectItem = useCallback(
    (item: JewelleryItem) => {
      selectItem(item, selectedCategory || undefined);
    },
    [selectItem, selectedCategory]
  );

  const handleSnapshotReady = useCallback((dataUrl: string) => {
    const link = document.createElement("a");
    link.href = dataUrl;
    link.download = `aura-jewellery-${Date.now()}.png`;
    link.click();
  }, []);

  // Convert activeItems to the Record<string, JewelleryItem> shape Stage expects
  const stageItems = useMemo(() => {
    const map: Record<string, JewelleryItem | undefined> = {};
    for (const [cat, item] of Object.entries(activeItems)) {
      if (item) {
        map[cat] = {
          id: item.id,
          name: item.name,
          category: item.category,
          price: item.price,
          src: item.cutoutUrl || item.imageUrl || item.src || "",
          anchor: item.anchor,
          necklaceAnchors: item.necklaceAnchors,
          type: item.type,
          style: item.style,
          widthRatio: item.widthRatio,
          yOffset: item.yOffset,
          scaleFactor: item.scaleFactor,
          procedural: item.procedural,
          modelUrl: item.modelUrl,
          metal: item.metal,
          isCustom: item.isCustom,
          cutoutUrl: item.cutoutUrl,
          uprightAngle: item.uprightAngle,
        };
      }
    }
    return map;
  }, [activeItems]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black flex flex-col select-none">
      {/* ── Glass Top Navigation Bar ── */}
      <div className="absolute top-0 inset-x-0 z-30 flex flex-col pointer-events-none">
        {/* Row 1: Back / Brand / Metal / Fullscreen */}
        <div className="flex items-center justify-between p-3.5 sm:p-5">
          {/* Top-Left: Atelier Back Button */}
          <div className="flex items-center">
            <button
              id="back-to-catalog-btn"
              onClick={onBack}
              className="pointer-events-auto flex items-center gap-2 px-4 py-2 rounded-full bg-black/75 hover:bg-black/95 backdrop-blur-xl border border-white/15 text-white hover:border-[#D4AF37]/50 text-xs sm:text-sm font-medium transition-all shadow-xl active:scale-95 cursor-pointer"
            >
              <span>←</span>
              <span>Atelier</span>
            </button>
          </div>

          {/* Top-Center: Brand badge */}
          <div className="flex flex-col items-center pointer-events-none select-none text-center px-2">
            <span className="text-[10px] sm:text-xs tracking-[0.28em] text-[#D4AF37] uppercase font-bold">
              LIVE VIRTUAL TRY-ON
            </span>
            <span className="text-sm sm:text-base font-serif font-medium text-white/90 tracking-wide">
              Aura Joaillerie
            </span>
          </div>

          {/* Top-Right: Metal Finish Selector + Fullscreen Button */}
          <div className="pointer-events-auto flex items-center gap-2 sm:gap-3">
            <div className="flex items-center p-1 rounded-full bg-black/75 backdrop-blur-xl border border-white/15 shadow-xl">
              {(["gold", "silver", "rose_gold"] as MetalType[]).map((m) => {
                const isSelected = metal === m;
                return (
                  <button
                    key={m}
                    onClick={() => setMetal(m)}
                    title={m === "rose_gold" ? "Rose Gold" : m.charAt(0).toUpperCase() + m.slice(1)}
                    className={`relative px-2.5 sm:px-3 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                      isSelected ? "text-neutral-950 font-bold shadow-sm" : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    {isSelected && (
                      <motion.div
                        layoutId="metalPill"
                        className="absolute inset-0 rounded-full"
                        style={{
                          background:
                            m === "gold"
                              ? "linear-gradient(135deg, #F5E1A4 0%, #D4AF37 100%)"
                              : m === "silver"
                              ? "linear-gradient(135deg, #FFFFFF 0%, #CBD5E1 100%)"
                              : "linear-gradient(135deg, #FAD0C4 0%, #B76E79 100%)",
                        }}
                        transition={{ type: "spring", stiffness: 400, damping: 30 }}
                      />
                    )}
                    <span className="relative z-10 text-[10px] sm:text-[11px] uppercase tracking-wider">
                      {m === "rose_gold" ? "Rose" : m}
                    </span>
                  </button>
                );
              })}
            </div>

            <button
              id="mobile-connect-btn"
              onClick={() => setShowMobileModal(true)}
              title="Use on Mobile Phone & Laptop"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/75 hover:bg-black/95 backdrop-blur-xl border border-[#D4AF37]/40 hover:border-[#D4AF37] text-[#F5E1A4] hover:text-white text-xs font-semibold transition-all shadow-xl active:scale-95 cursor-pointer"
            >
              <span className="text-xs leading-none">📱</span>
              <span className="text-[11px] uppercase tracking-wider font-bold">Mobile</span>
            </button>

            <button
              id="fullscreen-btn"
              onClick={handleToggleFullscreen}
              title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/75 hover:bg-black/95 backdrop-blur-xl border border-white/15 hover:border-[#D4AF37]/50 text-neutral-200 hover:text-white text-xs font-semibold transition-all shadow-xl active:scale-95 cursor-pointer"
            >
              <span className="text-sm leading-none">{isFullscreen ? "⊡" : "⊞"}</span>
              <span className="hidden md:inline text-[11px] uppercase tracking-wider">{isFullscreen ? "Exit" : "Full"}</span>
            </button>
          </div>
        </div>

        {/* Row 2: Slim Category Tabs under the title */}
        <div className="flex items-center justify-center pointer-events-auto px-4 -mt-1">
          <div className="flex items-center gap-0.5 p-0.5 rounded-full bg-black/70 backdrop-blur-xl border border-white/10 shadow-lg">
            {allCategories.map((cat) => {
              const isCurrent = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  id={`tryon-cat-${cat.id}`}
                  onClick={() => handleSelectCategory(cat.id as LandmarkerCategory)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium transition-all cursor-pointer ${
                    isCurrent
                      ? "bg-gradient-to-r from-[#F5E1A4] via-[#E5C158] to-[#D4AF37] text-neutral-950 font-bold shadow-sm shadow-[#D4AF37]/25"
                      : "text-neutral-400 hover:text-white hover:bg-white/10"
                  }`}
                >
                  <span className="text-[10px]">{CATEGORY_ICONS[cat.id] ?? "💎"}</span>
                  <span className="text-[11px] whitespace-nowrap">{cat.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── Debug overlay text: only visible if showDebug is on ── */}
      {showDebug && (
        <div className="absolute top-24 left-4 z-40 text-[10px] font-mono text-purple-300 bg-black/80 border border-purple-500/40 px-2.5 py-1 rounded-lg pointer-events-none shadow-xl">
          {debugOverlayText}
        </div>
      )}

      {/* ── Fullscreen Camera Stage ── */}
      <div className="relative flex-1 w-full h-full">
        <Stage
          category={selectedCategory as LandmarkerCategory}
          items={stageItems}
          noseRingToggle={noseRingToggle}
          metal={metal}
          showDebug={showDebug}
          useOcclusion={useOcclusion}
          onToggleDebug={() => setShowDebug((p) => !p)}
          onToggleOcclusion={() => setUseOcclusion((p) => !p)}
          onSnapshotReady={handleSnapshotReady}
          startOnMount={true}
          onCameraStop={onBack}
        />
      </div>

      {/* ── Compact Bottom Thumbnail Strip (max 72px, semi-transparent) ── */}
      <div className="absolute bottom-0 inset-x-0 z-30 h-[72px] bg-black/60 backdrop-blur-md border-t border-white/10 pointer-events-auto" style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 0px)' }}>
        <div className="h-full max-w-5xl mx-auto flex items-center justify-center gap-1.5 overflow-x-auto hide-scrollbar px-3">
          {(currentCat?.items ?? []).map((item) => {
            const isItemSelected = selectedItem?.id === item.id;
            return (
              <motion.button
                key={item.id}
                id={`tryon-thumb-${item.id}`}
                onClick={() => handleSelectItem(item)}
                title={item.name}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`flex-shrink-0 flex flex-col items-center gap-0.5 transition-all focus:outline-none cursor-pointer ${
                  isItemSelected ? "opacity-100" : "opacity-50 hover:opacity-100"
                }`}
              >
                <div
                  className={`relative w-12 h-12 rounded-lg overflow-hidden p-0.5 transition-all duration-300 border ${
                    isItemSelected
                      ? "border-[#D4AF37] scale-105"
                      : "border-white/10 hover:border-white/30"
                  }`}
                  style={{
                    background: "linear-gradient(145deg, #1c1c1f 0%, #111113 100%)",
                    boxShadow: isItemSelected
                      ? "0 2px 8px rgba(212,175,55,0.35)"
                      : "0 1px 3px rgba(0,0,0,0.4)",
                  }}
                >
                  <MiniThumbnail
                    itemId={item.id}
                    alt={item.name}
                    fallbackSrc={item.src || undefined}
                  />
                </div>
                <span
                  title={item.name}
                  className={`text-[8px] text-center font-medium line-clamp-1 max-w-[52px] leading-tight ${
                    isItemSelected ? "text-[#F5E1A4] font-semibold" : "text-neutral-500"
                  }`}
                >
                  {item.name}
                </span>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Cross-Device Mobile & Laptop QR Modal */}
      <MobileConnectModal
        isOpen={showMobileModal}
        onClose={() => setShowMobileModal(false)}
      />
    </div>
  );
}
