import * as THREE from 'three';
import { MetalColorType, GemType } from './types';

export const METAL_TONES: Record<MetalColorType, { color: number; roughness: number; metalness: number }> = {
  gold: { color: 0xd4af37, roughness: 0.18, metalness: 1.0 },
  silver: { color: 0xc0c0c0, roughness: 0.22, metalness: 1.0 },
  rose_gold: { color: 0xb76e79, roughness: 0.20, metalness: 1.0 },
};

/**
 * Creates luxury MeshPhysicalMaterial instances for metal and gems.
 */
export function createJewelMaterials(metal: MetalColorType = 'gold') {
  const metalCfg = METAL_TONES[metal] || METAL_TONES.gold;

  const metalMat = new THREE.MeshPhysicalMaterial({
    color: metalCfg.color,
    metalness: metalCfg.metalness,
    roughness: metalCfg.roughness,
    envMapIntensity: 1.4,
    clearcoat: 0.35,
    clearcoatRoughness: 0.1,
    reflectivity: 0.95,
  });
  metalMat.name = 'jewel_metal';

  const diamondMat = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    metalness: 0.0,
    roughness: 0.0,
    transmission: 0.9,
    ior: 2.4,
    thickness: 0.5,
    envMapIntensity: 1.4,
    clearcoat: 1.0,
    clearcoatRoughness: 0.04,
    transparent: true,
    opacity: 0.98,
  });
  diamondMat.name = 'gem_diamond';

  const rubyMat = new THREE.MeshPhysicalMaterial({
    color: 0xcc1133,
    metalness: 0.0,
    roughness: 0.0,
    transmission: 0.9,
    ior: 1.77,
    thickness: 0.5,
    envMapIntensity: 1.4,
    clearcoat: 0.85,
    clearcoatRoughness: 0.05,
    transparent: true,
    opacity: 0.95,
  });
  rubyMat.name = 'gem_ruby';

  const emeraldMat = new THREE.MeshPhysicalMaterial({
    color: 0x0f9d58,
    metalness: 0.0,
    roughness: 0.0,
    transmission: 0.9,
    ior: 1.58,
    thickness: 0.5,
    envMapIntensity: 1.4,
    clearcoat: 0.85,
    transparent: true,
    opacity: 0.95,
  });
  emeraldMat.name = 'gem_emerald';

  const sapphireMat = new THREE.MeshPhysicalMaterial({
    color: 0x1a4fb5,
    metalness: 0.0,
    roughness: 0.0,
    transmission: 0.9,
    ior: 1.77,
    thickness: 0.5,
    envMapIntensity: 1.4,
    clearcoat: 0.9,
    transparent: true,
    opacity: 0.95,
  });
  sapphireMat.name = 'gem_sapphire';

  const pearlMat = new THREE.MeshPhysicalMaterial({
    color: 0xfbf8ee,
    metalness: 0.08,
    roughness: 0.25,
    envMapIntensity: 1.4,
    clearcoat: 1.0,
    clearcoatRoughness: 0.12,
  });
  pearlMat.name = 'gem_pearl';

  const blackOnyxMat = new THREE.MeshPhysicalMaterial({
    color: 0x111115,
    metalness: 0.1,
    roughness: 0.12,
    clearcoat: 0.95,
  });
  blackOnyxMat.name = 'gem_onyx';

  return {
    metalMat,
    diamondMat,
    rubyMat,
    emeraldMat,
    sapphireMat,
    pearlMat,
    blackOnyxMat,
    getGemMaterial: (type: GemType): THREE.Material => {
      switch (type) {
        case 'ruby':
          return rubyMat;
        case 'emerald':
          return emeraldMat;
        case 'sapphire':
          return sapphireMat;
        case 'pearl':
          return pearlMat;
        case 'diamond':
        default:
          return diamondMat;
      }
    },
  };
}

/**
 * Updates any meshes marked with 'jewel_metal' to match the new metal tone.
 */
export function updateGroupMetal(group: THREE.Group, metal: MetalColorType) {
  const cfg = METAL_TONES[metal] || METAL_TONES.gold;
  group.traverse((child) => {
    if ((child as THREE.Mesh).isMesh) {
      const mesh = child as THREE.Mesh;
      if (mesh.material && !Array.isArray(mesh.material)) {
        const mat = mesh.material as THREE.MeshPhysicalMaterial;
        if (mat.name === 'jewel_metal') {
          mat.color.setHex(cfg.color);
          mat.roughness = cfg.roughness;
          mat.metalness = cfg.metalness;
          mat.needsUpdate = true;
        }
      }
    }
  });
}

/**
 * Generates faceted brilliant-cut diamond geometry with authentic table, crown, girdle, and pavilion.
 */
export function createBrilliantGemGeometry(radius = 0.35): THREE.BufferGeometry {
  const octa = new THREE.OctahedronGeometry(radius, 1);
  octa.scale(1.15, 0.9, 1.15);
  octa.computeVertexNormals();
  return octa;
}

/**
 * Generates an emerald/baguette rectangular step-cut gem.
 */
export function createStepCutGemGeometry(w = 0.5, h = 0.7, d = 0.35): THREE.BufferGeometry {
  const geom = new THREE.BoxGeometry(w, h, d);
  geom.computeVertexNormals();
  return geom;
}
