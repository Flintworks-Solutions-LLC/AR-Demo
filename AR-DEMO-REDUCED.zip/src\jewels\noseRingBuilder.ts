import * as THREE from 'three';
import { JewelConfig } from './types';
import { createJewelMaterials, createBrilliantGemGeometry } from './materials';

/**
 * Builds one of 10 distinct, richly detailed 3D nose rings / naths / studs.
 * Scale: 1 unit = 1 cm (size range 0.3 to 0.9 cm).
 * Centered at (0, 0, 0) with mounting post facing -Z into the nostril.
 */
export function buildNoseRing(config: JewelConfig): THREE.Group {
  const group = new THREE.Group();
  group.name = `nosering_${config.id}`;

  const { metalMat, diamondMat, rubyMat, emeraldMat, sapphireMat, pearlMat } =
    createJewelMaterials(config.metalTone);

  // Small nostril insertion post
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.25, 6), metalMat);
  post.position.set(0, 0, -0.12);
  post.rotation.x = Math.PI / 2;
  group.add(post);

  switch (config.style) {
    case 'diamond_stud': {
      // 4-prong diamond solitaire stud (approx 3.5mm diameter)
      const gem = new THREE.Mesh(createBrilliantGemGeometry(0.18), diamondMat);
      gem.position.set(0, 0, 0.04);
      group.add(gem);

      const collet = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.1, 0.1, 8), metalMat);
      collet.position.set(0, 0, 0);
      collet.rotation.x = Math.PI / 2;
      group.add(collet);
      break;
    }

    case 'gold_hoop': {
      // Delicate 8mm seamless sleeper hoop with diamond bead
      const hoopRadius = 0.38;
      const hoop = new THREE.Mesh(
        new THREE.TorusGeometry(hoopRadius, 0.035, 12, 36, Math.PI * 1.85),
        metalMat
      );
      hoop.position.set(hoopRadius * 0.7, -hoopRadius * 0.5, 0);
      group.add(hoop);

      const bead = new THREE.Mesh(new THREE.SphereGeometry(0.065, 8, 8), diamondMat);
      bead.position.set(hoopRadius * 0.7, -hoopRadius * 1.5, 0);
      group.add(bead);
      break;
    }

    case 'nath_small': {
      // Bridal nath: 7mm hoop with pearl ring, ruby cluster, and delicate chain
      const hoop = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.03, 10, 32), metalMat);
      hoop.position.set(0.3, -0.2, 0);
      group.add(hoop);

      // Ruby cluster on edge
      const ruby = new THREE.Mesh(createBrilliantGemGeometry(0.12), rubyMat);
      ruby.position.set(0.68, -0.2, 0.04);
      group.add(ruby);

      // 4 tiny pearl beads along bottom edge
      for (let i = 0; i < 4; i++) {
        const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 6), pearlMat);
        pearl.position.set(0.3 + i * 0.12, -0.65, 0);
        group.add(pearl);
      }
      break;
    }

    case 'dot_stud': {
      // Minimalist 22K solid gold ball stud
      const ball = new THREE.Mesh(new THREE.SphereGeometry(0.16, 16, 16), metalMat);
      ball.position.set(0, 0, 0.06);
      group.add(ball);
      break;
    }

    case 'flower': {
      // 6-petal diamond daisy nose stud with ruby pistil
      const rubyPistil = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), rubyMat);
      rubyPistil.position.set(0, 0, 0.05);
      group.add(rubyPistil);

      for (let i = 0; i < 6; i++) {
        const a = (i * Math.PI * 2) / 6;
        const petal = new THREE.Mesh(createBrilliantGemGeometry(0.07), diamondMat);
        petal.position.set(Math.cos(a) * 0.14, Math.sin(a) * 0.14, 0.03);
        group.add(petal);
      }
      break;
    }

    case 'teardrop_stud': {
      // Pear-cut emerald stud in bezel setting
      const gem = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.32, 8), emeraldMat);
      gem.position.set(0, -0.06, 0.04);
      gem.rotation.z = Math.PI;
      group.add(gem);

      const bezel = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.36, 8), metalMat);
      bezel.position.set(0, -0.06, 0.01);
      bezel.rotation.z = Math.PI;
      group.add(bezel);
      break;
    }

    case 'double_stone': {
      // Twin bezel-set diamonds stacked vertically
      const topStone = new THREE.Mesh(createBrilliantGemGeometry(0.12), diamondMat);
      topStone.position.set(0, 0.12, 0.04);
      group.add(topStone);

      const bottomStone = new THREE.Mesh(createBrilliantGemGeometry(0.16), diamondMat);
      bottomStone.position.set(0, -0.12, 0.04);
      group.add(bottomStone);

      const bar = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.44, 0.06), metalMat);
      bar.position.set(0, 0, 0.01);
      group.add(bar);
      break;
    }

    case 'clip_hoop': {
      // Crescent textured clip hoop
      const crescent = new THREE.Mesh(
        new THREE.TorusGeometry(0.36, 0.06, 12, 32, Math.PI * 1.6),
        metalMat
      );
      crescent.position.set(0.28, -0.22, 0);
      group.add(crescent);
      break;
    }

    case 'gem_hoop': {
      // 7mm hoop lined with micro-pavé sapphires
      const hoopRadius = 0.35;
      const hoop = new THREE.Mesh(new THREE.TorusGeometry(hoopRadius, 0.04, 10, 32), metalMat);
      hoop.position.set(hoopRadius * 0.7, -hoopRadius * 0.5, 0);
      group.add(hoop);

      for (let i = 0; i < 7; i++) {
        const a = (i / 6) * Math.PI;
        const sapphire = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 6), sapphireMat);
        sapphire.position.set(
          hoopRadius * 0.7 + Math.cos(a) * (hoopRadius + 0.03),
          -hoopRadius * 0.5 + Math.sin(a) * (hoopRadius + 0.03),
          0.02
        );
        group.add(sapphire);
      }
      break;
    }

    case 'bead_hoop':
    default: {
      // Bali wire hoop with 3 granulated gold beads
      const hoop = new THREE.Mesh(new THREE.TorusGeometry(0.36, 0.03, 10, 32), metalMat);
      hoop.position.set(0.28, -0.22, 0);
      group.add(hoop);

      [-0.12, 0, 0.12].forEach((offset) => {
        const bead = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), metalMat);
        bead.position.set(0.28 + offset, -0.58, 0);
        group.add(bead);
      });
      break;
    }
  }

  return group;
}
