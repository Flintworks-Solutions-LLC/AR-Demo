import { NextResponse } from "next/server";
import os from "os";

export async function GET() {
  const ifaces = os.networkInterfaces();
  const addresses: { iface: string; ip: string }[] = [];

  for (const name of Object.keys(ifaces)) {
    const list = ifaces[name];
    if (!list) continue;
    for (const net of list) {
      if (net.family === "IPv4" && !net.internal) {
        addresses.push({ iface: name, ip: net.address });
      }
    }
  }

  // Prioritize Wi-Fi or normal LAN interfaces over virtual adapters (WSL, Hyper-V, vEthernet, Docker)
  const sorted = addresses.sort((a, b) => {
    const aLower = a.iface.toLowerCase();
    const bLower = b.iface.toLowerCase();
    const aIsVirtual = aLower.includes("wsl") || aLower.includes("virtual") || aLower.includes("vethernet") || aLower.includes("docker");
    const bIsVirtual = bLower.includes("wsl") || bLower.includes("virtual") || bLower.includes("vethernet") || bLower.includes("docker");
    if (aIsVirtual && !bIsVirtual) return 1;
    if (!aIsVirtual && bIsVirtual) return -1;

    const aIsWifi = aLower.includes("wi-fi") || aLower.includes("wlan") || aLower.includes("wireless");
    const bIsWifi = bLower.includes("wi-fi") || bLower.includes("wlan") || bLower.includes("wireless");
    if (aIsWifi && !bIsWifi) return -1;
    if (!aIsWifi && bIsWifi) return 1;

    return 0;
  });

  const preferredIp = sorted[0]?.ip || "localhost";

  return NextResponse.json({
    ip: preferredIp,
    allIps: sorted,
  });
}

