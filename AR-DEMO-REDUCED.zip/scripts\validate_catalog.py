#!/usr/bin/env python3
"""
Post-processing validator for catalog images.
Re-checks all PNGs in public/catalog/*, validates transparency,
opaque coverage, luminance, and mannequin/bust detection.
Removes invalid entries from catalog.json and deletes bad images.
"""

import os
import sys
import json
import hashlib
from PIL import Image
import numpy as np

CATALOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "public", "catalog")
CATALOG_JSON = os.path.join(CATALOG_DIR, "catalog.json")

# Alpha <= this at corners is treated as transparent (rembg sometimes leaves 1-10)
CORNER_ALPHA_THRESHOLD = 15

def validate_image(img_path):
    """Returns (valid: bool, reason: str)"""
    try:
        with Image.open(img_path) as im:
            im = im.convert("RGBA")
        
        arr = np.array(im)
        alpha = arr[..., 3]
        rgb = arr[..., :3]
        h_dim, w = im.size[1], im.size[0]

        # 1. Corner pixels alpha should be near-transparent
        corners = [int(alpha[0, 0]), int(alpha[0, -1]), int(alpha[-1, 0]), int(alpha[-1, -1])]
        if not all(c <= CORNER_ALPHA_THRESHOLD for c in corners):
            return False, f"corners not transparent: {corners}"

        # 2. Opaque coverage between 5% and 75%
        opaque = alpha > 20
        total_opaque = int(np.sum(opaque))
        total_pixels = w * h_dim
        if total_pixels == 0:
            return False, "zero-size image"
        
        coverage = float(total_opaque / total_pixels)
        if not (0.05 <= coverage <= 0.75):
            return False, f"coverage {coverage:.2f} out of [0.05, 0.75]"

        # 3. Mean luminance of opaque pixels > 55
        lum = 0.299 * rgb[..., 0].astype(float) + 0.587 * rgb[..., 1].astype(float) + 0.114 * rgb[..., 2].astype(float)
        if total_opaque < 100:
            return False, "too few opaque pixels"
        mean_lum = float(np.mean(lum[opaque]))
        if mean_lum <= 55.0:
            return False, f"mean luminance {mean_lum:.1f} <= 55 (dark mannequin/bust)"

        # 4. Mannequin / bust / person detection
        hsv_im = im.convert("HSV")
        h_p, s_p, v_p = np.array(hsv_im).transpose(2, 0, 1)
        
        # Dark velvet/cloth blob
        dark_ratio = float(np.sum(opaque & (v_p < 55)) / total_opaque)
        if dark_ratio > 0.30:
            return False, f"dark bust/stand: dark_ratio={dark_ratio:.2f}"

        # Low saturation non-gold blob (grey mannequin, cloth stand)
        low_sat_ratio = float(np.sum(opaque & (s_p < 30) & (v_p < 110)) / total_opaque)
        if low_sat_ratio > 0.35:
            return False, f"mannequin/velvet: low_sat_ratio={low_sat_ratio:.2f}"

        # 5. Check gold content in final image (relaxed to 0.12)
        gold_mask = opaque & (h_p >= 10) & (h_p <= 50) & (s_p >= 30) & (v_p >= 40)
        gold_ratio = float(np.sum(gold_mask) / total_opaque)
        if gold_ratio < 0.12:
            return False, f"low gold ratio: {gold_ratio:.2f}"

        # 6. Aspect ratio check - reject super wide or super tall
        aspect = w / max(h_dim, 1)
        if aspect > 4.0 or aspect < 0.25:
            return False, f"bad aspect ratio: {aspect:.2f}"

        return True, f"OK (coverage={coverage:.2f}, lum={mean_lum:.1f}, gold={gold_ratio:.2f})"
    except Exception as e:
        return False, f"error: {e}"


def main():
    if not os.path.exists(CATALOG_JSON):
        print("ERROR: catalog.json not found at", CATALOG_JSON)
        sys.exit(1)
    
    with open(CATALOG_JSON, "r", encoding="utf-8") as f:
        catalog = json.load(f)
    
    categories = catalog.get("categories", [])
    total_removed = 0
    total_kept = 0

    for cat in categories:
        items = cat.get("items", [])
        valid_items = []
        
        print(f"\n--- {cat.get('name', cat.get('id', '?'))} ---")
        for item in items:
            src = item.get("src", "")
            # Convert relative path to absolute
            img_path = os.path.join(os.path.dirname(CATALOG_DIR), src.lstrip("/"))
            img_path = os.path.normpath(img_path)
            
            if not os.path.exists(img_path):
                print(f"  [MISSING] {item['name']}: {img_path}")
                total_removed += 1
                continue
            
            valid, reason = validate_image(img_path)
            if valid:
                valid_items.append(item)
                total_kept += 1
                print(f"  [OK] {item['name']}: {reason}")
            else:
                print(f"  [REMOVED] {item['name']}: {reason}")
                # Delete the image file
                try:
                    os.remove(img_path)
                    print(f"    Deleted: {img_path}")
                except Exception as e:
                    print(f"    Could not delete {img_path}: {e}")
                total_removed += 1
        
        cat["items"] = valid_items

    # Rebuild items list
    catalog["items"] = []
    for cat in categories:
        catalog["items"].extend(cat["items"])

    # Save updated catalog.json
    with open(CATALOG_JSON, "w", encoding="utf-8") as f:
        json.dump(catalog, f, indent=2, ensure_ascii=False)
    
    print(f"\nValidation complete: {total_kept} kept, {total_removed} removed")
    print(f"Updated {CATALOG_JSON}")


if __name__ == "__main__":
    main()
