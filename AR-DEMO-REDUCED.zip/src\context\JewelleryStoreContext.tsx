"use client";

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from "react";
import { getJewelsByCategory, JewelConfig, CategoryType } from "@/jewels";
import { getAllCustomJewels, saveCustomJewel, StoredJewelleryItem } from "@/lib/indexedDb";
import { NecklaceAnchors } from "@/config/jewellery.config";
import { TRYON_ASSET_MAPPINGS } from "@/config/tryonAssetMapping";

export type MetalType = "gold" | "silver" | "rose_gold";

export interface SelectedItem {
  id: string;
  category: string;
  name: string;
  imageUrl: string;
  cutoutUrl: string;
  modelUrl?: string;
  metal: MetalType;
  price?: string;
  src?: string;
  type?: string;
  style?: string;
  anchor: { x: number; y: number };
  necklaceAnchors?: NecklaceAnchors;
  widthRatio?: number;
  yOffset?: number;
  rotationOffset?: number;
  scaleFactor?: number;
  procedural?: boolean;
  isCustom?: boolean;
  uprightAngle?: number;
  originalSrc?: string;
}

/* Shape used by CatalogScreen / TryOnScreen for displaying items */
export interface JewelleryItem {
  id: string;
  name: string;
  category?: string;
  price?: string;
  src: string;
  anchor: { x: number; y: number };
  necklaceAnchors?: NecklaceAnchors;
  type?: string;
  style?: string;
  widthRatio?: number;
  yOffset?: number;
  rotationOffset?: number;
  scaleFactor?: number;
  modelUrl?: string;
  procedural?: boolean;
  materialsDescription?: string;
  metal?: MetalType;
  isCustom?: boolean;
  cutoutUrl?: string;
  uprightAngle?: number;
  originalSrc?: string;
  setPieces?: {
    necklace: JewelleryItem;
    earrings: JewelleryItem;
    bangle?: JewelleryItem;
  };
  setNecklaceSrc?: string;
  setEarringsSrc?: string;
  [key: string]: unknown;
}

export type ActiveCategory = 'necklaces' | 'earrings' | 'rings' | 'bangles' | 'noserings' | 'sets';

export function normalizeCategory(cat: string | null | undefined): ActiveCategory {
  if (!cat) return 'necklaces';
  const c = cat.toLowerCase();
  if (c === 'necklace' || c === 'necklaces') return 'necklaces';
  if (c === 'earrings') return 'earrings';
  if (c === 'finger_ring' || c === 'rings') return 'rings';
  if (c === 'bangles') return 'bangles';
  if (c === 'nose_ring' || c === 'noserings') return 'noserings';
  if (c === 'sets') return 'sets';
  return 'necklaces';
}

export const SETS_CATALOG: JewelleryItem[] = [
  {
    id: "set_kundan_bridal",
    name: "Royal Kundan Bridal Set",
    category: "sets",
    price: "$18,500",
    src: "/catalog/sets/gold_set_01.png",
    anchor: { x: 0.5, y: 0.0 },
    necklaceAnchors: {
      leftEnd: { x: 0.14, y: 0.04 },
      rightEnd: { x: 0.86, y: 0.04 },
      pendantCenter: { x: 0.50, y: 0.85 },
      bottomCenter: { x: 0.50, y: 0.94 },
    },
    setPieces: {
      necklace: {
        id: "necklace_kundan_collar",
        name: "Royal Kundan Choker",
        category: "necklaces",
        src: "/catalog/necklace/gold_necklace_01.png",
        anchor: { x: 0.5, y: 0.0 },
        type: "choker",
        widthRatio: 0.75,
        scaleFactor: 1.0,
        necklaceAnchors: {
          leftEnd: { x: 0.14, y: 0.04 },
          rightEnd: { x: 0.86, y: 0.04 },
          pendantCenter: { x: 0.50, y: 0.85 },
          bottomCenter: { x: 0.50, y: 0.94 },
        },
      },
      earrings: {
        id: "earrings_kundan",
        name: "Gold Chandbali Drops",
        category: "earrings",
        src: "/catalog/earrings/gold_earrings_02.png",
        anchor: { x: 0.5, y: 0.08 },
        type: "jhumka",
        widthRatio: 0.18,
        scaleFactor: 0.14,
      },
    },
    setNecklaceSrc: "/catalog/necklace/gold_necklace_01.png",
    setEarringsSrc: "/catalog/earrings/gold_earrings_02.png",
  },
  {
    id: "set_temple_heritage",
    name: "Temple Heritage Grand Suite",
    category: "sets",
    price: "$22,000",
    src: "/catalog/sets/gold_set_02.png",
    anchor: { x: 0.5, y: 0.0 },
    necklaceAnchors: {
      leftEnd: { x: 0.14, y: 0.04 },
      rightEnd: { x: 0.86, y: 0.04 },
      pendantCenter: { x: 0.50, y: 0.88 },
      bottomCenter: { x: 0.50, y: 0.96 },
    },
    setPieces: {
      necklace: {
        id: "necklace_temple_haram",
        name: "Temple Heritage Necklace",
        category: "necklaces",
        src: "/catalog/necklace/gold_necklace_02.png",
        anchor: { x: 0.5, y: 0.0 },
        type: "long",
        widthRatio: 0.82,
        scaleFactor: 1.0,
        necklaceAnchors: {
          leftEnd: { x: 0.14, y: 0.04 },
          rightEnd: { x: 0.86, y: 0.04 },
          pendantCenter: { x: 0.50, y: 0.88 },
          bottomCenter: { x: 0.50, y: 0.96 },
        },
      },
      earrings: {
        id: "earrings_temple_jhumka",
        name: "Temple Gold Jhumka",
        category: "earrings",
        src: "/catalog/earrings/gold_earrings_01.png",
        anchor: { x: 0.5, y: 0.08 },
        type: "jhumka",
        widthRatio: 0.18,
        scaleFactor: 0.14,
      },
    },
    setNecklaceSrc: "/catalog/necklace/gold_necklace_02.png",
    setEarringsSrc: "/catalog/earrings/gold_earrings_01.png",
  },
  {
    id: "set_filigree_choker",
    name: "22K Filigree Collar & Chandelier Set",
    category: "sets",
    price: "$16,900",
    src: "/catalog/sets/gold_set_03.png",
    anchor: { x: 0.5, y: 0.0 },
    necklaceAnchors: {
      leftEnd: { x: 0.14, y: 0.04 },
      rightEnd: { x: 0.86, y: 0.04 },
      pendantCenter: { x: 0.50, y: 0.85 },
      bottomCenter: { x: 0.50, y: 0.94 },
    },
    setPieces: {
      necklace: {
        id: "necklace_filigree_collar",
        name: "22K Gold Filigree Collar",
        category: "necklaces",
        src: "/catalog/necklace/gold_necklace_03.png",
        anchor: { x: 0.5, y: 0.0 },
        type: "choker",
        widthRatio: 0.75,
        scaleFactor: 1.0,
        necklaceAnchors: {
          leftEnd: { x: 0.14, y: 0.04 },
          rightEnd: { x: 0.86, y: 0.04 },
          pendantCenter: { x: 0.50, y: 0.85 },
          bottomCenter: { x: 0.50, y: 0.94 },
        },
      },
      earrings: {
        id: "earrings_filigree_chandelier",
        name: "Filigree Chandelier Earrings",
        category: "earrings",
        src: "/catalog/earrings/gold_earrings_09.png",
        anchor: { x: 0.5, y: 0.08 },
        type: "jhumka",
        widthRatio: 0.18,
        scaleFactor: 0.14,
      },
    },
    setNecklaceSrc: "/catalog/necklace/gold_necklace_03.png",
    setEarringsSrc: "/catalog/earrings/gold_earrings_09.png",
  },
  {
    id: "set_polki_lotus",
    name: "Polki Pendant & Lotus Drops Suite",
    category: "sets",
    price: "$14,200",
    src: "/catalog/sets/gold_set_04.png",
    anchor: { x: 0.5, y: 0.0 },
    necklaceAnchors: {
      leftEnd: { x: 0.14, y: 0.04 },
      rightEnd: { x: 0.86, y: 0.04 },
      pendantCenter: { x: 0.50, y: 0.82 },
      bottomCenter: { x: 0.50, y: 0.94 },
    },
    setPieces: {
      necklace: {
        id: "necklace_polki_chain",
        name: "Polki Pendant Gold Chain",
        category: "necklaces",
        src: "/catalog/necklace/gold_necklace_09.png",
        anchor: { x: 0.5, y: 0.0 },
        type: "long",
        widthRatio: 0.65,
        scaleFactor: 0.85,
        necklaceAnchors: {
          leftEnd: { x: 0.14, y: 0.04 },
          rightEnd: { x: 0.86, y: 0.04 },
          pendantCenter: { x: 0.50, y: 0.82 },
          bottomCenter: { x: 0.50, y: 0.94 },
        },
      },
      earrings: {
        id: "earrings_lotus_drops",
        name: "Lotus Motif Gold Drops",
        category: "earrings",
        src: "/catalog/earrings/gold_earrings_11.png",
        anchor: { x: 0.5, y: 0.08 },
        type: "jhumka",
        widthRatio: 0.18,
        scaleFactor: 0.14,
      },
    },
    setNecklaceSrc: "/catalog/necklace/gold_necklace_09.png",
    setEarringsSrc: "/catalog/earrings/gold_earrings_11.png",
  },
  {
    id: "set_maharani_hasli",
    name: "Maharani Gold Hasli & Teardrop Set",
    category: "sets",
    price: "$19,800",
    src: "/catalog/sets/gold_set_05.png",
    anchor: { x: 0.5, y: 0.0 },
    necklaceAnchors: {
      leftEnd: { x: 0.14, y: 0.04 },
      rightEnd: { x: 0.86, y: 0.04 },
      pendantCenter: { x: 0.50, y: 0.85 },
      bottomCenter: { x: 0.50, y: 0.94 },
    },
    setPieces: {
      necklace: {
        id: "necklace_maharani_hasli",
        name: "Maharani Gold Hasli",
        category: "necklaces",
        src: "/catalog/necklace/gold_necklace_10.png",
        anchor: { x: 0.5, y: 0.0 },
        type: "choker",
        widthRatio: 0.75,
        scaleFactor: 1.0,
        necklaceAnchors: {
          leftEnd: { x: 0.14, y: 0.04 },
          rightEnd: { x: 0.86, y: 0.04 },
          pendantCenter: { x: 0.50, y: 0.85 },
          bottomCenter: { x: 0.50, y: 0.94 },
        },
      },
      earrings: {
        id: "earrings_sleek_teardrop",
        name: "Sleek Teardrop Gold Earrings",
        category: "earrings",
        src: "/catalog/earrings/gold_earrings_14.png",
        anchor: { x: 0.5, y: 0.08 },
        type: "jhumka",
        widthRatio: 0.18,
        scaleFactor: 0.14,
      },
    },
    setNecklaceSrc: "/catalog/necklace/gold_necklace_10.png",
    setEarringsSrc: "/catalog/earrings/gold_earrings_14.png",
  },
  {
    id: "set_peacock_bali",
    name: "Peacock Crest & Bali Grand Suite",
    category: "sets",
    price: "$24,500",
    src: "/catalog/sets/gold_set_06.png",
    anchor: { x: 0.5, y: 0.0 },
    necklaceAnchors: {
      leftEnd: { x: 0.14, y: 0.04 },
      rightEnd: { x: 0.86, y: 0.04 },
      pendantCenter: { x: 0.50, y: 0.85 },
      bottomCenter: { x: 0.50, y: 0.94 },
    },
    setPieces: {
      necklace: {
        id: "necklace_peacock_crest",
        name: "Peacock Crest Gold Necklace",
        category: "necklaces",
        src: "/catalog/necklace/gold_necklace_12.png",
        anchor: { x: 0.5, y: 0.0 },
        type: "choker",
        widthRatio: 0.78,
        scaleFactor: 1.0,
        necklaceAnchors: {
          leftEnd: { x: 0.14, y: 0.04 },
          rightEnd: { x: 0.86, y: 0.04 },
          pendantCenter: { x: 0.50, y: 0.85 },
          bottomCenter: { x: 0.50, y: 0.94 },
        },
      },
      earrings: {
        id: "earrings_heritage_bali",
        name: "Heritage Gold Bali",
        category: "earrings",
        src: "/catalog/earrings/gold_earrings_07.png",
        anchor: { x: 0.5, y: 0.08 },
        type: "jhumka",
        widthRatio: 0.18,
        scaleFactor: 0.14,
      },
    },
    setNecklaceSrc: "/catalog/necklace/gold_necklace_12.png",
    setEarringsSrc: "/catalog/earrings/gold_earrings_07.png",
  },
  {
    id: "set_princess_diamond",
    name: "Princess Diamond Collar & Studs Suite",
    category: "sets",
    price: "$26,500",
    src: "/catalog/sets/gold_set_07.png",
    anchor: { x: 0.5, y: 0.0 },
    necklaceAnchors: {
      leftEnd: { x: 0.14, y: 0.04 },
      rightEnd: { x: 0.86, y: 0.04 },
      pendantCenter: { x: 0.50, y: 0.85 },
      bottomCenter: { x: 0.50, y: 0.94 },
    },
    setPieces: {
      necklace: {
        id: "necklace_princess_collar",
        name: "Princess Diamond Collar",
        category: "necklaces",
        src: "/catalog/necklace/gold_necklace_16.png",
        anchor: { x: 0.5, y: 0.0 },
        type: "choker",
        widthRatio: 0.75,
        scaleFactor: 1.0,
        necklaceAnchors: {
          leftEnd: { x: 0.14, y: 0.04 },
          rightEnd: { x: 0.86, y: 0.04 },
          pendantCenter: { x: 0.50, y: 0.85 },
          bottomCenter: { x: 0.50, y: 0.94 },
        },
      },
      earrings: {
        id: "earrings_classic_studs",
        name: "Classic Diamond Studs",
        category: "earrings",
        src: "/catalog/earrings/gold_earrings_03.png",
        anchor: { x: 0.5, y: 0.5 },
        type: "stud",
        widthRatio: 0.10,
        scaleFactor: 0.08,
      },
    },
    setNecklaceSrc: "/catalog/necklace/gold_necklace_16.png",
    setEarringsSrc: "/catalog/earrings/gold_earrings_03.png",
  },
];

export interface JewelleryCategoryData {
  id: string;
  name: string;
  items: JewelleryItem[];
}

interface JewelleryStoreContextType {
  selectedItem: SelectedItem | null;
  activeItems: Record<string, SelectedItem | undefined>;
  activeCategories: Set<string>;
  activeCategory: ActiveCategory;
  metal: MetalType;
  isLoadingAsset: boolean;
  allCategories: JewelleryCategoryData[];
  selectedCategory: string;
  debugOverlayText: string;
  setMetal: (m: MetalType) => void;
  setSelectedCategory: (cat: string) => void;
  selectItem: (item: JewelleryItem, cat?: string) => void;
  toggleCategoryActive: (cat: string) => void;
  addUploadedItem: (item: StoredJewelleryItem) => Promise<void>;
  notifyAssetLoaded: (itemId: string) => void;
}

const JewelleryStoreContext = createContext<JewelleryStoreContextType | null>(null);

const CATEGORY_NAMES: Record<string, string> = {
  necklaces: "Necklaces",
  earrings: "Earrings",
  rings: "Rings",
  bangles: "Bangles",
  noserings: "Nose Rings",
  sets: "Sets",
  // Aliases
  necklace: "Necklaces",
  finger_ring: "Rings",
  nose_ring: "Nose Rings",
};

const CATEGORY_ORDER = ["necklaces", "earrings", "rings", "bangles", "noserings", "sets"];

function configToJewelleryItem(cfg: JewelConfig): JewelleryItem {
  const tryon = TRYON_ASSET_MAPPINGS[cfg.id];
  return {
    id: cfg.id,
    name: cfg.name,
    category: cfg.category,
    price: cfg.price,
    src: tryon?.src || "",
    anchor: tryon?.anchor || cfg.wearAnchor || { x: 0.5, y: 0.5 },
    necklaceAnchors: tryon?.necklaceAnchors,
    type: tryon?.type || cfg.style,
    style: cfg.style,
    widthRatio: tryon?.widthRatio ?? cfg.wearAnchor.widthRatio,
    scaleFactor: tryon?.scaleFactor ?? cfg.wearAnchor.scaleFactor,
    procedural: true,
    materialsDescription: cfg.materialsDescription,
  };
}

function itemToSelectedItem(item: JewelleryItem, category: string, metal: MetalType): SelectedItem {
  const tryon = TRYON_ASSET_MAPPINGS[item.id];
  const url = item.src || tryon?.src || "";
  return {
    id: item.id,
    category: item.category || category,
    name: item.name,
    imageUrl: url,
    cutoutUrl: url,
    modelUrl: item.modelUrl,
    metal,
    price: item.price,
    type: item.type || tryon?.type,
    style: item.style,
    anchor: item.anchor || tryon?.anchor || { x: 0.5, y: 0.5 },
    necklaceAnchors: item.necklaceAnchors || tryon?.necklaceAnchors,
    widthRatio: item.widthRatio ?? tryon?.widthRatio,
    yOffset: item.yOffset ?? tryon?.yOffset,
    rotationOffset: item.rotationOffset,
    scaleFactor: item.scaleFactor ?? tryon?.scaleFactor,
    procedural: item.procedural,
    isCustom: item.isCustom,
    uprightAngle: item.uprightAngle,
    originalSrc: item.originalSrc,
  };
}

export function JewelleryStoreProvider({ children }: { children: React.ReactNode }) {
  const [metal, setMetalState] = useState<MetalType>("gold");
  const [selectedCategory, setSelectedCategoryState] = useState<string>("necklaces");
  const [isLoadingAsset, setIsLoadingAsset] = useState<boolean>(false);
  const [customItems, setCustomItems] = useState<StoredJewelleryItem[]>([]);

  // Build categories from parametric catalog + Sets
  const baseCategories = useMemo<JewelleryCategoryData[]>(() => {
    return CATEGORY_ORDER.map((catId) => {
      if (catId === "sets") {
        return {
          id: "sets",
          name: "Sets",
          items: SETS_CATALOG,
        };
      }
      const rawCat = catId === "necklaces" ? "necklace" : catId === "rings" ? "finger_ring" : catId === "noserings" ? "nose_ring" : catId;
      const configs = getJewelsByCategory(rawCat as CategoryType);
      return {
        id: catId,
        name: CATEGORY_NAMES[catId] || catId,
        items: configs.map(configToJewelleryItem),
      };
    });
  }, []);

  // Merged categories including custom uploads
  const allCategories = useMemo<JewelleryCategoryData[]>(() => {
    return baseCategories.map((cat) => {
      const customs: JewelleryItem[] = customItems
        .filter((ci) => normalizeCategory(ci.category) === normalizeCategory(cat.id))
        .map((ci) => {
          const lowerName = (ci.name || "").toLowerCase();
          const detectedMetal: MetalType | undefined =
            ci.metal ||
            (lowerName.includes("silver") ? "silver" : lowerName.includes("rose") ? "rose_gold" : undefined);
          return {
            id: ci.id,
            name: ci.name,
            category: cat.id,
            price: ci.price || "Custom",
            src: ci.src,
            anchor: ci.anchor || { x: 0.5, y: 0.5 },
            necklaceAnchors: ci.necklaceAnchors,
            type: ci.type || "custom",
            widthRatio: ci.widthRatio || 0.5,
            scaleFactor: ci.scaleFactor || 0.5,
            yOffset: ci.yOffset || 0,
            modelUrl: ci.modelUrl,
            metal: detectedMetal,
            isCustom: true,
            uprightAngle: ci.uprightAngle,
            originalSrc: ci.originalSrc,
          } as JewelleryItem;
        });
      return {
        ...cat,
        items: [...customs, ...cat.items],
      };
    });
  }, [baseCategories, customItems]);

  // Initial selection
  const [selectedItem, setSelectedItemState] = useState<SelectedItem | null>(() => {
    const firstCat = baseCategories[0];
    const firstItem = firstCat?.items?.[0];
    return firstItem ? itemToSelectedItem(firstItem, firstCat.id, "gold") : null;
  });

  const [activeItems, setActiveItems] = useState<Record<string, SelectedItem | undefined>>(() => {
    const firstCat = baseCategories[0];
    const firstItem = firstCat?.items?.[0];
    if (!firstItem) return {};
    const sel = itemToSelectedItem(firstItem, firstCat.id, "gold");
    return {
      necklace: sel,
      necklaces: sel,
    };
  });

  const activeCategory = useMemo<ActiveCategory>(() => {
    return normalizeCategory(selectedCategory);
  }, [selectedCategory]);

  const activeCategories = useMemo<Set<string>>(() => {
    return new Set([activeCategory]);
  }, [activeCategory]);

  // Load custom items from IndexedDB
  useEffect(() => {
    getAllCustomJewels()
      .then((items) => {
        if (items && items.length > 0) {
          setCustomItems(items);
        }
      })
      .catch((e) => console.warn("Failed to load custom jewels:", e));
  }, []);

  const setMetal = useCallback((newMetal: MetalType) => {
    setMetalState(newMetal);
    setSelectedItemState((prev) => (prev ? { ...prev, metal: newMetal } : null));
    setActiveItems((prev) => {
      const next: Record<string, SelectedItem | undefined> = {};
      for (const [k, v] of Object.entries(prev)) {
        next[k] = v ? { ...v, metal: newMetal } : undefined;
      }
      return next;
    });
  }, []);

  const selectItem = useCallback(
    (item: JewelleryItem, catOverride?: string) => {
      const cat = catOverride || item.category || selectedCategory || "necklaces";
      const normCat = normalizeCategory(cat);

      // Auto-detect metal from item preference or name (e.g. Silver Bracelet)
      const lowerName = (item.name || "").toLowerCase();
      let itemMetal: MetalType = metal;
      if (item.metal) {
        itemMetal = item.metal;
      } else if (lowerName.includes("silver")) {
        itemMetal = "silver";
      } else if (lowerName.includes("rose")) {
        itemMetal = "rose_gold";
      }

      if (itemMetal !== metal) {
        setMetalState(itemMetal);
      }

      const sel = itemToSelectedItem(item, normCat, itemMetal);

      setIsLoadingAsset(true);
      setSelectedItemState(sel);
      setSelectedCategoryState(normCat);

      if (normCat === "sets" && item.setPieces) {
        const neckSel = itemToSelectedItem(item.setPieces.necklace, "necklace", itemMetal);
        const earSel = itemToSelectedItem(item.setPieces.earrings, "earrings", itemMetal);
        setActiveItems({
          necklace: neckSel,
          necklaces: neckSel,
          earrings: earSel,
          sets: sel,
        });
      } else if (normCat === "necklaces") {
        setActiveItems({
          necklace: sel,
          necklaces: sel,
        });
      } else if (normCat === "earrings") {
        setActiveItems({
          earrings: sel,
        });
      } else if (normCat === "rings") {
        setActiveItems({
          finger_ring: sel,
          rings: sel,
        });
      } else if (normCat === "bangles") {
        setActiveItems({
          bangles: sel,
        });
      } else if (normCat === "noserings") {
        setActiveItems({
          nose_ring: sel,
          noserings: sel,
        });
      }

      setTimeout(() => {
        setIsLoadingAsset(false);
      }, 250);
    },
    [metal, selectedCategory]
  );

  const setSelectedCategory = useCallback(
    (cat: string) => {
      const normCat = normalizeCategory(cat);
      setSelectedCategoryState(normCat);
      const targetCat = allCategories.find((c) => c.id === normCat || normalizeCategory(c.id) === normCat);
      if (targetCat && targetCat.items.length > 0) {
        selectItem(targetCat.items[0], normCat);
      } else {
        setActiveItems({});
        setSelectedItemState(null);
      }
    },
    [allCategories, selectItem]
  );

  const notifyAssetLoaded = useCallback(
    (itemId: string) => {
      if (selectedItem?.id === itemId) {
        setIsLoadingAsset(false);
      }
    },
    [selectedItem?.id]
  );

  const toggleCategoryActive = useCallback((cat: string) => {
    // Single category source of truth
    const norm = normalizeCategory(cat);
    setSelectedCategory(norm);
  }, [setSelectedCategory]);

  const addUploadedItem = useCallback(
    async (item: StoredJewelleryItem) => {
      await saveCustomJewel(item);
      setCustomItems((prev) => [item, ...prev]);

      const jewItem: JewelleryItem = {
        id: item.id,
        name: item.name,
        category: item.category,
        price: item.price || "Custom",
        src: item.src,
        anchor: item.anchor,
        type: item.type,
        widthRatio: item.widthRatio,
        scaleFactor: item.scaleFactor,
        modelUrl: item.modelUrl,
      };

      const norm = normalizeCategory(item.category);
      selectItem(jewItem, norm);
    },
    [selectItem]
  );

  const debugOverlayText = useMemo(() => {
    if (!selectedItem) return "No item selected";
    return `[Debug] ID: ${selectedItem.id} | Model: ${selectedItem.style || selectedItem.type || "parametric"}`;
  }, [selectedItem]);

  const value = useMemo(
    () => ({
      selectedItem,
      activeItems,
      activeCategories,
      activeCategory,
      metal,
      isLoadingAsset,
      allCategories,
      selectedCategory,
      debugOverlayText,
      setMetal,
      setSelectedCategory,
      selectItem,
      toggleCategoryActive,
      addUploadedItem,
      notifyAssetLoaded,
    }),
    [
      selectedItem,
      activeItems,
      activeCategories,
      activeCategory,
      metal,
      isLoadingAsset,
      allCategories,
      selectedCategory,
      debugOverlayText,
      setMetal,
      setSelectedCategory,
      selectItem,
      toggleCategoryActive,
      addUploadedItem,
      notifyAssetLoaded,
    ]
  );

  return (
    <JewelleryStoreContext.Provider value={value}>
      {children}
    </JewelleryStoreContext.Provider>
  );
}

export function useJewelleryStore() {
  const ctx = useContext(JewelleryStoreContext);
  if (!ctx) {
    throw new Error("useJewelleryStore must be used within a JewelleryStoreProvider");
  }
  return ctx;
}
