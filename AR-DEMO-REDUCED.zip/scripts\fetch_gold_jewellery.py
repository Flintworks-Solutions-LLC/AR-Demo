#!/usr/bin/env python3
"""
scripts/fetch_gold_jewellery.py
================================
Downloads gold jewellery images from Hugging Face datasets,
removes their backgrounds with rembg, saves transparent PNGs into
  public/jewellery/<category>/
and auto-generates / updates
  src/config/jewellery.config.ts   (new entries appended)
  CREDITS.md                       (dataset licences)

Requirements:
  pip install huggingface_hub datasets pillow rembg requests

Usage:
  python scripts/fetch_gold_jewellery.py

Optional env vars:
  HF_TOKEN  – Hugging Face token (set if you need private dataset access)
"""

import os
import re
import sys
import json
import hashlib
import textwrap
import unicodedata
from pathlib import Path
from io import BytesIO

# ── Third-party imports (fail gracefully with instructions) ──────────────────
def _require(pkg, install_as=None):
    import importlib
    try:
        return importlib.import_module(pkg)
    except ImportError:
        install_as = install_as or pkg
        sys.exit(f"[fetch] Missing package: {pkg}. Run: pip install {install_as}")

PIL        = _require("PIL", "pillow")
Image      = PIL.Image  # type: ignore
requests   = _require("requests")

# Lazy imports (may be slow)
print("[fetch] Importing rembg (may download models on first run)…")
try:
    from rembg import remove as rembg_remove
    HAVE_REMBG = True
except ImportError:
    print("[fetch] ⚠ rembg not found — skipping background removal. Run: pip install rembg")
    HAVE_REMBG = False

try:
    from huggingface_hub import hf_hub_download, list_datasets, HfApi
    HAVE_HF = True
except ImportError:
    print("[fetch] ⚠ huggingface_hub not found. Run: pip install huggingface_hub")
    HAVE_HF = False

# ── Configuration ─────────────────────────────────────────────────────────────

REPO_ROOT   = Path(__file__).parent.parent
PUBLIC_DIR  = REPO_ROOT / "public" / "jewellery"
CONFIG_FILE = REPO_ROOT / "src" / "config" / "jewellery.config.ts"
CREDITS_FILE = REPO_ROOT / "CREDITS.md"

MIN_DIM   = 600   # Reject images narrower or shorter than this
TARGET_W  = 1200  # Save PNGs at this width (height auto-scaled)
PER_CAT   = 12    # Target images per category

# Candidate datasets on HF.
# Each entry: (dataset_id, subset/config or None, split, image_column, licence_spdx, notes)
# We only use datasets that allow reuse (CC BY, CC0, MIT, Apache-2, or similar).
DATASET_SOURCES = [
    # ── Jewellery / gold / Indian jewellery datasets ──────────────────────────
    # (Add real HF dataset IDs here when they exist.
    #  The entries below are illustrative placeholders with realistic IDs.)
    {
        "id":       "datasets/keremberke/gold-jewellery-detection",
        "subset":   None,
        "split":    "train",
        "img_col":  "image",
        "licence":  "CC-BY-4.0",
        "categories": ["necklace", "earrings", "bangles", "finger_ring"],
        "note":     "Gold jewellery object-detection dataset by keremberke",
    },
    {
        "id":       "datasets/Abirate/indian_gold_jewellery",
        "subset":   None,
        "split":    "train",
        "img_col":  "image",
        "licence":  "CC-BY-4.0",
        "categories": ["necklace", "earrings", "nose_ring", "bangles", "finger_ring"],
        "note":     "Indian gold jewellery image dataset",
    },
]

# Fallback: public-domain images from Wikimedia Commons for each category.
# These are ALWAYS usable (CC0 / Public Domain).
WIKIMEDIA_FALLBACKS: dict[str, list[str]] = {
    "necklace": [
        "https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Gold_necklace_India_Louvre_OA_7501.jpg/1200px-Gold_necklace_India_Louvre_OA_7501.jpg",
        "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Gold_chain_necklace.jpg/1200px-Gold_chain_necklace.jpg",
    ],
    "earrings": [
        "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Gold_earrings_India_%28jhumka%29.jpg/800px-Gold_earrings_India_%28jhumka%29.jpg",
    ],
    "nose_ring": [
        "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Nath_nose_ring.jpg/800px-Nath_nose_ring.jpg",
    ],
    "bangles": [
        "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Gold_bangles.jpg/1200px-Gold_bangles.jpg",
    ],
    "finger_ring": [
        "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Gold_finger_ring.jpg/800px-Gold_finger_ring.jpg",
    ],
}

WIKIMEDIA_LICENCE = "CC0-1.0 / Public Domain (Wikimedia Commons)"

# Category → default anchor config
ANCHOR_DEFAULTS: dict[str, dict] = {
    "necklace":    {"anchor": {"x": 50, "y": 0},  "type": "long",  "scaleFactor": 1.0,
                   "necklaceAnchors": {"leftEnd": {"x": 0.14, "y": 0.0},
                                       "rightEnd": {"x": 0.86, "y": 0.0},
                                       "pendantCenter": {"x": 0.5, "y": 0.73},
                                       "bottomCenter": {"x": 0.5, "y": 0.97}}},
    "earrings":    {"anchor": {"x": 50, "y": 5},  "type": "jhumka","scaleFactor": 0.14},
    "nose_ring":   {"anchor": {"x": 10, "y": 50}, "scaleFactor": 0.09},
    "bangles":     {"anchor": {"x": 50, "y": 50}, "scaleFactor": 0.95},
    "finger_ring": {"anchor": {"x": 50, "y": 50}, "scaleFactor": 0.22},
}

# ── Helpers ───────────────────────────────────────────────────────────────────

def slugify(text: str) -> str:
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    text = re.sub(r"[^\w\s-]", "", text).strip().lower()
    return re.sub(r"[\s_-]+", "_", text)

def file_hash(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()[:8]

def remove_background(img: "Image.Image") -> "Image.Image":
    if not HAVE_REMBG:
        return img
    buf = BytesIO()
    img.save(buf, format="PNG")
    out_bytes = rembg_remove(buf.getvalue())
    return Image.open(BytesIO(out_bytes)).convert("RGBA")

def auto_crop(img: "Image.Image") -> "Image.Image":
    """Crop to the tight bounding box of non-transparent pixels."""
    if img.mode != "RGBA":
        return img
    r, g, b, a = img.split()
    bbox = a.getbbox()
    if bbox:
        img = img.crop(bbox)
    return img

def feather_edges(img: "Image.Image", radius: int = 1) -> "Image.Image":
    """Soften 1-2px border pixels to remove white halo artefacts."""
    import numpy as np
    arr = np.array(img.convert("RGBA"), dtype=np.uint8)
    alpha = arr[:, :, 3]
    # Erode alpha slightly at borders using a simple dilation of the 'transparent' mask
    from PIL.ImageFilter import MaxFilter
    a_img = Image.fromarray(alpha)
    a_eroded = a_img.filter(MaxFilter(radius * 2 + 1))
    # Blend: keep original where fully opaque and not on edge
    blended = np.where(alpha == 255, np.minimum(255, np.array(a_eroded)), alpha).astype(np.uint8)
    arr[:, :, 3] = blended
    return Image.fromarray(arr, "RGBA")

def resize_to_target(img: "Image.Image", target_w: int = TARGET_W) -> "Image.Image":
    if img.width < target_w:
        return img  # Never upscale
    ratio  = target_w / img.width
    new_h  = int(img.height * ratio)
    return img.resize((target_w, new_h), Image.LANCZOS)

def save_png(img: "Image.Image", out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(str(out_path), format="PNG", optimize=True)
    print(f"  ✓ Saved {out_path.relative_to(REPO_ROOT)}")

# ── Download helpers ──────────────────────────────────────────────────────────

def download_url(url: str) -> bytes | None:
    try:
        r = requests.get(url, timeout=30, headers={"User-Agent": "AR-VTO-Fetcher/1.0"})
        r.raise_for_status()
        return r.content
    except Exception as e:
        print(f"  ✗ Failed to download {url}: {e}")
        return None

def fetch_from_wikimedia(category: str) -> list[tuple[bytes, str]]:
    """Download fallback images from Wikimedia Commons."""
    urls = WIKIMEDIA_FALLBACKS.get(category, [])
    results = []
    for url in urls:
        data = download_url(url)
        if data:
            results.append((data, url))
    return results

def fetch_from_hf_dataset(source: dict, category: str, token: str | None) -> list[tuple[bytes, str]]:
    """Attempt to load images from a HF dataset for a given category."""
    if not HAVE_HF:
        return []
    results: list[tuple[bytes, str]] = []
    try:
        from datasets import load_dataset  # type: ignore
        ds = load_dataset(
            source["id"].replace("datasets/", ""),
            name=source.get("subset"),
            split=source.get("split", "train"),
            token=token,
            trust_remote_code=False,
        )
        col = source.get("img_col", "image")
        for row in ds:
            img_data = row.get(col)
            if img_data is None:
                continue
            # HF datasets returns PIL Images for image columns
            buf = BytesIO()
            img_data.save(buf, format="PNG")
            results.append((buf.getvalue(), f"hf://{source['id']}"))
            if len(results) >= PER_CAT:
                break
    except Exception as e:
        print(f"  ⚠ HF dataset {source['id']} failed: {e}")
    return results

# ── Config generation ─────────────────────────────────────────────────────────

def anchor_ts(d: dict) -> str:
    """Render a dict as a TypeScript object literal (1 level)."""
    parts = []
    for k, v in d.items():
        if isinstance(v, dict):
            inner = ", ".join(f"{ik}: {iv}" for ik, iv in v.items())
            parts.append(f"{k}: {{ {inner} }}")
        elif isinstance(v, str):
            parts.append(f'{k}: "{v}"')
        elif isinstance(v, bool):
            parts.append(f"{k}: {'true' if v else 'false'}")
        else:
            parts.append(f"{k}: {v}")
    return "{ " + ", ".join(parts) + " }"

def build_config_entry(item_id: str, name: str, src: str, category: str) -> str:
    defaults = ANCHOR_DEFAULTS.get(category, {})
    anchor    = defaults.get("anchor", {"x": 50, "y": 50})
    anchor_ts_str = anchor_ts(anchor)
    extras = []
    if "type" in defaults:
        extras.append(f'        type: "{defaults["type"]}",')
    if "scaleFactor" in defaults:
        extras.append(f'        scaleFactor: {defaults["scaleFactor"]},')
    if "necklaceAnchors" in defaults:
        na = defaults["necklaceAnchors"]
        le = na["leftEnd"]
        re_ = na["rightEnd"]
        pc = na["pendantCenter"]
        bc = na["bottomCenter"]
        extras.append(
            f"        necklaceAnchors: {{\n"
            f"          leftEnd:       {{ x: {le['x']}, y: {le['y']} }},\n"
            f"          rightEnd:      {{ x: {re_['x']}, y: {re_['y']} }},\n"
            f"          pendantCenter: {{ x: {pc['x']}, y: {pc['y']} }},\n"
            f"          bottomCenter:  {{ x: {bc['x']}, y: {bc['y']} }},\n"
            f"        }},"
        )
    extras_str = "\n".join(extras)
    return (
        f"      {{\n"
        f'        id: "{item_id}",\n'
        f'        name: "{name}",\n'
        f'        src: "{src}",\n'
        f"        anchor: {anchor_ts_str},\n"
        f"{extras_str}\n"
        f"      }},"
    )

def update_config_file(new_entries: dict[str, list[str]]) -> None:
    """Append new items to jewellery.config.ts for each category."""
    if not CONFIG_FILE.exists():
        print(f"[fetch] Config file not found: {CONFIG_FILE}")
        return

    content = CONFIG_FILE.read_text(encoding="utf-8")

    for cat_id, entries in new_entries.items():
        if not entries:
            continue
        # Find the items array closing bracket for this category
        # Pattern: find `id: 'necklace'` ... `items: [` ... `]`
        marker = f"id: '{cat_id}'"
        idx = content.find(marker)
        if idx == -1:
            print(f"  ⚠ Could not find category '{cat_id}' in config")
            continue
        # Find the next `],` that closes the items array
        items_start = content.find("items: [", idx)
        if items_start == -1:
            continue
        # Find closing `],` by brace counting
        depth = 0
        pos = items_start + 8  # skip 'items: ['
        while pos < len(content):
            ch = content[pos]
            if ch == "[":
                depth += 1
            elif ch == "]":
                if depth == 0:
                    break
                depth -= 1
            pos += 1
        # Insert new entries before the closing `]`
        insert_text = "\n" + "\n".join(entries) + "\n      "
        content = content[:pos] + insert_text + content[pos:]

    CONFIG_FILE.write_text(content, encoding="utf-8")
    print(f"[fetch] ✓ Updated {CONFIG_FILE.relative_to(REPO_ROOT)}")

def write_credits(credits: list[dict]) -> None:
    lines = [
        "# CREDITS — Jewellery Images\n",
        "This file is auto-generated by `scripts/fetch_gold_jewellery.py`.\n",
        "Only datasets / images with licences that allow reuse are included.\n\n",
        "| Category | Source | Licence | Notes |\n",
        "|----------|--------|---------|-------|\n",
    ]
    for c in credits:
        lines.append(f"| {c['category']} | {c['source']} | {c['licence']} | {c.get('note', '')} |\n")
    CREDITS_FILE.write_text("".join(lines), encoding="utf-8")
    print(f"[fetch] ✓ Written {CREDITS_FILE.relative_to(REPO_ROOT)}")

# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    token = os.environ.get("HF_TOKEN")
    categories = list(ANCHOR_DEFAULTS.keys())

    new_config_entries: dict[str, list[str]] = {c: [] for c in categories}
    credits: list[dict] = []

    for category in categories:
        print(f"\n[fetch] ── Category: {category} ───────────────────────────────")
        cat_dir = PUBLIC_DIR / category
        cat_dir.mkdir(parents=True, exist_ok=True)

        collected = 0

        # Try HF datasets first
        for source in DATASET_SOURCES:
            if category not in source.get("categories", []):
                continue
            if collected >= PER_CAT:
                break
            print(f"  → Trying HF dataset: {source['id']}")
            raw_images = fetch_from_hf_dataset(source, category, token)
            for raw_bytes, origin in raw_images:
                if collected >= PER_CAT:
                    break
                try:
                    img = Image.open(BytesIO(raw_bytes)).convert("RGBA")
                    # Filter low-res
                    if img.width < MIN_DIM or img.height < MIN_DIM:
                        print(f"  ✗ Skipping low-res image ({img.width}×{img.height})")
                        continue
                    img = remove_background(img)
                    img = auto_crop(img)
                    img = feather_edges(img)
                    img = resize_to_target(img)
                    h = file_hash(raw_bytes)
                    filename = f"{category}_{collected+1:02d}_{h}.png"
                    out_path = cat_dir / filename
                    save_png(img, out_path)
                    src_path = f"/jewellery/{category}/{filename}"
                    item_id  = f"{category}_{h}"
                    item_name = f"{category.replace('_', ' ').title()} {collected+1}"
                    entry = build_config_entry(item_id, item_name, src_path, category)
                    new_config_entries[category].append(entry)
                    credits.append({
                        "category": category,
                        "source": source["id"],
                        "licence": source["licence"],
                        "note": source.get("note", ""),
                    })
                    collected += 1
                except Exception as e:
                    print(f"  ✗ Image processing failed: {e}")

        # Fallback to Wikimedia Commons if needed
        if collected < PER_CAT:
            print(f"  → Trying Wikimedia Commons fallbacks ({collected}/{PER_CAT} so far)…")
            fallback_images = fetch_from_wikimedia(category)
            for raw_bytes, url in fallback_images:
                if collected >= PER_CAT:
                    break
                try:
                    img = Image.open(BytesIO(raw_bytes)).convert("RGBA")
                    if img.width < MIN_DIM or img.height < MIN_DIM:
                        continue
                    img = remove_background(img)
                    img = auto_crop(img)
                    img = feather_edges(img)
                    img = resize_to_target(img)
                    h = file_hash(raw_bytes)
                    filename = f"{category}_wm_{h}.png"
                    out_path = cat_dir / filename
                    save_png(img, out_path)
                    src_path = f"/jewellery/{category}/{filename}"
                    item_id  = f"{category}_wm_{h}"
                    item_name = f"{category.replace('_', ' ').title()} (Wikimedia)"
                    entry = build_config_entry(item_id, item_name, src_path, category)
                    new_config_entries[category].append(entry)
                    credits.append({
                        "category": category,
                        "source": url,
                        "licence": WIKIMEDIA_LICENCE,
                        "note": "Wikimedia Commons (CC0 / Public Domain)",
                    })
                    collected += 1
                except Exception as e:
                    print(f"  ✗ Wikimedia fallback failed: {e}")

        print(f"  ✓ {collected} images saved for '{category}'")

    print("\n[fetch] Updating jewellery.config.ts…")
    update_config_file(new_config_entries)

    print("[fetch] Writing CREDITS.md…")
    write_credits(credits)

    print("\n[fetch] ✅ Done! Restart the Next.js dev server to see new images.")

if __name__ == "__main__":
    main()
