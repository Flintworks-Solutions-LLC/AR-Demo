/**
 * Advanced Jewellery Background Removal
 * 
 * 1. Upscale if long side < 1200px (2x with high-quality smoothing)
 * 2. Background sampling from 4 corners and borders
 * 3. Seeded border flood-fill (BFS) with tolerance.
 *    White areas enclosed by jewellery (diamonds, halos) remain untouched & opaque.
 * 4. Alpha mask generation with morphological close (fills micro-cracks in links/prongs)
 *    and speck removal.
 * 5. 1px edge feathering + color decontamination / un-premultiplication to remove white fringe.
 * 6. Auto-crop to bounding box with padding.
 * 7. Optional AI mode via @imgly/background-removal.
 */

export interface BackgroundRemovalOptions {
  tolerance?: number;        // Color distance tolerance (default ~28)
  feather?: number;          // Edge feather radius in px: 0 to 2 (default 1)
  cropPadding?: number;      // Padding in px around cropped jewel (default 8)
  closeRadius?: number;      // Morphological close radius (default 1)
  removeSpecks?: boolean;    // Clean isolated noise specks (default true)
  upscaleSmall?: boolean;    // Upscale 2x if < 1200px (default true)
}

export interface RGB {
  r: number;
  g: number;
  b: number;
}

/**
 * Upscale image 2x with smoothing if long side is under 1200px.
 * Preserves full resolution if >= 1200px.
 */
export function upscaleIfNeeded(srcCanvas: HTMLCanvasElement): HTMLCanvasElement {
  const w = srcCanvas.width;
  const h = srcCanvas.height;
  const longSide = Math.max(w, h);

  if (longSide >= 1200) {
    return srcCanvas;
  }

  const scale = 2;
  const targetW = w * scale;
  const targetH = h * scale;

  const upCanvas = document.createElement("canvas");
  upCanvas.width = targetW;
  upCanvas.height = targetH;
  const ctx = upCanvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return srcCanvas;

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(srcCanvas, 0, 0, targetW, targetH);

  console.info(`[BgRemoval] Upscaled image 2x from ${w}x${h} to ${targetW}x${targetH} for detail preservation`);
  return upCanvas;
}

/**
 * Sample a 5x5 patch around (cx, cy) to get an average background color.
 */
function samplePatchColor(
  data: Uint8ClampedArray,
  w: number,
  h: number,
  cx: number,
  cy: number,
  patchRadius = 3
): RGB {
  let sumR = 0;
  let sumG = 0;
  let sumB = 0;
  let count = 0;

  for (let dy = -patchRadius; dy <= patchRadius; dy++) {
    for (let dx = -patchRadius; dx <= patchRadius; dx++) {
      const px = Math.max(0, Math.min(w - 1, cx + dx));
      const py = Math.max(0, Math.min(h - 1, cy + dy));
      const idx = (py * w + px) * 4;
      sumR += data[idx];
      sumG += data[idx + 1];
      sumB += data[idx + 2];
      count++;
    }
  }

  return {
    r: Math.round(sumR / count),
    g: Math.round(sumG / count),
    b: Math.round(sumB / count),
  };
}

/**
 * Sample the background colors from the 4 corners and the 4 outer edge centers.
 */
export function sampleBackgroundColors(data: Uint8ClampedArray, w: number, h: number): RGB[] {
  const samples: RGB[] = [
    samplePatchColor(data, w, h, 2, 2),                         // Top-Left
    samplePatchColor(data, w, h, w - 3, 2),                     // Top-Right
    samplePatchColor(data, w, h, 2, h - 3),                     // Bottom-Left
    samplePatchColor(data, w, h, w - 3, h - 3),                 // Bottom-Right
    samplePatchColor(data, w, h, Math.floor(w / 2), 2),         // Top-Center
    samplePatchColor(data, w, h, Math.floor(w / 2), h - 3),     // Bottom-Center
    samplePatchColor(data, w, h, 2, Math.floor(h / 2)),         // Left-Center
    samplePatchColor(data, w, h, w - 3, Math.floor(h / 2)),     // Right-Center
  ];

  return samples;
}

/**
 * Measure perceptual distance from pixel color (r, g, b) to background samples.
 * Uses weighted Euclidean distance (redmean approximation) for accurate color distance.
 */
export function isColorMatch(
  r: number,
  g: number,
  b: number,
  samples: RGB[],
  tol: number
): boolean {
  // tol is typically 15 - 45
  const tolSq = tol * tol;

  for (let i = 0; i < samples.length; i++) {
    const s = samples[i];
    const dr = r - s.r;
    const dg = g - s.g;
    const db = b - s.b;

    // Per-channel sanity check
    if (Math.abs(dr) <= tol && Math.abs(dg) <= tol && Math.abs(db) <= tol) {
      return true;
    }

    // Weighted Euclidean distance (human eye is more sensitive to green)
    const rMean = (r + s.r) * 0.5;
    const weightR = 2 + rMean / 256;
    const weightG = 4.0;
    const weightB = 2 + (255 - rMean) / 256;
    const distSq = (weightR * dr * dr + weightG * dg * dg + weightB * db * db) / 3;

    if (distSq <= tolSq) {
      return true;
    }
  }

  return false;
}

/**
 * Seed flood fill from outer border pixels.
 * Visited pixels = 1 (Background to remove).
 * Unvisited pixels = 0 (Foreground / Jewellery).
 * 
 * Crucially: Any interior white pixels (diamonds, halo centers, enclosed chain loops)
 * NOT connected to the outer border will NEVER be visited and remain completely opaque!
 */
export function floodFillBorder(
  data: Uint8ClampedArray,
  w: number,
  h: number,
  samples: RGB[],
  tol: number
): Uint8Array {
  const numPixels = w * h;
  const visited = new Uint8Array(numPixels);
  const queue = new Int32Array(numPixels);
  let head = 0;
  let tail = 0;

  const tryEnqueue = (x: number, y: number) => {
    const idx = y * w + x;
    if (visited[idx] === 1) return;

    const pIdx = idx * 4;
    const r = data[pIdx];
    const g = data[pIdx + 1];
    const b = data[pIdx + 2];
    const a = data[pIdx + 3];

    // If already transparent or matches background color samples
    if (a < 20 || isColorMatch(r, g, b, samples, tol)) {
      visited[idx] = 1;
      queue[tail++] = idx;
    }
  };

  // Seed all 4 outer borders
  for (let x = 0; x < w; x++) {
    tryEnqueue(x, 0);         // Top edge
    tryEnqueue(x, h - 1);     // Bottom edge
  }
  for (let y = 0; y < h; y++) {
    tryEnqueue(0, y);         // Left edge
    tryEnqueue(w - 1, y);     // Right edge
  }

  // BFS traversal (4-connected)
  while (head < tail) {
    const curr = queue[head++];
    const cx = curr % w;
    const cy = (curr / w) | 0;

    // Check 4 neighbors
    if (cx + 1 < w) {
      const nIdx = curr + 1;
      if (visited[nIdx] === 0) {
        const p = nIdx * 4;
        if (data[p + 3] < 20 || isColorMatch(data[p], data[p + 1], data[p + 2], samples, tol)) {
          visited[nIdx] = 1;
          queue[tail++] = nIdx;
        }
      }
    }
    if (cx - 1 >= 0) {
      const nIdx = curr - 1;
      if (visited[nIdx] === 0) {
        const p = nIdx * 4;
        if (data[p + 3] < 20 || isColorMatch(data[p], data[p + 1], data[p + 2], samples, tol)) {
          visited[nIdx] = 1;
          queue[tail++] = nIdx;
        }
      }
    }
    if (cy + 1 < h) {
      const nIdx = curr + w;
      if (visited[nIdx] === 0) {
        const p = nIdx * 4;
        if (data[p + 3] < 20 || isColorMatch(data[p], data[p + 1], data[p + 2], samples, tol)) {
          visited[nIdx] = 1;
          queue[tail++] = nIdx;
        }
      }
    }
    if (cy - 1 >= 0) {
      const nIdx = curr - w;
      if (visited[nIdx] === 0) {
        const p = nIdx * 4;
        if (data[p + 3] < 20 || isColorMatch(data[p], data[p + 1], data[p + 2], samples, tol)) {
          visited[nIdx] = 1;
          queue[tail++] = nIdx;
        }
      }
    }
  }

  return visited;
}

/**
 * Morphological close (dilation then erosion) on the foreground mask.
 * Closes hairline gaps (1-2px) in fine chains, diamond prong settings, and halo borders.
 */
export function morphologicalClose(
  mask: Uint8Array,
  w: number,
  h: number,
  radius: number = 1
): Uint8Array {
  if (radius <= 0) return mask;

  const numPixels = w * h;
  const dilated = new Uint8Array(numPixels);
  const closed = new Uint8Array(numPixels);

  // Step 1: Dilation (3x3 window)
  for (let y = 0; y < h; y++) {
    const yOffset = y * w;
    for (let x = 0; x < w; x++) {
      const idx = yOffset + x;
      if (mask[idx] === 1) {
        dilated[idx] = 1;
        continue;
      }
      // Check 8-neighborhood
      let found = false;
      for (let dy = -radius; dy <= radius && !found; dy++) {
        const ny = y + dy;
        if (ny < 0 || ny >= h) continue;
        const nOffset = ny * w;
        for (let dx = -radius; dx <= radius; dx++) {
          const nx = x + dx;
          if (nx < 0 || nx >= w) continue;
          if (mask[nOffset + nx] === 1) {
            found = true;
            break;
          }
        }
      }
      if (found) dilated[idx] = 1;
    }
  }

  // Step 2: Erosion on dilated mask
  for (let y = 0; y < h; y++) {
    const yOffset = y * w;
    for (let x = 0; x < w; x++) {
      const idx = yOffset + x;
      if (dilated[idx] === 0) {
        closed[idx] = 0;
        continue;
      }
      let allOnes = true;
      for (let dy = -radius; dy <= radius && allOnes; dy++) {
        const ny = y + dy;
        if (ny < 0 || ny >= h) continue;
        const nOffset = ny * w;
        for (let dx = -radius; dx <= radius; dx++) {
          const nx = x + dx;
          if (nx < 0 || nx >= w) continue;
          if (dilated[nOffset + nx] === 0) {
            allOnes = false;
            break;
          }
        }
      }
      closed[idx] = allOnes ? 1 : 0;
    }
  }

  return closed;
}

/**
 * Remove tiny isolated specks (dust or stray pixels) in the background.
 */
export function removeSmallSpecks(
  mask: Uint8Array,
  w: number,
  h: number,
  minArea: number = 24
): Uint8Array {
  const numPixels = w * h;
  const visited = new Uint8Array(numPixels);
  const cleaned = new Uint8Array(mask);
  const componentQueue = new Int32Array(numPixels);
  const componentPixels = new Int32Array(minArea + 1);

  for (let i = 0; i < numPixels; i++) {
    if (mask[i] === 0 || visited[i] === 1) continue;

    // BFS to find size of connected component
    let head = 0;
    let tail = 0;
    let count = 0;

    visited[i] = 1;
    componentQueue[tail++] = i;

    while (head < tail) {
      const curr = componentQueue[head++];
      if (count < minArea) {
        componentPixels[count] = curr;
      }
      count++;

      const cx = curr % w;
      const cy = (curr / w) | 0;

      const neighbors = [
        cx + 1 < w ? curr + 1 : -1,
        cx - 1 >= 0 ? curr - 1 : -1,
        cy + 1 < h ? curr + w : -1,
        cy - 1 >= 0 ? curr - w : -1,
      ];

      for (let n = 0; n < 4; n++) {
        const nIdx = neighbors[n];
        if (nIdx !== -1 && mask[nIdx] === 1 && visited[nIdx] === 0) {
          visited[nIdx] = 1;
          componentQueue[tail++] = nIdx;
        }
      }
    }

    // If small isolated speck, erase it
    if (count < minArea) {
      for (let c = 0; c < count; c++) {
        cleaned[componentPixels[c]] = 0;
      }
    }
  }

  return cleaned;
}

/**
 * Edge refinement: 1px feather only (never more than 1px erosion).
 * Un-premultiplies / decontaminates edge colors so there is zero white fringe.
 */
export function applyAlphaMaskAndDecontaminate(
  canvas: HTMLCanvasElement,
  fgMask: Uint8Array,
  feather: number,
  bgSamples: RGB[]
): HTMLCanvasElement {
  const w = canvas.width;
  const h = canvas.height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return canvas;

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // Compute average background color for decontamination
  let avgR = 0, avgG = 0, avgB = 0;
  for (let i = 0; i < bgSamples.length; i++) {
    avgR += bgSamples[i].r;
    avgG += bgSamples[i].g;
    avgB += bgSamples[i].b;
  }
  const bgR = Math.round(avgR / bgSamples.length);
  const bgG = Math.round(avgG / bgSamples.length);
  const bgB = Math.round(avgB / bgSamples.length);

  // Identify 1px boundary pixels
  const isBoundary = new Uint8Array(w * h);

  for (let y = 0; y < h; y++) {
    const yOffset = y * w;
    for (let x = 0; x < w; x++) {
      const idx = yOffset + x;
      if (fgMask[idx] === 0) continue;

      let touchesBg = false;
      for (let dy = -1; dy <= 1 && !touchesBg; dy++) {
        const ny = y + dy;
        if (ny < 0 || ny >= h) { touchesBg = true; break; }
        const nOffset = ny * w;
        for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx;
          if (nx < 0 || nx >= w || fgMask[nOffset + nx] === 0) {
            touchesBg = true;
            break;
          }
        }
      }

      if (touchesBg) {
        isBoundary[idx] = 1;
      }
    }
  }

  // Apply alpha & color decontamination
  // feather = 0 (crisp edge), 1 (1px smooth transition), 2 (slightly softer 1px transition)
  const featherAlpha = feather <= 0 ? 255 : feather === 1 ? 165 : 130;

  for (let i = 0; i < w * h; i++) {
    const pIdx = i * 4;

    if (fgMask[i] === 0) {
      // Pure background pixel
      data[pIdx + 3] = 0;
      continue;
    }

    if (isBoundary[i] === 1 && feather > 0) {
      // 1px boundary pixel: soften alpha and un-premultiply white background
      const alphaVal = featherAlpha;
      data[pIdx + 3] = alphaVal;

      const alphaNorm = alphaVal / 255;
      const invAlpha = 1 - alphaNorm;

      // Un-premultiply / decontaminate: Fg = (Observed - invAlpha * Bg) / alphaNorm
      const origR = data[pIdx];
      const origG = data[pIdx + 1];
      const origB = data[pIdx + 2];

      data[pIdx]     = Math.max(0, Math.min(255, Math.round((origR - invAlpha * bgR) / alphaNorm)));
      data[pIdx + 1] = Math.max(0, Math.min(255, Math.round((origG - invAlpha * bgG) / alphaNorm)));
      data[pIdx + 2] = Math.max(0, Math.min(255, Math.round((origB - invAlpha * bgB) / alphaNorm)));
    } else {
      // Solid foreground pixel: if it's right next to boundary, do subtle de-fringing
      // to remove lighting bleed from white backdrop
      data[pIdx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return canvas;
}

/**
 * Auto-crop canvas to bounding box of remaining non-transparent pixels.
 */
export function autoCrop(srcCanvas: HTMLCanvasElement, pad: number = 8): HTMLCanvasElement {
  const w = srcCanvas.width;
  const h = srcCanvas.height;
  const ctx = srcCanvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return srcCanvas;

  const data = ctx.getImageData(0, 0, w, h).data;
  let minX = w, maxX = 0, minY = h, maxY = 0;
  let foundOpaque = false;

  for (let y = 0; y < h; y++) {
    const yOffset = y * w;
    for (let x = 0; x < w; x++) {
      const alpha = data[(yOffset + x) * 4 + 3];
      if (alpha > 15) {
        foundOpaque = true;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }

  if (!foundOpaque || minX > maxX || minY > maxY) {
    return srcCanvas;
  }

  minX = Math.max(0, minX - pad);
  minY = Math.max(0, minY - pad);
  maxX = Math.min(w - 1, maxX + pad);
  maxY = Math.min(h - 1, maxY + pad);

  const cropW = maxX - minX + 1;
  const cropH = maxY - minY + 1;

  const croppedCanvas = document.createElement("canvas");
  croppedCanvas.width = cropW;
  croppedCanvas.height = cropH;

  const cropCtx = croppedCanvas.getContext("2d");
  if (!cropCtx) return srcCanvas;

  cropCtx.drawImage(srcCanvas, minX, minY, cropW, cropH, 0, 0, cropW, cropH);
  return croppedCanvas;
}

/**
 * Detail-safe Flood Fill Background Removal
 * 
 * Guaranteed to preserve:
 * - Diamond-set links & white gemstone facets (enclosed or inner regions stay 100% opaque)
 * - Fine chain segments (protected by border-only BFS & morphological closing)
 * - Pendant halos
 */
export function removeBackgroundCanvas(
  rawCanvas: HTMLCanvasElement,
  options: BackgroundRemovalOptions = {}
): HTMLCanvasElement {
  const {
    tolerance = 28,
    feather = 1,
    cropPadding = 8,
    closeRadius = 1,
    removeSpecks = true,
    upscaleSmall = true,
  } = options;

  // 1. Upscale if under 1200px on long side for pristine sub-pixel detail
  const workingCanvas = upscaleSmall ? upscaleIfNeeded(rawCanvas) : rawCanvas;
  const w = workingCanvas.width;
  const h = workingCanvas.height;

  // Create clean processing canvas
  const procCanvas = document.createElement("canvas");
  procCanvas.width = w;
  procCanvas.height = h;
  const ctx = procCanvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Could not create canvas 2D context.");

  ctx.drawImage(workingCanvas, 0, 0);
  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // 2. Sample background color from corners and borders
  const bgSamples = sampleBackgroundColors(data, w, h);

  // 3. Flood-fill from borders only (BFS)
  const bgVisited = floodFillBorder(data, w, h, bgSamples, tolerance);

  // 4. Invert to foreground mask (1 = Jewel, 0 = Background)
  const fgMask = new Uint8Array(w * h);
  for (let i = 0; i < w * h; i++) {
    fgMask[i] = bgVisited[i] === 1 ? 0 : 1;
  }

  // 5. Morphological close (fills micro-hairlines between links, prongs)
  const closedMask = closeRadius > 0 ? morphologicalClose(fgMask, w, h, closeRadius) : fgMask;

  // 6. Speck removal (eliminates stray dust spots)
  const cleanMask = removeSpecks ? removeSmallSpecks(closedMask, w, h, 24) : closedMask;

  // 7. 1px Edge feather + Color decontamination (erases white fringe)
  applyAlphaMaskAndDecontaminate(procCanvas, cleanMask, feather, bgSamples);

  // 8. Auto-crop to bounding box
  return autoCrop(procCanvas, cropPadding);
}

/**
 * AI-powered background removal via @imgly/background-removal (client-side)
 * Uses high-quality isnet model.
 */
export async function removeBackgroundAI(
  rawCanvas: HTMLCanvasElement,
  options: BackgroundRemovalOptions = {}
): Promise<HTMLCanvasElement> {
  const { cropPadding = 8, upscaleSmall = true } = options;

  const workingCanvas = upscaleSmall ? upscaleIfNeeded(rawCanvas) : rawCanvas;

  try {
    const { removeBackground } = await import("@imgly/background-removal");

    const blob: Blob = await removeBackground(workingCanvas.toDataURL("image/png"), {
      model: "isnet_fp16",
      progress: (key: string, current: number, total: number) => {
        console.log(`[@imgly AI progress] ${key}: ${(current / total * 100).toFixed(0)}%`);
      },
    });

    const resultUrl = URL.createObjectURL(blob);
    const resultImg = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = resultUrl;
    });
    URL.revokeObjectURL(resultUrl);

    const resultCanvas = document.createElement("canvas");
    resultCanvas.width = resultImg.naturalWidth;
    resultCanvas.height = resultImg.naturalHeight;
    const rCtx = resultCanvas.getContext("2d");
    if (!rCtx) throw new Error("Could not get context for AI result canvas");
    rCtx.drawImage(resultImg, 0, 0);

    // Auto-crop tight to jewel
    return autoCrop(resultCanvas, cropPadding);
  } catch (err) {
    console.warn("[BgRemoval] AI mode encountered an error, gracefully falling back to high-precision algorithmic extraction:", err);
    return removeBackgroundCanvas(rawCanvas, options);
  }
}

