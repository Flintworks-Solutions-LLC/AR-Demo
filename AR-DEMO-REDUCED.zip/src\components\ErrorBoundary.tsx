"use client";

import React, { Component, ErrorInfo, ReactNode } from "react";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("[AR ErrorBoundary] Uncaught component error:", error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      return (
        <div className="w-full max-w-2xl mx-auto my-8 p-6 bg-red-950/70 border border-red-800 rounded-3xl text-center text-slate-100 shadow-2xl backdrop-blur-md">
          <div className="w-12 h-12 mx-auto mb-4 bg-red-500/20 text-red-400 rounded-full flex items-center justify-center text-2xl font-bold">
            ⚠
          </div>
          <h2 className="text-xl font-bold text-red-200 mb-2">Something went wrong</h2>
          <p className="text-sm text-slate-300 mb-4 max-w-md mx-auto">
            {this.state.error?.message || "An unexpected error occurred while running the AR try-on."}
          </p>
          <button
            onClick={this.handleReset}
            className="px-6 py-2.5 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl transition shadow-lg shadow-red-600/30 text-sm"
          >
            Reload Application
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
