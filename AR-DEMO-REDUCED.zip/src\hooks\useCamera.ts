import { useState, useEffect, useRef, useCallback } from "react";

export type CameraStatus = "idle" | "starting" | "active" | "error";

interface UseCameraProps {
  onStreamReady: (videoElement: HTMLVideoElement) => void;
  onPermissionError: (error: string) => void;
}

export function useCamera({ onStreamReady, onPermissionError }: UseCameraProps) {
  const [cameraStatus, setCameraStatus] = useState<CameraStatus>("idle");
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isMetadataLoaded, setIsMetadataLoaded] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const isMountedRef = useRef<boolean>(true);
  const isStartingRef = useRef<boolean>(false);
  const requestIdRef = useRef<number>(0);

  // Stable callback refs
  const onStreamReadyRef = useRef(onStreamReady);
  onStreamReadyRef.current = onStreamReady;
  const onPermissionErrorRef = useRef(onPermissionError);
  onPermissionErrorRef.current = onPermissionError;

  // Enumerate video devices
  const refreshDevices = useCallback(async () => {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    try {
      const allDevices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = allDevices.filter((d) => d.kind === "videoinput");
      setDevices(videoDevices);
      if (videoDevices.length > 0 && !selectedDeviceId) {
        // Default to first video device or one matching current facing mode
        setSelectedDeviceId(videoDevices[0].deviceId);
      }
    } catch (err) {
      console.warn("[useCamera] enumerateDevices error:", err);
    }
  }, [selectedDeviceId]);

  // Initial device enumeration on mount
  useEffect(() => {
    refreshDevices();
  }, [refreshDevices]);

  // Stop camera tracks cleanly
  const stopCamera = useCallback(() => {
    requestIdRef.current++;
    isStartingRef.current = false;

    if (streamRef.current) {
      try {
        streamRef.current.getTracks().forEach((track) => {
          track.stop();
        });
      } catch (err) {
        console.warn("[useCamera] Error stopping stream track:", err);
      }
      streamRef.current = null;
    }

    if (videoRef.current) {
      try {
        const srcObj = videoRef.current.srcObject as MediaStream | null;
        if (srcObj && srcObj !== streamRef.current) {
          srcObj.getTracks().forEach((t) => t.stop());
        }
      } catch {}
      videoRef.current.srcObject = null;
    }

    setIsCameraActive(false);
    setIsMetadataLoaded(false);
    setCameraStatus("idle");
  }, []);

  /**
   * Start camera with user-gesture trigger, flexible constraints,
   * OverconstrainedError auto-fallback to { video: true }, and comprehensive error handling.
   */
  const startCamera = useCallback(
    async (targetDeviceId?: string) => {
      // Prevent overlapping start calls
      if (isStartingRef.current) {
        console.log("[useCamera] startCamera already in progress, ignoring duplicate call.");
        return;
      }

      const currentRequestId = ++requestIdRef.current;
      isStartingRef.current = true;
      setCameraStatus("starting");
      setErrorMessage(null);
      setIsMetadataLoaded(false);

      // Stop previous stream if active
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => {
          try { t.stop(); } catch {}
        });
        streamRef.current = null;
      }

      const devId = targetDeviceId || selectedDeviceId;

      // Primary high-resolution constraints:
      // ideal width 1920, ideal height 1080, facingMode ideal
      const primaryConstraints: MediaStreamConstraints = {
        video: {
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          facingMode: facingMode === "environment" ? "environment" : "user",
          ...(devId ? { deviceId: { ideal: devId } } : {}),
        },
        audio: false,
      };

      console.log("[useCamera] Requesting getUserMedia with constraints:", primaryConstraints);

      let stream: MediaStream | null = null;

      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          throw new Error("getUserMedia is not supported by your browser or context is insecure (HTTPS required).");
        }

        try {
          stream = await navigator.mediaDevices.getUserMedia(primaryConstraints);
        } catch (initialErr) {
          const err = initialErr as Error;
          console.warn(`[useCamera] 1080p constraint failed [${err.name}]: ${err.message}. Trying 720p fallback...`);

          try {
            stream = await navigator.mediaDevices.getUserMedia({
              video: {
                facingMode: { ideal: facingMode },
                width: { ideal: 1280 },
                height: { ideal: 720 },
                ...(devId ? { deviceId: { ideal: devId } } : {}),
              },
              audio: false,
            });
          } catch (secondaryErr) {
            console.warn("[useCamera] 720p fallback failed; falling back to simple constraints { video: true }...", secondaryErr);
            stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
          }
        }

        // If unmounted or cancelled while awaiting stream
        if (currentRequestId !== requestIdRef.current || !isMountedRef.current) {
          console.info("[useCamera] Stream resolved after unmount or cancel; stopping tracks immediately.");
          stream.getTracks().forEach((t) => {
            try { t.stop(); } catch {}
          });
          isStartingRef.current = false;
          setCameraStatus("idle");
          return;
        }

        streamRef.current = stream;

        // Refresh devices list so device labels are available now that permission is granted
        refreshDevices();

        // Ensure video element is available in DOM
        let video = videoRef.current;
        if (!video) {
          console.warn("[useCamera] videoRef not immediately available, waiting for DOM ref...");
          for (let i = 0; i < 20 && !videoRef.current; i++) {
            await new Promise((r) => setTimeout(r, 50));
          }
          video = videoRef.current;
        }

        if (!video) {
          throw new Error("Video element reference is not mounted in the DOM.");
        }

        // Set video attributes before assigning srcObject
        video.muted = true;
        video.playsInline = true;
        video.srcObject = stream;

        // Await video.play()
        try {
          await video.play();
          console.log("[useCamera] video.play() succeeded.");
        } catch (playErr) {
          console.error("[useCamera] video.play() failed:", playErr);
        }

        // Wait for loadedmetadata before starting MediaPipe
        if (video.readyState < 1) {
          await new Promise<void>((resolve) => {
            const onMetadata = () => {
              video?.removeEventListener("loadedmetadata", onMetadata);
              resolve();
            };
            video?.addEventListener("loadedmetadata", onMetadata);
            // Fallback timeout in case event doesn't fire
            setTimeout(resolve, 1500);
          });
        }

        console.log(`[useCamera] loadedmetadata ready. Video size: ${video.videoWidth}x${video.videoHeight}`);
        setIsMetadataLoaded(true);

        if (currentRequestId !== requestIdRef.current || !isMountedRef.current) {
          isStartingRef.current = false;
          setCameraStatus("idle");
          return;
        }

        setIsCameraActive(true);
        setCameraStatus("active");
        isStartingRef.current = false;
        onStreamReadyRef.current(video);
      } catch (e) {
        isStartingRef.current = false;
        const err = e as Error;
        console.error(`[useCamera] Camera start failure: ${err.name} - ${err.message}`, err);

        // Stop stream if any
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((t) => {
            try { t.stop(); } catch {}
          });
          streamRef.current = null;
        }
        if (videoRef.current) {
          videoRef.current.srcObject = null;
        }

        setIsCameraActive(false);
        setIsMetadataLoaded(false);
        setCameraStatus("error");

        let userMsg = "Error accessing camera. Please try again.";

        if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
          userMsg = "Camera blocked. Click the lock icon in the address bar, allow Camera, then reload.";
        } else if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
          userMsg = "No camera found.";
        } else if (
          err.name === "NotReadableError" ||
          err.name === "TrackStartError" ||
          /in use/i.test(err.message)
        ) {
          userMsg = "Camera is in use by another app (Zoom/Teams/Meet). Close it and retry.";
        } else if (err.name === "OverconstrainedError") {
          userMsg = "Camera requested format is not supported by your hardware.";
        } else if (err.message) {
          userMsg = err.message;
        }

        setErrorMessage(userMsg);
        onPermissionErrorRef.current(userMsg);
      }
    },
    [facingMode, refreshDevices, selectedDeviceId]
  );

  const retryCamera = useCallback(() => {
    return startCamera();
  }, [startCamera]);

  const toggleFacingMode = useCallback(() => {
    setFacingMode((prev) => (prev === "user" ? "environment" : "user"));
  }, []);

  const handleDeviceChange = useCallback(
    (deviceId: string) => {
      setSelectedDeviceId(deviceId);
      if (isCameraActive) {
        startCamera(deviceId);
      }
    },
    [isCameraActive, startCamera]
  );

  // Safe cleanup on real unmount
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
      stopCamera();
    };
  }, [stopCamera]);

  return {
    videoRef,
    isCameraActive,
    cameraStatus,
    errorMessage,
    isMetadataLoaded,
    startCamera,
    stopCamera,
    retryCamera,
    devices,
    selectedDeviceId,
    setSelectedDeviceId: handleDeviceChange,
    toggleFacingMode,
    facingMode,
  };
}
