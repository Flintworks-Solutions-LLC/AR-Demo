import * as THREE from 'three';
import { JewelConfig } from './types';
import { createJewelMaterials, createBrilliantGemGeometry, createStepCutGemGeometry } from './materials';

/**
 * Builds one of 10 distinct, richly detailed 3D finger rings.
 * Scale: 1 unit = 1 cm (ring diameter ~1.8 cm, inner radius ~0.88 cm).
 * The head and gemstone point along +Y or +Z so orientation is clear.
 */
export function buildRing(config: JewelConfig): THREE.Group {
  const group = new THREE.Group();
  group.name = `ring_${config.id}`;

  const { metalMat, diamondMat, rubyMat, emeraldMat, sapphireMat, pearlMat } =
    createJewelMaterials(config.metalTone);

  const innerRadius = 0.88; // 17.6mm diameter
  const bandThickness = 0.12;
  const bandWidth = 0.18;

  // Base band geometry
  switch (config.style) {
    case 'solitaire_cathedral': {
      // Tapered shank sweeping upward into cathedral arches with 6 prongs
      const band = new THREE.Mesh(new THREE.TorusGeometry(innerRadius, bandThickness, 24, 64), metalMat);
      group.add(band);

      // Cathedral arches
      const archGeom = new THREE.CylinderGeometry(0.04, 0.08, 0.55, 12);
      const leftArch = new THREE.Mesh(archGeom, metalMat);
      leftArch.position.set(-0.25, innerRadius + 0.15, 0);
      leftArch.rotation.z = -0.35;
      group.add(leftArch);

      const rightArch = new THREE.Mesh(archGeom, metalMat);
      rightArch.position.set(0.25, innerRadius + 0.15, 0);
      rightArch.rotation.z = 0.35;
      group.add(rightArch);

      // Crown collet / basket
      const collet = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.22, 0.28, 16), metalMat);
      collet.position.set(0, innerRadius + 0.38, 0);
      group.add(collet);

      // 6 prongs
      for (let i = 0; i < 6; i++) {
        const angle = (i * Math.PI * 2) / 6;
        const prong = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.42, 8), metalMat);
        prong.position.set(Math.cos(angle) * 0.32, innerRadius + 0.48, Math.sin(angle) * 0.32);
        group.add(prong);
      }

      // Brilliant diamond
      const gem = new THREE.Mesh(createBrilliantGemGeometry(0.42), diamondMat);
      gem.position.set(0, innerRadius + 0.52, 0);
      group.add(gem);
      break;
    }

    case 'halo': {
      // Classic round band
      const band = new THREE.Mesh(new THREE.TorusGeometry(innerRadius, bandThickness, 20, 64), metalMat);
      group.add(band);

      // Center sapphire
      const centerGem = new THREE.Mesh(createBrilliantGemGeometry(0.36), sapphireMat);
      centerGem.position.set(0, innerRadius + 0.34, 0);
      group.add(centerGem);

      // Bezel plate
      const bezel = new THREE.Mesh(new THREE.CylinderGeometry(0.58, 0.45, 0.18, 24), metalMat);
      bezel.position.set(0, innerRadius + 0.24, 0);
      group.add(bezel);

      // Surrounding halo of 14 micro diamonds
      const haloCount = 14;
      const haloRadius = 0.48;
      for (let i = 0; i < haloCount; i++) {
        const a = (i * Math.PI * 2) / haloCount;
        const micro = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 8), diamondMat);
        micro.position.set(Math.cos(a) * haloRadius, innerRadius + 0.33, Math.sin(a) * haloRadius);
        group.add(micro);
      }
      break;
    }

    case 'three_stone': {
      // Trilogy setting: Emerald flanked by two diamonds
      const band = new THREE.Mesh(new THREE.TorusGeometry(innerRadius, bandThickness, 20, 64), metalMat);
      group.add(band);

      // Bridge
      const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.12, 0.36), metalMat);
      bridge.position.set(0, innerRadius + 0.16, 0);
      group.add(bridge);

      // Center emerald
      const centerGem = new THREE.Mesh(createStepCutGemGeometry(0.44, 0.32, 0.38), emeraldMat);
      centerGem.position.set(0, innerRadius + 0.32, 0);
      group.add(centerGem);

      // Side diamond left
      const leftGem = new THREE.Mesh(createBrilliantGemGeometry(0.24), diamondMat);
      leftGem.position.set(-0.35, innerRadius + 0.28, 0);
      group.add(leftGem);

      // Side diamond right
      const rightGem = new THREE.Mesh(createBrilliantGemGeometry(0.24), diamondMat);
      rightGem.position.set(0.35, innerRadius + 0.28, 0);
      group.add(rightGem);
      break;
    }

    case 'pave_band': {
      // Flat comfort band encrusted with micro pavé diamonds across upper half
      const band = new THREE.Mesh(new THREE.CylinderGeometry(innerRadius + 0.12, innerRadius + 0.12, bandWidth, 48, 1, true), metalMat);
      band.rotation.x = Math.PI / 2;
      group.add(band);

      const innerSleeve = new THREE.Mesh(new THREE.TorusGeometry(innerRadius, 0.08, 16, 64), metalMat);
      group.add(innerSleeve);

      // 18 micro diamonds along the top 180 degrees
      const count = 18;
      for (let i = 0; i < count; i++) {
        const theta = -Math.PI / 2 + (i / (count - 1)) * Math.PI;
        const x = Math.cos(theta) * (innerRadius + 0.12);
        const y = Math.sin(theta) * (innerRadius + 0.12);
        const gem = new THREE.Mesh(new THREE.SphereGeometry(0.048, 8, 8), diamondMat);
        gem.position.set(x, y, 0);
        group.add(gem);
      }
      break;
    }

    case 'signet': {
      // Bold flat top signet with bevelled shoulders
      const band = new THREE.Mesh(new THREE.TorusGeometry(innerRadius, bandThickness * 1.3, 16, 48), metalMat);
      group.add(band);

      // Signet head
      const head = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.35, 0.35, 8), metalMat);
      head.position.set(0, innerRadius + 0.24, 0);
      head.rotation.y = Math.PI / 8;
      group.add(head);

      // Star-set ruby in the center of the crest
      const crestRuby = new THREE.Mesh(createBrilliantGemGeometry(0.22), rubyMat);
      crestRuby.position.set(0, innerRadius + 0.42, 0);
      group.add(crestRuby);
      break;
    }

    case 'cluster': {
      // Victorian floral cluster: central oval ruby surrounded by 8 diamond petals
      const band = new THREE.Mesh(new THREE.TorusGeometry(innerRadius, bandThickness, 20, 64), metalMat);
      group.add(band);

      const centerGem = new THREE.Mesh(createBrilliantGemGeometry(0.32), rubyMat);
      centerGem.position.set(0, innerRadius + 0.34, 0);
      group.add(centerGem);

      const petalCount = 8;
      const petalRadius = 0.38;
      for (let i = 0; i < petalCount; i++) {
        const a = (i * Math.PI * 2) / petalCount;
        const petal = new THREE.Mesh(createBrilliantGemGeometry(0.18), diamondMat);
        petal.position.set(Math.cos(a) * petalRadius, innerRadius + 0.30, Math.sin(a) * petalRadius);
        group.add(petal);

        // Under-prong
        const prong = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.22, 6), metalMat);
        prong.position.set(Math.cos(a) * petalRadius, innerRadius + 0.19, Math.sin(a) * petalRadius);
        group.add(prong);
      }
      break;
    }

    case 'eternity': {
      // Full eternity channel with square-cut emeralds repeating around 360 degrees
      const band = new THREE.Mesh(new THREE.TorusGeometry(innerRadius, 0.16, 20, 64), metalMat);
      group.add(band);

      const gemCount = 20;
      for (let i = 0; i < gemCount; i++) {
        const a = (i * Math.PI * 2) / gemCount;
        const x = Math.cos(a) * (innerRadius + 0.14);
        const y = Math.sin(a) * (innerRadius + 0.14);
        const gem = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.18, 0.14), emeraldMat);
        gem.position.set(x, y, 0);
        gem.rotation.z = a;
        group.add(gem);
      }
      break;
    }

    case 'twisted_rope': {
      // Dual-strand twisted cable shank crowned with a bezel-set pearl
      const curveCount = 64;
      const r = innerRadius;
      const tubeR = 0.07;
      const rope1 = new THREE.Mesh(new THREE.TorusGeometry(r, tubeR, 12, curveCount), metalMat);
      group.add(rope1);

      const rope2 = new THREE.Mesh(new THREE.TorusGeometry(r, tubeR, 12, curveCount), metalMat);
      rope2.position.z = 0.1;
      group.add(rope2);

      // Pearl bezel cup
      const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.40, 0.25, 0.22, 20), metalMat);
      cup.position.set(0, innerRadius + 0.22, 0.05);
      group.add(cup);

      // Glowing South-sea pearl
      const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.36, 24, 24), pearlMat);
      pearl.position.set(0, innerRadius + 0.38, 0.05);
      group.add(pearl);
      break;
    }

    case 'cocktail': {
      // Art Deco stepped architectural cocktail ring with blue sapphire and stepped tiers
      const band = new THREE.Mesh(new THREE.TorusGeometry(innerRadius, bandThickness, 20, 64), metalMat);
      group.add(band);

      // Stepped tier 1
      const tier1 = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.12, 0.7), metalMat);
      tier1.position.set(0, innerRadius + 0.18, 0);
      group.add(tier1);

      // Stepped tier 2
      const tier2 = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.12, 0.52), metalMat);
      tier2.position.set(0, innerRadius + 0.28, 0);
      group.add(tier2);

      // Central radiant sapphire
      const gem = new THREE.Mesh(createStepCutGemGeometry(0.48, 0.30, 0.42), sapphireMat);
      gem.position.set(0, innerRadius + 0.40, 0);
      group.add(gem);

      // Flanking baguette diamonds
      const bag1 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 0.36), diamondMat);
      bag1.position.set(-0.35, innerRadius + 0.34, 0);
      group.add(bag1);

      const bag2 = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 0.36), diamondMat);
      bag2.position.set(0.35, innerRadius + 0.34, 0);
      group.add(bag2);
      break;
    }

    case 'vintage_heritage':
    default: {
      // Indian royal Navratna ring: 9 sacred gemstones set in lotus mandala bezel
      const band = new THREE.Mesh(new THREE.TorusGeometry(innerRadius, bandThickness * 1.2, 20, 64), metalMat);
      group.add(band);

      // Lotus petal plate
      const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.58, 0.18, 32), metalMat);
      plate.position.set(0, innerRadius + 0.22, 0);
      group.add(plate);

      // Center ruby
      const rubyCenter = new THREE.Mesh(createBrilliantGemGeometry(0.24), rubyMat);
      rubyCenter.position.set(0, innerRadius + 0.34, 0);
      group.add(rubyCenter);

      // 8 surrounding Navratna gems
      const navratnaMats = [diamondMat, pearlMat, emeraldMat, sapphireMat, diamondMat, rubyMat, sapphireMat, emeraldMat];
      const radius = 0.46;
      for (let i = 0; i < 8; i++) {
        const a = (i * Math.PI * 2) / 8;
        const gem = new THREE.Mesh(createBrilliantGemGeometry(0.14), navratnaMats[i]);
        gem.position.set(Math.cos(a) * radius, innerRadius + 0.32, Math.sin(a) * radius);
        group.add(gem);
      }
      break;
    }
  }

  return group;
}
