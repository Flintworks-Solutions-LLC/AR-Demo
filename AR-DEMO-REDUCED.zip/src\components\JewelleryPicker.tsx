﻿import React from "react";
import { LandmarkerCategory } from "@/hooks/useLandmarkers";
import { JewelleryItem, JewelleryCategoryData } from "@/config/jewellery.config";

export type MetalType = "gold" | "silver" | "rose_gold";

// Re-export so page.tsx can import from one place
export type { JewelleryItem, JewelleryCategoryData };

interface JewelleryPickerProps {
  categories: JewelleryCategoryData[];
  selectedCategory: LandmarkerCategory;
  onSelectCategory: (cat: LandmarkerCategory) => void;
  selectedItemIds: Record<string, string>;
  onSelectItem: (cat: string, itemId: string) => void;
  metal: MetalType;
  onMetalChange: (metal: MetalType) => void;
  noseRingToggle?: "left" | "right" | "both";
  onNoseRingToggle?: (t: "left" | "right" | "both") => void;
}

export function JewelleryPicker({
  categories,
  selectedCategory,
  onSelectCategory,
  selectedItemIds,
  onSelectItem,
  metal,
  onMetalChange,
  noseRingToggle,
  onNoseRingToggle,
}: JewelleryPickerProps) {
  const currentCat = categories.find((c) => c.id === selectedCategory);

  return (
    <div className="w-full bg-slate-900/80 p-4 rounded-2xl border border-slate-800 shadow-2xl backdrop-blur-md">
      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-3 border-b border-slate-700/50">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => onSelectCategory(cat.id)}
            className={`whitespace-nowrap px-4 py-2 rounded-full font-medium transition-colors ${
              selectedCategory === cat.id
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20"
                : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Settings row */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
        {/* Metal toggle */}
        <div className="flex bg-slate-800 p-1 rounded-xl">
          {(["gold", "silver", "rose_gold"] as MetalType[]).map((m) => (
            <button
              key={m}
              onClick={() => onMetalChange(m)}
              style={metal === m ? {
                backgroundColor: m === "gold" ? "#D4AF37" : m === "silver" ? "#E2E8F0" : "#B76E79",
                color: m === "silver" ? "#0f172a" : "#fff",
              } : undefined}
              className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition ${
                metal !== m ? "text-slate-400 hover:text-slate-200" : ""
              }`}
            >
              {m === "rose_gold" ? "Rose Gold" : m.charAt(0).toUpperCase() + m.slice(1)}
            </button>
          ))}
        </div>

        {/* Nose ring side toggle */}
        {selectedCategory === "nose_ring" && onNoseRingToggle && (
          <div className="flex bg-slate-800 p-1 rounded-xl">
            {(["left", "both", "right"] as const).map((s) => (
              <button
                key={s}
                onClick={() => onNoseRingToggle(s)}
                className={`px-3 py-1.5 rounded-lg text-sm transition capitalize ${
                  noseRingToggle === s ? "bg-slate-600 text-white" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Item thumbnails */}
      {currentCat && (
        <div className="flex gap-4 overflow-x-auto pb-4">
          {currentCat.items.map((item) => {
            const isSelected = selectedItemIds[selectedCategory!] === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectItem(selectedCategory!, item.id)}
                className="flex-shrink-0 w-24 flex flex-col items-center gap-2 group"
              >
                <div
                  className={`w-20 h-20 rounded-2xl flex items-center justify-center p-2 transition-all ${
                    isSelected
                      ? "bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border-2 border-indigo-400 shadow-xl"
                      : "bg-slate-800 border border-slate-700 hover:border-slate-500"
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={item.src || "/jewellery/placeholder.png"}
                    alt={item.name}
                    className="w-full h-full object-contain filter drop-shadow-md"
                    onError={(e) => {
                      // Show a fallback gem icon if PNG missing
                      (e.target as HTMLImageElement).style.opacity = "0.3";
                    }}
                  />
                </div>
                <span
                  className={`text-xs text-center font-medium line-clamp-2 ${
                    isSelected ? "text-indigo-300" : "text-slate-400 group-hover:text-slate-200"
                  }`}
                >
                  {item.name}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
