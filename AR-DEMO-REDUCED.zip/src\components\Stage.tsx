"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { useCamera } from "@/hooks/useCamera";
import { useLandmarkers, LandmarkerCategory } from "@/hooks/useLandmarkers";
import {
  calcEarringTransform,
  calcNoseRingTransform,
  calcNecklaceTargetPoints,
  TransformFilter,
  OneEuroFilter,
  LandmarkFilterArray,
  Landmark,
  NecklaceTargetPoints,
  NecklaceTuning,
  DEFAULT_NECKLACE_TUNING,
  computeCanvasTransform,
  toCanvas,
  CanvasTransform,
} from "@/lib/jewelleryMath";
import { computeAlphaPrincipalAxis } from "@/lib/imageEnhancement";
import { JewelleryItem } from "@/config/jewellery.config";
import { ThreeJewelleryManager, MetalType } from "@/lib/threeJewellery";

// ─── Types ───────────────────────────────────────────────────────────────────
type Transform = {
  x: number;
  y: number;
  scale: number;
  rotation: number;
  opacity: number;
};

// ─── StageProps ───────────────────────────────────────────────────────────────
interface StageProps {
  category: LandmarkerCategory;
  items: Record<string, JewelleryItem | undefined>;
  noseRingToggle: "left" | "right" | "both";
  metal?: MetalType;
  showDebug: boolean;
  useOcclusion: boolean;
  onToggleDebug: () => void;
  onToggleOcclusion: () => void;
  onSnapshotReady?: (dataUrl: string) => void;
  /** If true, camera starts automatically when the component mounts. */
  startOnMount?: boolean;
  /** Called when the camera stops (e.g., user navigates back) */
  onCameraStop?: () => void;
  onOpen360?: () => void;
  children?: React.ReactNode;
}

// ─── Realism helpers ─────────────────────────────────────────────────────────
function sampleRegionLuminance(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number
): number {
  try {
    const x = Math.max(0, Math.round(cx - r));
    const y = Math.max(0, Math.round(cy - r));
    const w = Math.min(ctx.canvas.width - x, Math.round(r * 2));
    const h = Math.min(ctx.canvas.height - y, Math.round(r * 2));
    if (w <= 0 || h <= 0) return 1;
    const data = ctx.getImageData(x, y, w, h).data;
    let sum = 0;
    for (let i = 0; i < data.length; i += 16) {
      sum += (0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]) / 255;
    }
    return sum / (data.length / 16);
  } catch {
    return 1;
  }
}

function getSelectedProduct(
  category: LandmarkerCategory,
  items: Record<string, JewelleryItem | undefined>
): JewelleryItem | undefined {
  switch (category) {
    case "necklace":
    case "necklaces":
      return items.necklace || items.necklaces;
    case "finger_ring":
    case "rings":
      return items.finger_ring || items.rings;
    case "bangles":
      return items.bangles;
    case "nose_ring":
    case "noserings":
      return items.nose_ring || items.noserings;
    case "sets":
      return items.necklace || items.necklaces;
    case "earrings":
      return items.earrings;
    default:
      return undefined;
  }
}

interface NecklaceAssetLayers {
  chain: HTMLCanvasElement;
  pendant: HTMLCanvasElement;
  uprightAngle: number;
}

function createNecklaceAssetLayers(
  img: HTMLImageElement,
  item: JewelleryItem
): NecklaceAssetLayers | null {
  const anchors = item.necklaceAnchors || {
    leftEnd: { x: 0.14, y: 0.04 },
    rightEnd: { x: 0.86, y: 0.04 },
    pendantCenter: { x: 0.5, y: 0.82 },
    bottomCenter: { x: 0.5, y: 0.94 },
  };
  const width = img.naturalWidth;
  const height = img.naturalHeight;
  const pendantW = width * 0.36;
  const pendantH = height * 0.34;
  const centerX = anchors.pendantCenter.x * width;
  const centerY = anchors.pendantCenter.y * height;
  const sourceX = Math.max(0, Math.min(width - pendantW, centerX - pendantW / 2));
  const sourceY = Math.max(0, Math.min(height - pendantH, centerY - pendantH / 2));
  const chain = document.createElement("canvas");
  chain.width = width;
  chain.height = height;
  const chainContext = chain.getContext("2d");
  const pendant = document.createElement("canvas");
  pendant.width = Math.round(pendantW);
  pendant.height = Math.round(pendantH);
  const pendantContext = pendant.getContext("2d");
  if (!chainContext || !pendantContext) return null;

  chainContext.drawImage(img, 0, 0);
  pendantContext.drawImage(
    img,
    sourceX,
    sourceY,
    pendantW,
    pendantH,
    0,
    0,
    pendant.width,
    pendant.height
  );

  let uprightAngle = item.uprightAngle ?? 0;
  if (item.uprightAngle === undefined) {
    try {
      uprightAngle = computeAlphaPrincipalAxis(pendant);
    } catch (error) {
      console.warn(`[AR] Could not deskew pendant asset ${item.id}:`, error);
    }
  }
  const uprightW = Math.ceil(Math.abs(pendant.width * Math.cos(uprightAngle)) + Math.abs(pendant.height * Math.sin(uprightAngle)));
  const uprightH = Math.ceil(Math.abs(pendant.width * Math.sin(uprightAngle)) + Math.abs(pendant.height * Math.cos(uprightAngle)));
  const uprightPendant = document.createElement("canvas");
  uprightPendant.width = Math.max(1, uprightW);
  uprightPendant.height = Math.max(1, uprightH);
  const uprightContext = uprightPendant.getContext("2d");
  if (!uprightContext) return null;
  uprightContext.translate(uprightPendant.width / 2, uprightPendant.height / 2);
  uprightContext.rotate(uprightAngle);
  uprightContext.drawImage(pendant, -pendant.width / 2, -pendant.height / 2);
  return { chain, pendant: uprightPendant, uprightAngle };
}

function drawPNG(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  t: Transform,
  anchor: { x: number; y: number },
  fitScale: number,
  luminance: number,
  mirrorX = false
) {
  if (!img.complete || img.naturalWidth === 0) return;

  const w = t.scale * fitScale;
  const h = w * (img.naturalHeight / img.naturalWidth);
  const normAnchorX = anchor.x <= 1 ? anchor.x : anchor.x / 100;
  const normAnchorY = anchor.y <= 1 ? anchor.y : anchor.y / 100;
  const ax = normAnchorX * w;
  const ay = normAnchorY * h;

  ctx.save();
  ctx.translate(t.x, t.y);
  ctx.rotate(t.rotation);
  if (mirrorX) {
    ctx.scale(-1, 1);
  }
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.globalAlpha = Math.max(0.35, Math.min(1, t.opacity));
  const brightness = Math.min(1.25, Math.max(0.80, luminance * 1.2 + 0.40));
  ctx.filter = `brightness(${brightness.toFixed(2)})`;
  ctx.drawImage(img, -ax, -ay, w, h);
  ctx.filter = "none";
  ctx.restore();
}

// ─── Affine helper ────────────────────────────────────────────────────────────
// ─── Jaw/chin/neck polygon for realistic occlusion ────────────────────────────
const JAW_POLYGON_INDICES = [
  10, 338, 297, 332, 284, 251, 389, 356, 454,
  323, 361, 288, 397, 365, 379, 378, 400, 377, 152,
  148, 176, 149, 150, 136, 172, 58, 132, 93, 234,
  127, 162, 21, 54, 103, 67, 109, 10,
];

function drawNeckAndJawOcclusion(
  ctx: CanvasRenderingContext2D,
  video: HTMLVideoElement,
  face: Landmark[],
  leftNeck: { x: number; y: number },
  rightNeck: { x: number; y: number },
  cw: number,
  ch: number,
  transform: CanvasTransform
) {
  ctx.save();
  ctx.beginPath();

  for (let i = 0; i < JAW_POLYGON_INDICES.length; i++) {
    const lm = face[JAW_POLYGON_INDICES[i]];
    if (!lm) continue;
    if (i === 0) ctx.moveTo(lm.x, lm.y);
    else ctx.lineTo(lm.x, lm.y);
  }

  const chin = face[152];
  if (chin) {
    ctx.lineTo(leftNeck.x, leftNeck.y);
    ctx.lineTo(chin.x, Math.max(chin.y, (leftNeck.y + rightNeck.y) / 2));
    ctx.lineTo(rightNeck.x, rightNeck.y);
  }

  ctx.closePath();
  ctx.clip();

  // Draw video into the clip region matching exact video display
  if (transform.isMirrored) {
    ctx.save();
    ctx.translate(cw, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(
      video,
      0, 0, video.videoWidth, video.videoHeight,
      transform.offsetX, transform.offsetY, transform.renderedW, transform.renderedH
    );
    ctx.restore();
  } else {
    ctx.drawImage(
      video,
      0, 0, video.videoWidth, video.videoHeight,
      transform.offsetX, transform.offsetY, transform.renderedW, transform.renderedH
    );
  }
  ctx.restore();
}

// ─── Debug overlay ────────────────────────────────────────────────────────────
function drawDebug(
  ctx: CanvasRenderingContext2D,
  face: Landmark[] | null,
  pose: Landmark[] | null,
  hands: Landmark[][] | null,
  cw: number,
  ch: number,
  neckTargets?: NecklaceTargetPoints | null,
  neckAnchorsScreen?: {
    leftEnd: { x: number; y: number };
    rightEnd: { x: number; y: number };
    pendantCenter: { x: number; y: number };
  } | null,
  bangleDebug?: { center: { x: number; y: number; z: number }; forearmDir: { x: number; y: number; z: number } } | null,
  ringDebug?: { position: { x: number; y: number; z: number }; fingerAxis: { x: number; y: number; z: number }; isBackOfHand: boolean; handedness: string } | null,
) {
  const dot = (x: number, y: number, color: string, label?: string) => {
    ctx.beginPath();
    ctx.arc(x, y, 4, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();
    if (label) {
      ctx.fillStyle = "white";
      ctx.font = "9px monospace";
      ctx.fillText(label, x + 6, y + 3);
    }
  };
  const ldot = (lm: Landmark, color: string, label?: string) => {
    if (!lm) return;
    const px = Math.abs(lm.x) > 1.5 ? lm.x : lm.x * cw;
    const py = Math.abs(lm.y) > 1.5 ? lm.y : lm.y * ch;
    dot(px, py, color, label);
  };

  if (face) {
    ldot(face[234], "purple", "234(ear-R)");
    ldot(face[454], "purple", "454(ear-L)");
    ldot(face[129], "yellow", "129(nostril-L)");
    ldot(face[358], "yellow", "358(nostril-R)");
    ldot(face[152], "lime",   "152(chin)");
    ldot(face[10],  "lime",   "10(forehead)");
  }
  if (pose) {
    ldot(pose[11], "red",  "11(shldr-L)");
    ldot(pose[12], "blue", "12(shldr-R)");
  }

  // Hands landmarks (0..20)
  if (hands) {
    hands.forEach((hand) => {
      hand.forEach((lm, idx) => {
        const isKey = idx === 0 || idx === 5 || idx === 9 || idx === 13 || idx === 14 || idx === 17;
        ldot(lm, isKey ? "#00ffff" : "rgba(255,255,255,0.4)", isKey ? `${idx}` : undefined);
      });
    });
  }

  // Necklace debug
  if (neckTargets) {
    const sq = (pt: { x: number; y: number }, color: string, label: string) => {
      ctx.fillStyle = color;
      ctx.fillRect(pt.x - 6, pt.y - 6, 12, 12);
      ctx.fillStyle = "white";
      ctx.font = "11px monospace";
      ctx.fillText(label, pt.x + 10, pt.y + 4);
    };

    sq(neckTargets.leftNeck,  "#ff4444", "leftNeck");
    sq(neckTargets.rightNeck, "#4444ff", "rightNeck");
    sq(neckTargets.pendant,   "#44ff44", "pendant");
    sq(neckTargets.chainSag,  "#ffaa00", "chainSag");

    ctx.save();
    ctx.strokeStyle = "#00ffff";
    ctx.lineWidth = 3;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    ctx.moveTo(neckTargets.leftNeck.x, neckTargets.leftNeck.y);
    ctx.quadraticCurveTo(
      neckTargets.chainSag.x - (neckTargets.rightNeck.x - neckTargets.leftNeck.x) * 0.15,
      neckTargets.chainSag.y,
      neckTargets.pendant.x,
      neckTargets.pendant.y
    );
    ctx.quadraticCurveTo(
      neckTargets.chainSag.x + (neckTargets.rightNeck.x - neckTargets.leftNeck.x) * 0.15,
      neckTargets.chainSag.y,
      neckTargets.rightNeck.x,
      neckTargets.rightNeck.y
    );
    ctx.stroke();
    ctx.restore();
  }

  if (neckAnchorsScreen) {
    const diamond = (pt: { x: number; y: number }, color: string, label: string) => {
      ctx.save();
      ctx.translate(pt.x, pt.y);
      ctx.rotate(Math.PI / 4);
      ctx.fillStyle = color;
      ctx.fillRect(-5, -5, 10, 10);
      ctx.restore();
      ctx.fillStyle = "white";
      ctx.font = "10px monospace";
      ctx.fillText(label, pt.x + 10, pt.y - 6);
    };
    diamond(neckAnchorsScreen.leftEnd,       "#ff8888", "anchor:leftEnd");
    diamond(neckAnchorsScreen.rightEnd,      "#8888ff", "anchor:rightEnd");
    diamond(neckAnchorsScreen.pendantCenter, "#88ff88", "anchor:pendant");
  }

  // 3D Bangle Debug
  if (bangleDebug) {
    const c2d = { x: bangleDebug.center.x, y: ch - bangleDebug.center.y };
    dot(c2d.x, c2d.y, "#ffd700", "Bangle Center C");
    // Draw forearm direction ray
    ctx.save();
    ctx.strokeStyle = "#ffd700";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(c2d.x, c2d.y);
    ctx.lineTo(c2d.x + bangleDebug.forearmDir.x * 60, c2d.y - bangleDebug.forearmDir.y * 60);
    ctx.stroke();
    ctx.restore();
  }

  // 3D Ring Debug
  if (ringDebug) {
    const r2d = { x: ringDebug.position.x, y: ch - ringDebug.position.y };
    dot(r2d.x, r2d.y, "#00ffcc", "Ring Pos");

    // Status badge: BACK vs PALM
    ctx.save();
    ctx.fillStyle = ringDebug.isBackOfHand ? "rgba(34, 197, 94, 0.85)" : "rgba(234, 179, 8, 0.85)";
    ctx.beginPath();
    ctx.roundRect(r2d.x + 15, r2d.y - 20, 95, 24, 6);
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 11px sans-serif";
    ctx.fillText(ringDebug.isBackOfHand ? "ORIENT: BACK" : "ORIENT: PALM", r2d.x + 22, r2d.y - 4);
    ctx.restore();
  }
}

// Categories that use 3D Three.js rendering (not 2D PNG — skip transparency checks for these)
const USES_3D_RENDERING = new Set(["bangles", "finger_ring"]);

// ─── Stage ───────────────────────────────────────────────────────────────────
export function Stage({
  category,
  items,
  noseRingToggle,
  metal = "gold",
  showDebug,
  useOcclusion,
  onToggleDebug,
  onToggleOcclusion,
  onSnapshotReady,
  startOnMount = false,
  onCameraStop,
  children,
}: StageProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const threeCanvasRef = useRef<HTMLCanvasElement>(null);
  const threeManagerRef = useRef<ThreeJewelleryManager | null>(null);
  const stageContainerRef = useRef<HTMLDivElement>(null);
  const canvasTransformRef = useRef<CanvasTransform | null>(null);
  const [assetToast, setAssetToast] = useState<string | null>(null);
  const [loadedAssetInfo, setLoadedAssetInfo] = useState<{ productId: string; url: string } | null>(null);
  const selectedProduct = getSelectedProduct(category, items);
  const selectedProductId = selectedProduct?.id;
  const selectedProductSrc = selectedProduct?.src;
  const selectedProductModelUrl = selectedProduct?.modelUrl;
  const selectedProductRef = useRef(selectedProduct);
  selectedProductRef.current = selectedProduct;
  const loggedAssetLoadsRef = useRef(new Set<string>());

  const [permissionError, setPermissionError] = useState<string | null>(null);
  const [hint, setHint] = useState<string>("");
  const [fit, setFit] = useState({ scale: 1, offsetX: 0, offsetY: 0 });
  const [showFitPanel, setShowFitPanel] = useState(false);

  // Bangle Stack selector: 1 / 2 / 4 / 6 (Default 2)
  const [bangleStackCount, setBangleStackCount] = useState<1 | 2 | 4 | 6>(2);
  const [wristShift, setWristShift] = useState<number>(0.25);
  const [fingerWidthRatio, setFingerWidthRatio] = useState<number>(0.42);

  // Live tuning for necklace ratios
  const [neckTuning, setNeckTuning] = useState<NecklaceTuning>(DEFAULT_NECKLACE_TUNING);

  // Tracking stability & framing guide
  const trackingStableFrames = useRef(0);
  const [isTrackingStable, setIsTrackingStable] = useState(false);
  const [isBackOfHand, setIsBackOfHand] = useState(true);

  // Shoulder-lost timer: show "step back" hint only after 1.5s of continuously lost shoulders
  const shoulderLostStartRef = useRef<number | null>(null);
  const [showChestHint, setShowChestHint] = useState(false);

  // Check if debug mode is enabled via URL param
  const isDebugUrl = typeof window !== "undefined" && window.location.search.includes("debug=1");

  // Synchronize 3D models when items change
  const ringItem = items["finger_ring"] || items["rings"];
  const bangleItem = items["bangles"];
  const ringItemRef = useRef(ringItem);
  const bangleItemRef = useRef(bangleItem);
  const metalRef = useRef(metal);
  ringItemRef.current = ringItem;
  bangleItemRef.current = bangleItem;
  metalRef.current = metal;

  useEffect(() => {
    const ring = ringItem;
    if (threeManagerRef.current && ring) {
      threeManagerRef.current.setRingItem(ring);
    }
  }, [ringItem]);

  useEffect(() => {
    if (threeManagerRef.current && bangleItem) {
      threeManagerRef.current.setBangleItem(bangleItem);
    }
  }, [bangleItem]);

  const handleStreamReady = useCallback(() => setPermissionError(null), []);
  const handlePermissionError = useCallback((e: string) => setPermissionError(e), []);

  const {
    videoRef,
    isCameraActive,
    cameraStatus,
    errorMessage: cameraErrorMsg,
    startCamera,
    stopCamera,
    retryCamera,
    devices,
    selectedDeviceId,
    setSelectedDeviceId,
    toggleFacingMode,
    facingMode,
  } = useCamera({
    onStreamReady: handleStreamReady,
    onPermissionError: handlePermissionError,
  });
 
  useEffect(() => {
    if (startOnMount) {
      startCamera();
    }
  }, [startOnMount, startCamera]);

  const isJewellerySelected = Boolean(category && items && items[category]);

  const handleTryAgain = useCallback(() => {
    setPermissionError(null);
    retryCamera();
  }, [retryCamera]);

  const {
    isReady,
    isFaceLoaded,
    isHandLoaded,
    isPoseLoaded,
    error: landmarkError,
    retryInit,
    detect,
  } = useLandmarkers();

  const frameHandleRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(-1);

  // Landmark adaptive smoothing filter sets (Face, Pose, Hands)
  const faceLandmarkFilter = useRef(new LandmarkFilterArray(478, 0.8, 0.015));
  const poseLandmarkFilter = useRef(new LandmarkFilterArray(33, 0.8, 0.015));
  const handLandmarkFilters = useRef([
    new LandmarkFilterArray(21, 0.8, 0.015),
    new LandmarkFilterArray(21, 0.8, 0.015),
  ]);

  // Jewel transform filters (smoothed in canvas pixel space)
  const filters = useRef({
    earL: new TransformFilter(0.8, 0.015),
    earR: new TransformFilter(0.8, 0.015),
    noseL: new TransformFilter(0.8, 0.015),
    noseR: new TransformFilter(0.8, 0.015),
    neckLx: new OneEuroFilter(0.8, 0.015),
    neckLy: new OneEuroFilter(0.8, 0.015),
    neckRx: new OneEuroFilter(0.8, 0.015),
    neckRy: new OneEuroFilter(0.8, 0.015),
    pendX:  new OneEuroFilter(0.8, 0.015),
    pendY:  new OneEuroFilter(0.8, 0.015),
    sagX:   new OneEuroFilter(0.8, 0.015),
    sagY:   new OneEuroFilter(0.8, 0.015),
  });

  // Hand 3D landmark smoothing: 21 landmarks x 3 coords (X, Y, Z) per hand
  // Image cache — keyed by src
  const imgCache = useRef<Record<string, HTMLImageElement>>({});
  const necklaceLayersCache = useRef<Record<string, NecklaceAssetLayers>>({});
  const lastActiveFaceRef = useRef<{ landmarks: Landmark[]; time: number } | null>(null);
  const lastActivePoseRef = useRef<{ landmarks: Landmark[]; time: number } | null>(null);
  const lastActiveHandsRef = useRef<{ landmarks: Landmark[][]; time: number } | null>(null);

  const reportAssetLoaded = useCallback((productId: string, url: string) => {
    if (selectedProductRef.current?.id !== productId || !url) return;
    setLoadedAssetInfo({ productId, url });
    const key = `${productId}:${url}`;
    if (!loggedAssetLoadsRef.current.has(key)) {
      loggedAssetLoadsRef.current.add(key);
      console.info(`[AR Debug] selectedProduct.id=${productId} loadedAssetUrl=${url}`);
    }
  }, []);

  const reportAssetError = useCallback((productId: string) => {
    if (selectedProductRef.current?.id === productId) {
      setLoadedAssetInfo(null);
      setAssetToast("asset unavailable");
    }
  }, []);

  useEffect(() => {
    setAssetToast(null);
    setLoadedAssetInfo(null);
    if (selectedProductId && !selectedProductSrc && !selectedProductModelUrl) {
      setAssetToast("asset unavailable");
    }
  }, [selectedProductId, selectedProductSrc, selectedProductModelUrl]);

  useEffect(() => {
    if (!assetToast) return;
    const timer = window.setTimeout(() => setAssetToast(null), 2400);
    return () => window.clearTimeout(timer);
  }, [assetToast]);

  // Initialize ThreeJewelleryManager
  useEffect(() => {
    if (threeCanvasRef.current && !threeManagerRef.current) {
      const mgr = new ThreeJewelleryManager(
        threeCanvasRef.current,
        reportAssetLoaded,
        reportAssetError
      );
      threeManagerRef.current = mgr;
      mgr.setMetal(metalRef.current);
      if (bangleItemRef.current) mgr.setBangleItem(bangleItemRef.current);
      if (ringItemRef.current) mgr.setRingItem(ringItemRef.current);
    }
    return () => {
      if (threeManagerRef.current) {
        threeManagerRef.current.dispose();
        threeManagerRef.current = null;
      }
    };
  }, [reportAssetError, reportAssetLoaded]);

  // Sync metal to 3D manager
  useEffect(() => {
    if (threeManagerRef.current) {
      threeManagerRef.current.setMetal(metal);
    }
  }, [metal]);

  // Preload images whenever items change; verify real RGBA

  useEffect(() => {
    Object.values(items).forEach((item) => {
      if (!item?.src) {
        if (item && selectedProduct?.id === item.id && !item.modelUrl) {
          reportAssetError(item.id);
        }
        return;
      }
      if (imgCache.current[item.src]) {
        if (!item.modelUrl && item.id === selectedProduct?.id) {
          reportAssetLoaded(item.id, item.src);
        }
        return;
      }
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        imgCache.current[item.src] = img;
        if (!item.modelUrl && item.id === selectedProduct?.id) {
          reportAssetLoaded(item.id, item.src);
        }
        if (
          item.uprightAngle !== undefined ||
          /pendant|cross/i.test(`${item.id} ${item.name} ${item.type}`)
        ) {
          const layers = createNecklaceAssetLayers(img, item);
          if (layers) {
            necklaceLayersCache.current[`${item.id}:${item.src}`] = layers;
          }
        }
        // Skip transparency check for 3D-rendered categories (bangles, finger_ring)
        if (category && USES_3D_RENDERING.has(category)) return;
        try {
          const tc = document.createElement("canvas");
          tc.width = img.naturalWidth;
          tc.height = img.naturalHeight;
          const tctx = tc.getContext("2d");
          if (tctx) {
            tctx.drawImage(img, 0, 0);
            const px = tctx.getImageData(0, 0, 1, 1).data;
            if (px[3] > 0) {
              const msg = `"${item.name}" (${item.src}) has no real transparency — corner alpha=${px[3]}`;
              console.warn(`[AR] ${msg}`);
            }
          }
        } catch (e) {
          console.warn("[AR] Could not check transparency:", e);
        }
      };
      img.onerror = () => {
        console.error(`[AR] Failed to load jewellery image: ${item.src}`);
        if (item.id === selectedProduct?.id && !item.modelUrl) {
          reportAssetError(item.id);
        }
      };
      img.src = item.src;
    });
  }, [items, category, selectedProduct, reportAssetError, reportAssetLoaded]);

  // Update hint per category / condition
  // "Step back so your chest is visible" only shows after 1.5s of continuously lost shoulders
  useEffect(() => {
    const cat = category as string;
    const isNeck = cat === "necklace" || cat === "necklaces" || cat === "sets";
    const isEar  = cat === "earrings";
    const isNose = cat === "nose_ring" || cat === "noserings";
    const isBang = cat === "bangles";
    const isRing = cat === "finger_ring" || cat === "rings";

    if (showChestHint && isNeck) {
      setHint("Step back so your chest is visible");
    } else if (isEar || isNose) {
      setHint("Show your face to the camera");
    } else if (isNeck) {
      if (!isTrackingStable) {
        setHint("Keep your head in the top third, shoulders and chest in frame");
      } else {
        setHint("");
      }
    } else if (isBang) {
      setHint("Show the back of your hand");
    } else if (isRing) {
      if (!isBackOfHand) {
        setHint("Show the back of your hand");
      } else {
        setHint("");
      }
    } else {
      setHint("");
    }
  }, [category, showChestHint, isTrackingStable, isBackOfHand]);

  // ── Render loop (uses requestVideoFrameCallback for hardware sync) ───────────
  const renderLoop = useCallback(() => {
    if (!isCameraActive || !videoRef.current || !canvasRef.current) {
      if (isCameraActive) {
        frameHandleRef.current = requestAnimationFrame(renderLoop);
      }
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const stageEl = stageContainerRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Size canvas to stage container dimensions × devicePixelRatio for sharp rendering
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const stageW = stageEl ? stageEl.clientWidth : canvas.clientWidth;
    const stageH = stageEl ? stageEl.clientHeight : canvas.clientHeight;
    const targetW = Math.round(stageW * dpr);
    const targetH = Math.round(stageH * dpr);

    if (video.videoWidth && video.videoHeight) {
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width  = targetW;
        canvas.height = targetH;
        if (threeManagerRef.current) {
          threeManagerRef.current.resize(targetW, targetH);
        }
      }
    }

    // Compute canvas transform matching video's object-fit: cover and mirror/flip
    const transform = computeCanvasTransform(
      targetW,
      targetH,
      video.videoWidth,
      video.videoHeight,
      facingMode === "user",
      dpr
    );
    canvasTransformRef.current = transform;

    // Always ensure imageSmoothingQuality on 2D context
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";

    const scheduleNext = () => {
      if (!isCameraActive) return;
      if ("requestVideoFrameCallback" in video) {
        frameHandleRef.current = (video as unknown as { requestVideoFrameCallback: (cb: () => void) => number }).requestVideoFrameCallback(renderLoop);
      } else {
        frameHandleRef.current = requestAnimationFrame(renderLoop);
      }
    };

    if (video.currentTime !== lastTimeRef.current && video.readyState >= 2) {
      lastTimeRef.current = video.currentTime;
      const now = performance.now();

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (!isReady && !(isFaceLoaded || isHandLoaded || isPoseLoaded)) {
        scheduleNext();
        return;
      }

      const { faceResult, handResult, poseResult } = detect(video, now, category);

      // 1. Map raw MediaPipe [0..1] landmarks to canvas pixel space using unified toCanvas
      const rawFace = faceResult?.faceLandmarks?.[0] ?? null;
      const rawPose = poseResult?.landmarks?.[0]     ?? null;
      const rawHands = handResult?.landmarks          ?? null;

      const mappedFace = rawFace ? rawFace.map((lm) => toCanvas(lm, transform)) : null;
      const mappedPose = rawPose ? rawPose.map((lm) => toCanvas(lm, transform)) : null;
      const mappedHands = rawHands ? rawHands.map((h) => h.map((lm) => toCanvas(lm, transform))) : null;

      // 2. Smooth landmarks with One Euro Filter in canvas pixel space
      let face = faceLandmarkFilter.current.filter(mappedFace, now);
      let pose = poseLandmarkFilter.current.filter(mappedPose, now);
      let hands = mappedHands ? mappedHands.map((h, i) => handLandmarkFilters.current[i].filter(h, now)!).filter(Boolean) : null;

      // 3. Jitter smoothing & hold last pose briefly (up to 300ms) on momentary tracking loss
      if (face) {
        lastActiveFaceRef.current = { landmarks: face, time: now };
      } else if (lastActiveFaceRef.current && now - lastActiveFaceRef.current.time < 300) {
        face = lastActiveFaceRef.current.landmarks;
      }

      if (pose) {
        lastActivePoseRef.current = { landmarks: pose, time: now };
      } else if (lastActivePoseRef.current && now - lastActivePoseRef.current.time < 300) {
        pose = lastActivePoseRef.current.landmarks;
      }

      if (hands && hands.length > 0) {
        lastActiveHandsRef.current = { landmarks: hands, time: now };
      } else if (lastActiveHandsRef.current && now - lastActiveHandsRef.current.time < 300) {
        hands = lastActiveHandsRef.current.landmarks;
      }

      const cw = canvas.width;
      const ch = canvas.height;

      // Tracking stability check
      if (face) {
        trackingStableFrames.current = Math.min(60, trackingStableFrames.current + 1);
        if (trackingStableFrames.current >= 30) {
          setIsTrackingStable(true);
        }
      } else {
        trackingStableFrames.current = Math.max(0, trackingStableFrames.current - 2);
        if (trackingStableFrames.current === 0) {
          setIsTrackingStable(false);
        }
      }

      // Strict single-category rendering:
      // Only render jewellery for the currently selected category.
      // Exception: "sets" renders necklace + earrings together.
      const _cat = (category as string);
      const _isSets = _cat === "sets";
      const isEarringsActive = (_cat === "earrings" || _isSets) && Boolean(items["earrings"]);
      const isNoseRingActive = (_cat === "nose_ring" || _cat === "noserings") && Boolean(items["nose_ring"] || items["noserings"]);
      const isNecklaceActive = (_cat === "necklace" || _cat === "necklaces" || _isSets) && Boolean(items["necklace"] || items["necklaces"]);
      const isBanglesActive = (_cat === "bangles") && Boolean(items["bangles"]);
      const isRingActive = (_cat === "finger_ring" || _cat === "rings") && Boolean(items["finger_ring"] || items["rings"]);

      // Shoulder visibility detection for the 1.5s chest-hint delay
      const poseS11v = pose?.[11]?.visibility ?? 0;
      const poseS12v = pose?.[12]?.visibility ?? 0;
      const shouldersDetected = poseS11v > 0.4 && poseS12v > 0.4;
      if (shouldersDetected) {
        shoulderLostStartRef.current = null;
        if (showChestHint) setShowChestHint(false);
      } else {
        if (shoulderLostStartRef.current === null) {
          shoulderLostStartRef.current = now;
        } else if (now - shoulderLostStartRef.current > 1500) {
          if (!showChestHint) setShowChestHint(true);
        }
      }

      // ── Earrings (Always render BOTH earrings, with right mirrored) ────────
      if (isEarringsActive && face) {
        const item = items["earrings"];
        const img = item?.src ? imgCache.current[item.src] : undefined;
        const isStud = item?.type === "stud" || item?.id?.includes("stud") || false;

        if (item && img?.complete && img.naturalWidth > 0) {
          for (const side of ["left", "right"] as const) {
            const raw = calcEarringTransform(face, cw, ch, side, isStud);
            if (!raw) continue;
            const key = side === "left" ? "earL" : "earR";
            const t = filters.current[key].filter(raw, now);
            const lum = sampleRegionLuminance(ctx, t.x, t.y, t.scale * 0.5);
            // Mirror horizontally for the right ear
            drawPNG(ctx, img, t, item!.anchor, fit.scale, lum, side === "right");
          }
        }
      }

      // ── Nose ring (Nostril landmarks, scaled for clear visibility) ─────────
      if (isNoseRingActive && face) {
        const item = items["nose_ring"] || items["noserings"];
        const img = item?.src ? imgCache.current[item.src] : undefined;
        const isNathOrHoop = item?.type === "nath" || item?.type === "hoop" || item?.id?.includes("nath") || item?.id?.includes("hoop");

        if (img?.complete && img.naturalWidth > 0) {
          const raw = calcNoseRingTransform(face, cw, ch, isNathOrHoop);
          if (raw) {
            const sides: Array<["noseL" | "noseR", typeof raw.left]> = [];
            if (noseRingToggle === "left" || noseRingToggle === "both")
              sides.push(["noseL", raw.left]);
            if (noseRingToggle === "right" || noseRingToggle === "both")
              sides.push(["noseR", raw.right]);
            for (const [key, rawSide] of sides) {
              const t = filters.current[key].filter(rawSide, now);
              const lum = sampleRegionLuminance(ctx, t.x, t.y, t.scale * 0.4);
              drawPNG(ctx, img, t, item!.anchor, fit.scale, lum);
            }
          }
        }
      }

      // ── Necklace (3-point affine placement + collarbone drape + occlusion) ──
      let neckTargetsDebug: NecklaceTargetPoints | null = null;
      let neckAnchorsScreenDebug: {
        leftEnd: { x: number; y: number };
        rightEnd: { x: number; y: number };
        pendantCenter: { x: number; y: number };
      } | null = null;

      if (isNecklaceActive && face) {
        const item = items["necklace"] || items["necklaces"];
        const img = item?.src ? imgCache.current[item.src] : undefined;
        const anchors = item?.necklaceAnchors || {
          leftEnd: { x: 0.14, y: 0.04 },
          rightEnd: { x: 0.86, y: 0.04 },
          pendantCenter: { x: 0.50, y: 0.85 },
          bottomCenter: { x: 0.50, y: 0.94 },
        };

        if (item && img?.complete && img.naturalWidth > 0) {
          const necklaceType = item?.type || item?.style || 'regular';
          const rawTargets = calcNecklaceTargetPoints(face, pose, cw, ch, neckTuning, necklaceType);
          if (rawTargets) {
            const f = filters.current;
            const smoothed: NecklaceTargetPoints = {
              ...rawTargets,
              leftNeck: {
                x: f.neckLx.filter(rawTargets.leftNeck.x, now),
                y: f.neckLy.filter(rawTargets.leftNeck.y, now),
              },
              rightNeck: {
                x: f.neckRx.filter(rawTargets.rightNeck.x, now),
                y: f.neckRy.filter(rawTargets.rightNeck.y, now),
              },
              pendant: {
                x: f.pendX.filter(rawTargets.pendant.x, now),
                y: f.pendY.filter(rawTargets.pendant.y, now),
              },
              chainSag: {
                x: f.sagX.filter(rawTargets.chainSag.x, now),
                y: f.sagY.filter(rawTargets.chainSag.y, now),
              },
              chestCenter: {
                x: f.pendX.filter(rawTargets.pendant.x, now),
                y: f.pendY.filter(rawTargets.pendant.y, now),
              },
            };
            neckTargetsDebug = smoothed;

            const lN = { x: smoothed.leftNeck.x + fit.offsetX, y: smoothed.leftNeck.y + fit.offsetY };
            const rN = { x: smoothed.rightNeck.x + fit.offsetX, y: smoothed.rightNeck.y + fit.offsetY };
            const pend = { x: smoothed.pendant.x + fit.offsetX, y: smoothed.pendant.y + fit.offsetY };

            const imgW = img.naturalWidth * fit.scale;
            const imgH = img.naturalHeight * fit.scale;

            const srcL = { x: anchors.leftEnd.x * imgW, y: anchors.leftEnd.y * imgH };
            const srcR = { x: anchors.rightEnd.x * imgW, y: anchors.rightEnd.y * imgH };

            neckAnchorsScreenDebug = {
              leftEnd: lN,
              rightEnd: rN,
              pendantCenter: pend,
            };

            const sourceMid = { x: (srcL.x + srcR.x) / 2, y: (srcL.y + srcR.y) / 2 };
            const targetMid = { x: (lN.x + rN.x) / 2, y: (lN.y + rN.y) / 2 };
            const sourceSpan = Math.hypot(srcR.x - srcL.x, srcR.y - srcL.y) || 1;
            const targetSpan = Math.hypot(rN.x - lN.x, rN.y - lN.y);
            const scale = targetSpan / sourceSpan;
            const sourceAngle = Math.atan2(srcR.y - srcL.y, srcR.x - srcL.x);
            const chainAngle = smoothed.tilt - sourceAngle;
            const a = scale * Math.cos(chainAngle);
            const b = scale * Math.sin(chainAngle);
            const c = -scale * Math.sin(chainAngle);
            const d = scale * Math.cos(chainAngle);
            const e = targetMid.x - a * sourceMid.x - c * sourceMid.y;
            const ff = targetMid.y - b * sourceMid.x - d * sourceMid.y;
            // Fastening parts clip:
            // Any cord, tied string, clasp, hook or chain extension above the neck anchor baseline (srcL to srcR)
            // belongs behind the wearer's neck. We clip out those fastening elements so they sit naturally
            // out of sight behind the neck while 100% of the front decorative design is preserved.
            const cordCutY = Math.min(srcL.y, srcR.y);

            // Brightness matching
            const lum = sampleRegionLuminance(ctx, pend.x, pend.y, 80);
            const brightness = Math.min(1.35, Math.max(0.75, lum * 1.35 + 0.35));

            // Draw the complete necklace smoothly using neck endpoints & clamped shoulder-line tilt
            ctx.save();
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = "high";
            ctx.filter = `brightness(${brightness.toFixed(2)})`;
            ctx.setTransform(a, b, c, d, e, ff);
            if (cordCutY < imgH * 0.20) {
              ctx.beginPath();
              ctx.rect(0, cordCutY - 6, imgW, imgH * 2);
              ctx.clip();
            }
            ctx.drawImage(img, 0, 0, imgW, imgH);
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.filter = "none";
            ctx.restore();

            // Occlusion: chin & jaw over top strand
            if (useOcclusion) {
              drawNeckAndJawOcclusion(ctx, video, face, lN, rN, cw, ch, transform);
            }
          }
        }
      }

      // ── 3D Bangles & 3D Finger Ring (Three.js WebGL Layer) ──────────────
      if (threeManagerRef.current) {
        if (isBanglesActive || isRingActive) {
          const primaryHand = hands?.[0] ?? null;

          if (primaryHand && primaryHand.length >= 21) {
            if (isBanglesActive) {
              threeManagerRef.current.updateBangles(
                primaryHand,
                cw,
                ch,
                fit,
                bangleStackCount,
                wristShift,
                showDebug
              );
            }
            if (isRingActive) {
              const handedness = (handResult as unknown as { handedness?: Array<Array<{ categoryName?: string }>> })
                ?.handedness?.[0]?.[0]?.categoryName || "Right";

              threeManagerRef.current.updateRing(
                primaryHand,
                handedness,
                cw,
                ch,
                fit,
                fingerWidthRatio,
                showDebug
              );

              if (threeManagerRef.current?.ringDebugInfo) {
                setIsBackOfHand(threeManagerRef.current.ringDebugInfo.isBackOfHand);
              }
            }
          } else {
            if (isBanglesActive) {
              threeManagerRef.current.updateBangles(null, cw, ch, fit, bangleStackCount, wristShift, showDebug);
            }
            if (isRingActive) {
              threeManagerRef.current.updateRing(null, undefined, cw, ch, fit, fingerWidthRatio, showDebug);
            }
          }

          threeManagerRef.current.render();
        } else {
          threeManagerRef.current.hideAll();
        }
      }

      if (showDebug) {
        drawDebug(
          ctx,
          face,
          pose,
          hands,
          cw,
          ch,
          neckTargetsDebug,
          neckAnchorsScreenDebug,
          threeManagerRef.current?.bangleDebugInfo,
          threeManagerRef.current?.ringDebugInfo
        );
      }
    }

    scheduleNext();
  }, [
    isCameraActive, isReady, isFaceLoaded, isHandLoaded, isPoseLoaded,
    detect, category, items, noseRingToggle, fit, showDebug, videoRef,
    neckTuning, useOcclusion, bangleStackCount,
    wristShift, fingerWidthRatio, facingMode,
    showChestHint,
  ]);

  const cancelNextFrame = useCallback(() => {
    const video = videoRef.current;
    if (frameHandleRef.current !== null) {
      if (video && "cancelVideoFrameCallback" in video) {
        try {
          (video as unknown as { cancelVideoFrameCallback: (handle: number) => void }).cancelVideoFrameCallback(frameHandleRef.current);
        } catch {}
      }
      cancelAnimationFrame(frameHandleRef.current);
      frameHandleRef.current = null;
    }
  }, [videoRef]);

  useEffect(() => {
    if (isCameraActive) {
      renderLoop();
    }
    return () => {
      cancelNextFrame();
    };
  }, [renderLoop, isCameraActive, cancelNextFrame]);

  // ── Snapshot: composite Video + 2D Canvas + 3D WebGL Canvas ────────────────
  const handleSnapshot = () => {
    if (!canvasRef.current || !videoRef.current || !onSnapshotReady) return;
    const snap = document.createElement("canvas");
    const stageW = stageContainerRef.current?.clientWidth || videoRef.current.videoWidth || 1280;
    const stageH = stageContainerRef.current?.clientHeight || videoRef.current.videoHeight || 720;
    const snapW = Math.round(stageW * (window.devicePixelRatio || 1));
    const snapH = Math.round(stageH * (window.devicePixelRatio || 1));
    snap.width  = snapW;
    snap.height = snapH;
    const sctx = snap.getContext("2d");
    if (!sctx) return;

    // Draw video using cover transform
    const transform = computeCanvasTransform(
      snapW,
      snapH,
      videoRef.current.videoWidth,
      videoRef.current.videoHeight,
      facingMode === "user",
      1
    );

    sctx.save();
    if (facingMode === "user") {
      sctx.translate(snapW, 0);
      sctx.scale(-1, 1);
    }
    sctx.drawImage(
      videoRef.current,
      0, 0, videoRef.current.videoWidth, videoRef.current.videoHeight,
      transform.offsetX, transform.offsetY, transform.renderedW, transform.renderedH
    );
    sctx.restore();

    // Composite 2D canvas directly
    sctx.drawImage(canvasRef.current, 0, 0, snapW, snapH);

    // Composite 3D WebGL Canvas directly
    if (threeCanvasRef.current) {
      sctx.drawImage(threeCanvasRef.current, 0, 0, snapW, snapH);
    }

    onSnapshotReady(snap.toDataURL("image/png"));
  };

  const handleStop = () => {
    stopCamera();
    cancelNextFrame();
    const ctx = canvasRef.current?.getContext("2d");
    if (ctx) ctx.clearRect(0, 0, canvasRef.current!.width, canvasRef.current!.height);
    if (threeManagerRef.current) threeManagerRef.current.hideAll();
    onCameraStop?.();
  };

  // Ensure camera and RAF/RVFC are cancelled when Stage unmounts (e.g. Back to Catalog)
  useEffect(() => {
    return () => {
      stopCamera();
      cancelNextFrame();
    };
  }, [stopCamera, cancelNextFrame]);

  const modelStatus = [
    isFaceLoaded ? null : "Face",
    isPoseLoaded ? null : "Pose",
    isHandLoaded ? null : "Hand",
  ].filter(Boolean);

  return (
    <div className="fixed inset-0 w-screen flex flex-col relative z-10 overflow-hidden" style={{ height: '100dvh' }}>


      {/* Debug overlay for the selected product and the asset actually loaded */}
      {showDebug && (
        <div className="absolute top-20 left-4 z-40 pointer-events-none hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/85 backdrop-blur-xl border border-[#D4AF37]/35 text-[11px] font-mono text-neutral-300 shadow-xl shadow-black/80">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>ID: <strong className="text-[#F5E1A4]">{selectedProduct?.id || "none"}</strong></span>
          <span className="text-white/30">|</span>
          <span className="text-white/60 truncate max-w-[280px]">
            Asset: {loadedAssetInfo && loadedAssetInfo.productId === selectedProduct?.id
              ? loadedAssetInfo.url
              : selectedProduct?.modelUrl || selectedProduct?.src || "unavailable"}
          </span>
        </div>
      )}

      {assetToast && (
        <div className="absolute top-32 left-1/2 -translate-x-1/2 z-50 rounded-full border border-amber-400/40 bg-black/85 px-3 py-1.5 text-xs text-amber-200 shadow-lg pointer-events-none">
          {assetToast}
        </div>
      )}

      {/* Floating hint pill: cleanly positioned below top header (top-20) to prevent overlap */}
      {hint && isCameraActive && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-30 bg-black/80 text-amber-200 border border-amber-400/40 px-5 py-2 rounded-full text-xs sm:text-sm font-medium backdrop-blur-xl pointer-events-none shadow-2xl animate-fade-in text-center max-w-md">
          {hint}
        </div>
      )}

      {/* MediaPipe Model Error notification (shows feed, but alerts user about model failure) */}
      {landmarkError && isCameraActive && (
        <div className="absolute top-28 left-1/2 -translate-x-1/2 z-40 bg-amber-950/90 border border-amber-500/60 text-amber-200 px-4 py-2.5 rounded-xl text-xs max-w-lg text-center shadow-xl backdrop-blur-md flex items-center justify-between gap-3">
          <span>⚠️ {landmarkError} (Camera is active without tracking)</span>
          <button
            onClick={retryInit}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1 rounded-lg text-[11px] whitespace-nowrap transition"
          >
            Retry Models
          </button>
        </div>
      )}

      {/* Model loading indicator */}
      {!landmarkError && modelStatus.length > 0 && isCameraActive && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-30 bg-amber-900/70 text-amber-200 px-3 py-1 rounded-full text-xs backdrop-blur-sm pointer-events-none">
          Loading: {modelStatus.join(", ")} models…
        </div>
      )}

      {/* Video + 2D Canvas + 3D WebGL Canvas Layer — fills entire stage */}
      <div ref={stageContainerRef} className="absolute inset-0 bg-black overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <video
          ref={videoRef}
          playsInline
          muted
          className={`absolute inset-0 w-full h-full object-cover ${facingMode === "user" ? "scale-x-[-1]" : ""}`}
          style={{ display: "block" }}
        />
        {/* 2D Canvas overlay for necklace, earrings, nose ring, debug lines */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full pointer-events-none z-10"
        />
        {/* 3D WebGL Canvas overlay for Bangles & Finger Ring */}
        <canvas
          ref={threeCanvasRef}
          className="absolute inset-0 w-full h-full pointer-events-none z-20"
        />

        {/* Framing Guide Overlay (Necklace tab only) */}
        {(category === "necklace" || category === "necklaces" || category === "sets") && isCameraActive && !isTrackingStable && (
          <div className="absolute inset-0 pointer-events-none z-30 flex flex-col items-center justify-between p-6">
            <div className="w-48 h-36 border-2 border-dashed border-amber-300/40 rounded-full mt-16 flex items-center justify-center">
              <span className="text-[10px] text-amber-200/60 uppercase font-bold tracking-wider">Head Area</span>
            </div>
            <div className="w-80 h-28 border-2 border-dashed border-indigo-300/30 rounded-3xl mb-8 flex items-center justify-center">
              <span className="text-[10px] text-indigo-200/50 uppercase font-bold tracking-wider">Chest / Shoulders</span>
            </div>
          </div>
        )}

        {/* Starting spinner */}
        {cameraStatus === "starting" && !permissionError && !cameraErrorMsg && (
          <div className="absolute inset-0 flex items-center justify-center z-40 bg-black/70 backdrop-blur-sm">
            <div className="flex flex-col items-center gap-3">
              <div className="w-10 h-10 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
              <p className="text-amber-300 text-sm font-semibold">Starting camera…</p>
            </div>
          </div>
        )}

        {/* Idle: No jewellery selected */}
        {!isJewellerySelected && !permissionError && !cameraErrorMsg && cameraStatus === "idle" && (
          <div className="absolute inset-0 flex items-center justify-center z-40 bg-black/75 backdrop-blur-sm p-4 text-center">
            <p className="text-amber-200 text-sm font-medium">Please select a piece of jewellery to start camera</p>
          </div>
        )}

        {/* Idle: Jewellery selected -> Prompt user with Start Camera button (user gesture) */}
        {isJewellerySelected && !permissionError && !cameraErrorMsg && cameraStatus === "idle" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center z-40 bg-gradient-to-b from-slate-950/80 via-slate-900/90 to-slate-950/95 backdrop-blur-md p-6 text-center">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-400/30 flex items-center justify-center text-3xl mb-3 shadow-lg shadow-amber-500/10">
              📸
            </div>
            <h3 className="text-base sm:text-lg font-bold text-slate-100 mb-1">
              Ready to Try On: {(category && items[category]?.name) || "Jewellery Piece"}
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mb-4">
              Click below to grant camera access and view real-time AR try-on.
            </p>

            {devices.length > 1 && (
              <div className="mb-4 flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
                <label className="text-xs text-slate-300 font-medium">Camera:</label>
                <select
                  value={selectedDeviceId}
                  onChange={(e) => setSelectedDeviceId(e.target.value)}
                  className="bg-transparent text-slate-200 text-xs focus:outline-none cursor-pointer max-w-[200px]"
                >
                  {devices.map((d, idx) => (
                    <option key={d.deviceId || idx} value={d.deviceId} className="bg-slate-900 text-white">
                      {d.label || `Camera ${idx + 1}`}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <button
              id="start-camera-button"
              onClick={() => startCamera()}
              className="flex items-center gap-2.5 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black px-8 py-3.5 rounded-xl shadow-xl shadow-amber-500/25 transition active:scale-95 text-sm sm:text-base cursor-pointer"
            >
              <span>📸</span> Start Camera
            </button>
          </div>
        )}

        {/* Error state with retry camera and device selector */}
        {(permissionError || cameraErrorMsg || cameraStatus === "error") && (
          <div className="absolute inset-0 flex items-center justify-center z-50 bg-black/85 backdrop-blur-md p-6">
            <div className="bg-red-950/90 border border-red-500/60 text-red-100 p-6 rounded-2xl max-w-md text-center shadow-2xl">
              <div className="text-3xl mb-2">📷</div>
              <h3 className="font-bold text-lg mb-1 text-red-200">Camera Access Error</h3>
              <p className="text-sm text-red-300 mb-4">{permissionError || cameraErrorMsg || "Could not access camera."}</p>

              {devices.length > 1 && (
                <div className="mb-4 flex items-center justify-center gap-2">
                  <label className="text-xs text-red-200 font-medium">Switch Camera:</label>
                  <select
                    value={selectedDeviceId}
                    onChange={(e) => setSelectedDeviceId(e.target.value)}
                    className="bg-red-900/60 text-red-100 text-xs px-3 py-1.5 rounded-lg border border-red-500/50 focus:outline-none"
                  >
                    {devices.map((d, idx) => (
                      <option key={d.deviceId || idx} value={d.deviceId} className="bg-slate-900 text-white">
                        {d.label || `Camera ${idx + 1}`}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <button
                id="retry-camera-btn"
                onClick={handleTryAgain}
                className="bg-red-600 hover:bg-red-500 text-white font-semibold px-6 py-2.5 rounded-xl shadow-lg transition active:scale-95 cursor-pointer"
              >
                Retry camera
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ── Right-side vertical control rail ── */}
      {isCameraActive && (
        <>
        <div className="absolute right-3 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-2 p-2 rounded-2xl bg-black/75 backdrop-blur-xl border border-white/15 shadow-2xl pointer-events-auto">
          <button
            id="flip-cam-btn"
            onClick={toggleFacingMode}
            title="Flip Camera"
            className="flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-200 border border-white/10 hover:border-[#D4AF37]/50 text-[10px] font-medium transition-all active:scale-95 cursor-pointer"
          >
            <span className="text-base">🔄</span>
            <span>Flip</span>
          </button>
          <button
            id="snapshot-btn"
            onClick={handleSnapshot}
            title="Take Snapshot"
            className="flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-xl bg-gradient-to-b from-[#F5E1A4] via-[#E5C158] to-[#D4AF37] hover:brightness-110 text-neutral-950 text-[10px] font-bold transition-all active:scale-95 shadow-sm cursor-pointer"
          >
            <span className="text-base">📸</span>
            <span>Snap</span>
          </button>
          <button
            id="fit-btn"
            onClick={() => setShowFitPanel((p) => !p)}
            title="Adjust Fit"
            className={`flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-xl border text-[10px] font-medium transition-all active:scale-95 cursor-pointer ${
              showFitPanel
                ? "bg-[#D4AF37]/25 text-[#F5E1A4] border-[#D4AF37]"
                : "bg-white/5 hover:bg-white/10 text-neutral-200 border-white/10"
            }`}
          >
            <span className="text-base">⚙</span>
            <span>Fit</span>
          </button>
          <button
            id="stop-cam-btn"
            onClick={handleStop}
            title="Stop Camera"
            className="flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-900/60 text-red-200 border border-red-800/40 text-[10px] font-medium transition-all active:scale-95 cursor-pointer"
          >
            <span className="text-base">✕</span>
            <span>Stop</span>
          </button>
          {/* Debug & Occl only when ?debug=1 */}
          {isDebugUrl && (
            <>
              <button
                onClick={onToggleDebug}
                title="Toggle Debug"
                className={`px-2 py-1.5 rounded-xl border text-[10px] font-medium transition-all cursor-pointer ${
                  showDebug
                    ? "bg-purple-900/50 text-purple-200 border-purple-500/50"
                    : "bg-white/5 text-neutral-400 border-white/5 hover:text-white"
                }`}
              >
                {showDebug ? "Dbg ✓" : "Dbg"}
              </button>
              {(category === "necklace" || category === "necklaces" || category === "sets") && (
                <button
                  onClick={onToggleOcclusion}
                  title="Toggle Occlusion"
                  className={`px-2 py-1.5 rounded-xl border text-[10px] font-medium transition-all cursor-pointer ${
                    useOcclusion
                      ? "bg-teal-900/50 text-teal-200 border-teal-500/50"
                      : "bg-white/5 text-neutral-400 border-white/5 hover:text-white"
                  }`}
                >
                  {useOcclusion ? "Occ ✓" : "Occ"}
                </button>
              )}
            </>
          )}
          {category === "bangles" && (
            <div className="flex flex-col items-center gap-0.5 bg-white/5 border border-white/10 px-1.5 py-1 rounded-xl">
              <span className="text-[9px] text-neutral-400">Stack</span>
              <div className="flex gap-0.5">
                {([1, 2, 4, 6] as const).map((count) => (
                  <button
                    key={count}
                    onClick={() => setBangleStackCount(count)}
                    className={`px-1 py-0.5 rounded text-[9px] font-bold transition cursor-pointer ${
                      bangleStackCount === count
                        ? "bg-[#D4AF37] text-neutral-950"
                        : "text-neutral-400 hover:text-white"
                    }`}
                  >
                    {count}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Fit panel (positioned above the bottom area) */}
        {showFitPanel && (
          <div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-30 pointer-events-auto mx-auto w-full max-w-xl bg-slate-900/90 backdrop-blur-xl rounded-2xl border border-slate-700/60 p-3 shadow-2xl">
            <div className="flex gap-3 items-center">
              <span className="text-xs font-semibold text-slate-400 whitespace-nowrap">Fit</span>
              <div className="flex-1 flex gap-3">
                <label className="flex flex-col text-[10px] text-slate-400 flex-1">
                  Size ({fit.scale.toFixed(2)}×)
                  <input type="range" min="0.5" max="2" step="0.05" value={fit.scale}
                    onChange={(e) => setFit({ ...fit, scale: parseFloat(e.target.value) })}
                    className="w-full accent-indigo-500" />
                </label>
                <label className="flex flex-col text-[10px] text-slate-400 flex-1">
                  X ({fit.offsetX}px)
                  <input type="range" min="-150" max="150" value={fit.offsetX}
                    onChange={(e) => setFit({ ...fit, offsetX: parseInt(e.target.value) })}
                    className="w-full accent-indigo-500" />
                </label>
                <label className="flex flex-col text-[10px] text-slate-400 flex-1">
                  Y ({fit.offsetY}px)
                  <input type="range" min="-150" max="150" value={fit.offsetY}
                    onChange={(e) => setFit({ ...fit, offsetY: parseInt(e.target.value) })}
                    className="w-full accent-indigo-500" />
                </label>
              </div>
              <button onClick={() => setFit({ scale: 1, offsetX: 0, offsetY: 0 })}
                className="text-[10px] bg-slate-700 px-2 py-1 rounded-lg text-slate-300">Reset</button>
            </div>
          </div>
        )}

          {/* Debug Sliders — only visible when ?debug=1 and debug is toggled on */}
          {isDebugUrl && showDebug && (
            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 z-30 pointer-events-auto flex flex-col gap-3 bg-purple-950/40 p-4 rounded-2xl border border-purple-800/50 backdrop-blur-md shadow-xl animate-fade-in w-full max-w-xl mx-auto">
              {(category === "necklace" || category === "necklaces" || category === "sets") && (
                <>
                  <div className="flex items-center justify-between border-b border-purple-800/40 pb-2">
                    <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                      Live Body Anchor Ratios
                    </span>
                    <button
                      onClick={() => setNeckTuning(DEFAULT_NECKLACE_TUNING)}
                      className="text-[11px] text-purple-400 hover:text-purple-200 transition bg-purple-900/40 px-2.5 py-1 rounded-md"
                    >
                      Reset Ratios
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <label className="flex flex-col text-xs text-purple-200">
                      <span>Neck Width: <strong className="font-mono text-purple-400">{neckTuning.neckWidthRatio.toFixed(2)}×fw</strong></span>
                      <input
                        type="range" min="0.25" max="0.75" step="0.01" value={neckTuning.neckWidthRatio}
                        onChange={(e) => setNeckTuning({ ...neckTuning, neckWidthRatio: parseFloat(e.target.value) })}
                        className="w-full mt-1 accent-purple-500"
                      />
                    </label>
                    <label className="flex flex-col text-xs text-purple-200">
                      <span>Neck Y Drop: <strong className="font-mono text-purple-400">{neckTuning.neckYDropRatio.toFixed(2)}×fw</strong></span>
                      <input
                        type="range" min="0.05" max="0.50" step="0.01" value={neckTuning.neckYDropRatio}
                        onChange={(e) => setNeckTuning({ ...neckTuning, neckYDropRatio: parseFloat(e.target.value) })}
                        className="w-full mt-1 accent-purple-500"
                      />
                    </label>
                    <label className="flex flex-col text-xs text-purple-200">
                      <span>Pendant Y Drop: <strong className="font-mono text-purple-400">{neckTuning.pendantYDropRatio.toFixed(2)}×fw</strong></span>
                      <input
                        type="range" min="0.80" max="2.40" step="0.02" value={neckTuning.pendantYDropRatio}
                        onChange={(e) => setNeckTuning({ ...neckTuning, pendantYDropRatio: parseFloat(e.target.value) })}
                        className="w-full mt-1 accent-purple-500"
                      />
                    </label>
                    <label className="flex flex-col text-xs text-purple-200">
                      <span>Chain Sag Point: <strong className="font-mono text-purple-400">{neckTuning.chainSagRatio.toFixed(2)}×fw</strong></span>
                      <input
                        type="range" min="0.60" max="2.00" step="0.02" value={neckTuning.chainSagRatio}
                        onChange={(e) => setNeckTuning({ ...neckTuning, chainSagRatio: parseFloat(e.target.value) })}
                        className="w-full mt-1 accent-purple-500"
                      />
                    </label>
                  </div>
                </>
              )}

              {category === "bangles" && (
                <>
                  <div className="flex items-center justify-between border-b border-purple-800/40 pb-2">
                    <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                      3D Bangle Alignment & Wrist Shift
                    </span>
                    <button
                      onClick={() => setWristShift(0.25)}
                      className="text-[11px] text-purple-400 hover:text-purple-200 transition bg-purple-900/40 px-2.5 py-1 rounded-md"
                    >
                      Reset Wrist Shift
                    </button>
                  </div>
                  <div className="flex gap-4">
                    <label className="flex flex-col text-xs text-purple-200 flex-1">
                      <span>Wrist Shift along Forearm: <strong className="font-mono text-purple-400">{wristShift.toFixed(2)}×|lm0-lm9|</strong></span>
                      <input
                        type="range" min="0.0" max="0.50" step="0.01" value={wristShift}
                        onChange={(e) => setWristShift(parseFloat(e.target.value))}
                        className="w-full mt-1 accent-purple-500"
                      />
                    </label>
                  </div>
                </>
              )}

              {(category === "finger_ring" || category === "rings") && (
                <>
                  <div className="flex items-center justify-between border-b border-purple-800/40 pb-2">
                    <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                      3D Ring Finger Width & Fit
                    </span>
                    <button
                      onClick={() => setFingerWidthRatio(0.42)}
                      className="text-[11px] text-purple-400 hover:text-purple-200 transition bg-purple-900/40 px-2.5 py-1 rounded-md"
                    >
                      Reset Finger Width
                    </button>
                  </div>
                  <div className="flex gap-4">
                    <label className="flex flex-col text-xs text-purple-200 flex-1">
                      <span>Finger Width Ratio: <strong className="font-mono text-purple-400">{fingerWidthRatio.toFixed(2)}×|lm13-lm14|</strong></span>
                      <input
                        type="range" min="0.25" max="0.65" step="0.01" value={fingerWidthRatio}
                        onChange={(e) => setFingerWidthRatio(parseFloat(e.target.value))}
                        className="w-full mt-1 accent-purple-500"
                      />
                    </label>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Integrated Bottom Dock: Category Tabs + Jewel Strip */}
          {children}
        </>
      )}
    </div>
  );
}
