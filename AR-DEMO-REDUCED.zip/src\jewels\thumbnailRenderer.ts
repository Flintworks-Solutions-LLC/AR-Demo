import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { JewelConfig, MetalColorType } from './types';
import { buildJewel } from './index';
import { getCachedThumbnail, saveCachedThumbnail } from '@/lib/indexedDb';

let sharedRenderer: THREE.WebGLRenderer | null = null;
let sharedScene: THREE.Scene | null = null;
let sharedCamera: THREE.PerspectiveCamera | null = null;

function getSharedSetup(): {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
} {
  if (typeof window === 'undefined') {
    throw new Error('Offscreen thumbnail generation is client-side only');
  }

  if (!sharedRenderer) {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;

    sharedRenderer = new THREE.WebGLRenderer({
      canvas,
      alpha: true,
      antialias: true,
      preserveDrawingBuffer: true,
    });
    sharedRenderer.setSize(512, 512);
    sharedRenderer.setPixelRatio(1);
    sharedRenderer.toneMapping = THREE.ACESFilmicToneMapping;
    sharedRenderer.toneMappingExposure = 1.4;
    sharedRenderer.outputColorSpace = THREE.SRGBColorSpace;

    sharedScene = new THREE.Scene();
    const pmremGenerator = new THREE.PMREMGenerator(sharedRenderer);
    pmremGenerator.compileEquirectangularShader();
    sharedScene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;

    // 3-point Studio Lighting
    const keyLight = new THREE.DirectionalLight(0xfff7e6, 2.8);
    keyLight.position.set(4, 6, 5);
    sharedScene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xe8f0ff, 1.4);
    fillLight.position.set(-4, 3, 4);
    sharedScene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 2.2);
    rimLight.position.set(0, -4, -4);
    sharedScene.add(rimLight);

    const ambLight = new THREE.AmbientLight(0xffffff, 0.8);
    sharedScene.add(ambLight);

    sharedCamera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
  }

  return { renderer: sharedRenderer, scene: sharedScene!, camera: sharedCamera! };
}

/**
 * Renders an offscreen 512x512 transparent PNG thumbnail directly from the 3D model.
 * Caches the result in IndexedDB so it renders only once per item & metal tone.
 */
export async function getOrRenderThumbnail(
  config: JewelConfig,
  metal: MetalColorType = 'gold'
): Promise<string> {
  const cacheKey = `thumb_${config.id}_${metal}`;

  // 1. Check IndexedDB
  const cached = await getCachedThumbnail(cacheKey);
  if (cached) {
    return cached;
  }

  if (typeof window === 'undefined') {
    return '';
  }

  try {
    const { renderer, scene, camera } = getSharedSetup();

    // 2. Build the exact model
    const model = await buildJewel(config, metal);

    // 3. Clear previous jewel meshes from scene (preserving lights)
    const toRemove: THREE.Object3D[] = [];
    scene.children.forEach((child) => {
      if ((child as THREE.Group).isGroup) {
        toRemove.push(child);
      }
    });
    toRemove.forEach((c) => scene.remove(c));

    scene.add(model);

    // 4. Position and angle model in 3/4 front view
    model.rotation.set(0, 0, 0);
    if (config.category === 'finger_ring') {
      model.rotation.x = -Math.PI * 0.15;
      model.rotation.y = Math.PI * 0.25;
    } else if (config.category === 'bangles') {
      model.rotation.x = Math.PI * 0.25;
      model.rotation.y = Math.PI * 0.25;
    } else if (config.category === 'necklace') {
      model.rotation.x = -Math.PI * 0.05;
      model.rotation.y = 0;
    } else if (config.category === 'earrings') {
      model.rotation.y = Math.PI * 0.15;
    } else if (config.category === 'nose_ring') {
      model.rotation.x = -Math.PI * 0.1;
      model.rotation.y = Math.PI * 0.2;
    }

    model.updateMatrixWorld(true);

    // 5. Fit camera to Box3
    const box = new THREE.Box3().setFromObject(model);
    const center = new THREE.Vector3();
    const size = new THREE.Vector3();
    box.getCenter(center);
    box.getSize(size);

    const maxDim = Math.max(size.x, size.y, size.z) || 1;
    const fov = camera.fov * (Math.PI / 180);
    let cameraZ = Math.abs((maxDim / 2) / Math.tan(fov / 2)) * 1.35;
    cameraZ = Math.max(cameraZ, 2.5);

    camera.position.set(center.x, center.y + maxDim * 0.1, center.z + cameraZ);
    camera.lookAt(center);
    camera.updateProjectionMatrix();

    // 6. Render
    renderer.render(scene, camera);

    // 7. Extract data URL
    const dataUrl = renderer.domElement.toDataURL('image/png');

    // 8. Cache in IndexedDB asynchronously
    saveCachedThumbnail(cacheKey, dataUrl).catch(() => {});

    // Clean up model from scene
    scene.remove(model);

    return dataUrl;
  } catch (err) {
    console.error(`Error rendering thumbnail for ${config.id}:`, err);
    return '';
  }
}
