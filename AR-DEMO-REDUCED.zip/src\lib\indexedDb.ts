/**
 * IndexedDB persistence for user-uploaded jewellery items & rendered 3D thumbnails.
 * Survives page refreshes and browser restarts.
 */

export interface StoredJewelleryItem {
  id: string;
  name: string;
  category: string;
  price?: string;
  src: string;          // cutout data URL or blob URL
  originalSrc?: string;  // before background removal
  modelUrl?: string;    // GLB data URL or blob URL
  type?: string;
  anchor: { x: number; y: number };
  necklaceAnchors?: {
    leftEnd: { x: number; y: number };
    rightEnd: { x: number; y: number };
    pendantCenter?: { x: number; y: number };
    bottomCenter?: { x: number; y: number };
  };
  widthRatio?: number;
  scaleFactor?: number;
  yOffset?: number;
  metal?: "gold" | "silver" | "rose_gold";
  uprightAngle?: number;
  aspect?: number;
  setPieces?: Record<string, unknown>;
  meta?: Record<string, unknown>;
  createdAt: number;
}

const DB_NAME = "AuraLuxeJewelleryDB";
const STORE_CUSTOM = "custom_jewellery";
const STORE_THUMBNAILS = "thumbnails";
const DB_VERSION = 2;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !window.indexedDB) {
      reject(new Error("IndexedDB not supported"));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_CUSTOM)) {
        db.createObjectStore(STORE_CUSTOM, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(STORE_THUMBNAILS)) {
        db.createObjectStore(STORE_THUMBNAILS, { keyPath: "key" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveCustomJewel(item: StoredJewelleryItem): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_CUSTOM, "readwrite");
      const store = tx.objectStore(STORE_CUSTOM);
      const req = store.put(item);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error("IndexedDB save error:", err);
  }
}

export async function getAllCustomJewels(): Promise<StoredJewelleryItem[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_CUSTOM, "readonly");
      const store = tx.objectStore(STORE_CUSTOM);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn("IndexedDB read error:", err);
    return [];
  }
}

export async function deleteCustomJewel(id: string): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_CUSTOM, "readwrite");
      const store = tx.objectStore(STORE_CUSTOM);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error("IndexedDB delete error:", err);
  }
}

export async function getCachedThumbnail(key: string): Promise<string | null> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_THUMBNAILS, "readonly");
      const store = tx.objectStore(STORE_THUMBNAILS);
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ? req.result.dataUrl : null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function saveCachedThumbnail(key: string, dataUrl: string): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_THUMBNAILS, "readwrite");
      const store = tx.objectStore(STORE_THUMBNAILS);
      const req = store.put({ key, dataUrl, timestamp: Date.now() });
      req.onsuccess = () => resolve();
      req.onerror = () => resolve();
    });
  } catch (err) {
    console.warn("Could not cache thumbnail in IndexedDB:", err);
  }
}
