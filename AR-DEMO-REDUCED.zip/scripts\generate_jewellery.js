const fs = require('fs');
const path = require('path');

const PUBLIC_DIR = path.join(__dirname, '../public/jewellery');

const categories = ['earrings', 'nose_ring', 'necklace'];

categories.forEach(cat => {
  const dir = path.join(PUBLIC_DIR, cat);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

const manifest = {
  earrings: [
    { id: 'jhumka', name: 'Traditional Jhumka', src: '/jewellery/earrings/jhumka.svg', anchor: { x: 50, y: 5 } },
    { id: 'stud', name: 'Diamond Stud', src: '/jewellery/earrings/stud.svg', anchor: { x: 50, y: 50 } },
    { id: 'hoop', name: 'Gold Hoop', src: '/jewellery/earrings/hoop.svg', anchor: { x: 50, y: 5 } },
    { id: 'chandbali', name: 'Chandbali', src: '/jewellery/earrings/chandbali.svg', anchor: { x: 50, y: 5 } },
  ],
  nose_ring: [
    { id: 'nath', name: 'Bridal Nath', src: '/jewellery/nose_ring/nath.svg', anchor: { x: 10, y: 10 } },
    { id: 'nose_stud', name: 'Simple Stud', src: '/jewellery/nose_ring/nose_stud.svg', anchor: { x: 50, y: 50 } },
    { id: 'nose_hoop', name: 'Nose Hoop', src: '/jewellery/nose_ring/nose_hoop.svg', anchor: { x: 10, y: 50 } },
  ],
  necklace: [
    { id: 'temple', name: 'Temple Necklace', src: '/jewellery/necklace/temple.svg', anchor: { x: 50, y: 10 }, type: 'regular' },
    { id: 'layered', name: 'Layered Chains', src: '/jewellery/necklace/layered.svg', anchor: { x: 50, y: 10 }, type: 'regular' },
    { id: 'pearl', name: 'Pearl Strand', src: '/jewellery/necklace/pearl.svg', anchor: { x: 50, y: 10 }, type: 'regular' },
    { id: 'solitaire', name: 'Solitaire Pendant', src: '/jewellery/necklace/solitaire.svg', anchor: { x: 50, y: 10 }, type: 'regular' },
    { id: 'choker', name: 'Gold Choker', src: '/jewellery/necklace/choker.svg', anchor: { x: 50, y: 50 }, type: 'choker' },
  ]
};

// Very basic SVGs (gray silhouettes, which will be tinted in canvas if needed or just use as is)
const svgContent = {
  earrings: {
    jhumka: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M50 5 L30 40 Q50 50 70 40 Z M25 45 Q50 60 75 45 L70 60 Q50 70 30 60 Z" fill="#D4AF37"/><circle cx="50" cy="70" r="5" fill="#D4AF37"/><circle cx="40" cy="65" r="3" fill="#D4AF37"/><circle cx="60" cy="65" r="3" fill="#D4AF37"/></svg>`,
    stud: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="30" fill="#E2E8F0"/><circle cx="50" cy="50" r="20" fill="#FFFFFF"/></svg>`,
    hoop: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="45" fill="none" stroke="#D4AF37" stroke-width="8"/></svg>`,
    chandbali: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M20 50 A 30 30 0 0 0 80 50 A 20 20 0 0 1 20 50" fill="#D4AF37"/><circle cx="50" cy="20" r="10" fill="#D4AF37"/></svg>`
  },
  nose_ring: {
    nath: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="40" cy="50" r="35" fill="none" stroke="#D4AF37" stroke-width="4"/><path d="M5 50 Q 50 100 95 10" fill="none" stroke="#D4AF37" stroke-width="2" stroke-dasharray="2,2"/><circle cx="10" cy="50" r="8" fill="#E2E8F0"/></svg>`,
    nose_stud: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="30" fill="#E2E8F0"/></svg>`,
    nose_hoop: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M10 50 A 40 40 0 1 0 90 50" fill="none" stroke="#D4AF37" stroke-width="6"/></svg>`
  },
  necklace: {
    temple: `<svg viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg"><path d="M10 10 Q 100 120 190 10" fill="none" stroke="#D4AF37" stroke-width="15"/><circle cx="100" cy="85" r="25" fill="#D4AF37"/><polygon points="100,60 120,110 80,110" fill="#B8860B"/></svg>`,
    layered: `<svg viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg"><path d="M20 10 Q 100 80 180 10" fill="none" stroke="#D4AF37" stroke-width="4"/><path d="M10 10 Q 100 110 190 10" fill="none" stroke="#D4AF37" stroke-width="6"/><path d="M0 10 Q 100 140 200 10" fill="none" stroke="#D4AF37" stroke-width="8"/></svg>`,
    pearl: `<svg viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg"><path d="M10 10 Q 100 120 190 10" fill="none" stroke="#F8FAFC" stroke-width="12" stroke-dasharray="12,4"/></svg>`,
    solitaire: `<svg viewBox="0 0 200 150" xmlns="http://www.w3.org/2000/svg"><path d="M20 10 Q 100 100 180 10" fill="none" stroke="#94A3B8" stroke-width="2"/><polygon points="100,70 110,90 100,110 90,90" fill="#E2E8F0"/></svg>`,
    choker: `<svg viewBox="0 0 200 80" xmlns="http://www.w3.org/2000/svg"><path d="M10 40 Q 100 60 190 40" fill="none" stroke="#D4AF37" stroke-width="25"/><path d="M10 40 Q 100 60 190 40" fill="none" stroke="#B8860B" stroke-width="5" stroke-dasharray="10,5"/></svg>`
  }
};

Object.keys(manifest).forEach(category => {
  manifest[category].forEach(item => {
    const content = svgContent[category][item.id];
    fs.writeFileSync(path.join(PUBLIC_DIR, category, `${item.id}.svg`), content);
  });
});

fs.writeFileSync(path.join(PUBLIC_DIR, 'manifest.json'), JSON.stringify(manifest, null, 2));

console.log('Jewellery generated!');
