"use client";

import React, { useRef, useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Box,
  Images,
  AlertCircle,
  CheckCircle2,
  Info,
  Loader2,
  BookOpen,
  Sparkles,
  Camera,
  RotateCcw,
  Plus,
  Trash2,
  ArrowRight,
  RefreshCw,
} from "lucide-react";
import { LandmarkerCategory } from "@/hooks/useLandmarkers";
import { useJewelleryStore } from "@/context/JewelleryStoreContext";
import { StoredJewelleryItem } from "@/lib/indexedDb";
import { validateGlbFile } from "@/lib/glbValidator";
import { validatePhotoSequence, preloadPhotoSequence } from "@/lib/imageSequenceUtils";
import { removeBackgroundAI } from "@/lib/backgroundRemoval";
import { detectJewellery } from "@/lib/detectJewellery";
import { enhanceUploadedProduct } from "@/lib/imageEnhancement";
import { prepareAsset, PreparedAssetResult } from "@/lib/prepareAsset";
import { GlbTurntableViewer } from "./GlbTurntableViewer";
import { PhotoSequenceViewer } from "./PhotoSequenceViewer";
import { UploadGuidelinesPanel } from "./UploadGuidelinesPanel";

type UploadCategory = "necklace" | "earrings" | "nose_ring" | "bangles" | "finger_ring";
type UploadMode = "single" | "glb" | "photos";
type Step = "idle" | "validating" | "preview" | "uploading" | "done" | "error" | "guidelines";

const CATEGORY_LABELS: Record<UploadCategory, string> = {
  necklace: "Necklace",
  earrings: "Earrings",
  nose_ring: "Nose Ring",
  bangles: "Bangles",
  finger_ring: "Ring",
};

export const AUTO_JEWELLERY_NAMES: Record<UploadCategory, string> = {
  necklace: "Gold Necklace",
  earrings: "Gold Earrings",
  bangles: "Gold Bangle",
  finger_ring: "Gold Ring",
  nose_ring: "Gold Nose Ring",
};

/** Default anchor & scale mapping per category (AR landmark anchors) */
export const DEFAULT_ANCHOR_MAP: Record<
  UploadCategory,
  {
    anchor: { x: number; y: number };
    widthRatio: number;
    scaleFactor: number;
    necklaceAnchors?: {
      leftEnd: { x: number; y: number };
      rightEnd: { x: number; y: number };
      pendantCenter: { x: number; y: number };
      bottomCenter: { x: number; y: number };
    };
  }
> = {
  // necklace: neck, just below chin, between shoulders
  necklace: {
    anchor: { x: 0.5, y: 0.0 },
    widthRatio: 0.8,
    scaleFactor: 1.0,
    necklaceAnchors: {
      leftEnd: { x: 0.14, y: 0.04 },
      rightEnd: { x: 0.86, y: 0.04 },
      pendantCenter: { x: 0.5, y: 0.85 },
      bottomCenter: { x: 0.5, y: 0.94 },
    },
  },
  // earring: ear landmarks on the face
  earrings: {
    anchor: { x: 0.5, y: 0.08 },
    widthRatio: 0.18,
    scaleFactor: 0.14,
  },
  // finger ring: ring finger base
  finger_ring: {
    anchor: { x: 0.5, y: 0.5 },
    widthRatio: 0.22,
    scaleFactor: 0.22,
  },
  // bracelet/bangle: wrist
  bangles: {
    anchor: { x: 0.5, y: 0.5 },
    widthRatio: 0.95,
    scaleFactor: 0.95,
  },
  // nose ring: nostril
  nose_ring: {
    anchor: { x: 0.35, y: 0.5 },
    widthRatio: 0.18,
    scaleFactor: 0.08,
  },
};

/**
 * Normalize any incoming category string to a valid UploadCategory key.
 * Handles "necklaces" → "necklace", "rings" → "finger_ring", "finger ring" → "finger_ring", etc.
 */
function normalizeToUploadCategory(raw: string | undefined | null): UploadCategory {
  if (!raw) return "necklace";
  const c = raw.toLowerCase().trim().replace(/[- ]+/g, "_");
  if (c === "necklace" || c === "necklaces") return "necklace";
  if (c === "earring" || c === "earrings") return "earrings";
  if (c === "nose_ring" || c === "noserings" || c === "nosering") return "nose_ring";
  if (c === "bangles" || c === "bangle" || c === "bracelet" || c === "bracelets") return "bangles";
  if (c === "finger_ring" || c === "rings" || c === "ring") return "finger_ring";
  return "necklace"; // safe fallback
}

/**
 * Clean a filename into a readable product name.
 * Strips file extensions, UUIDs, hex IDs, underscores, hyphens, leading numbers.
 */
function cleanItemName(filename: string, category: UploadCategory): string {
  const name = filename
    // Remove file extension
    .replace(/\.[^.]+$/, "")
    // Remove UUIDs (8-4-4-4-12 hex patterns)
    .replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, "")
    // Remove long hex strings (8+ chars)
    .replace(/[0-9a-f]{8,}/gi, "")
    // Remove common prefixes like "IMG_", "DSC_", "photo_", "upload_"
    .replace(/^(IMG|DSC|DCIM|photo|upload|image|file|pic|screenshot)[_-]*/i, "")
    // Replace underscores and hyphens with spaces
    .replace(/[-_]+/g, " ")
    // Remove leading/trailing numbers and whitespace
    .replace(/^\s*\d+\s*/, "")
    .replace(/\s*\d+\s*$/, "")
    .trim();

  // If nothing meaningful remains, use a category-based name
  if (!name || name.length < 2) {
    return `Custom ${CATEGORY_LABELS[category]}`;
  }

  // Title case
  return name
    .split(" ")
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ");
}

interface ProductUploadModalProps {
  initialCategory?: LandmarkerCategory;
  onClose: () => void;
  onItemAdded?: (cat: UploadCategory, item: StoredJewelleryItem) => void;
}

export function ProductUploadModal({
  initialCategory,
  onClose,
  onItemAdded,
}: ProductUploadModalProps) {
  const { addUploadedItem, metal } = useJewelleryStore();

  // Mode defaults to Single Photo (DEFAULT)
  const [mode, setMode] = useState<UploadMode>("single");
  const [step, setStep] = useState<Step>("idle");
  const [category, setCategory] = useState<UploadCategory>(
    normalizeToUploadCategory(initialCategory as string)
  );
  const [error, setError] = useState<string | null>(null);
  const [progressMsg, setProgressMsg] = useState<string>("");

  // ── Single Photo State ──────────────────────────────────────────
  const [singleRawCanvas, setSingleRawCanvas] = useState<HTMLCanvasElement | null>(null);
  const [singleCutoutUrl, setSingleCutoutUrl] = useState<string | null>(null);
  const [singleOriginalUrl, setSingleOriginalUrl] = useState<string | null>(null);
  const [singleItemName, setSingleItemName] = useState<string>("");
  const singleInputRef = useRef<HTMLInputElement>(null);
  const [singleDragOver, setSingleDragOver] = useState(false);
  const [bgRemovalBusy, setBgRemovalBusy] = useState(false);
  const [isDetecting, setIsDetecting] = useState<boolean>(false);
  const [detectedInfo, setDetectedInfo] = useState<{
    detected: boolean;
    label: string;
    confidence: number;
  } | null>(null);
  const [preparedAsset, setPreparedAsset] = useState<PreparedAssetResult | null>(null);
  const [enhancedCutoutCanvas, setEnhancedCutoutCanvas] = useState<HTMLCanvasElement | null>(null);
  const [showDebugPreview, setShowDebugPreview] = useState(false);

  // ── GLB State ──────────────────────────────────────────────────
  const [glbFile, setGlbFile] = useState<File | null>(null);
  const [glbObjectUrl, setGlbObjectUrl] = useState<string | null>(null);
  const glbInputRef = useRef<HTMLInputElement>(null);
  const [glbDragOver, setGlbDragOver] = useState(false);

  // ── Photo Sequence State ───────────────────────────────────────
  const [photoFiles, setPhotoFiles] = useState<File[]>([]);
  const [photoUrls, setPhotoUrls] = useState<string[]>([]);
  const photoUrlCleanup = useRef<(() => void) | null>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const [photoDragOver, setPhotoDragOver] = useState(false);

  // Cleanup object URLs on unmount
  useEffect(() => {
    return () => {
      if (glbObjectUrl) URL.revokeObjectURL(glbObjectUrl);
      photoUrlCleanup.current?.();
    };
  }, [glbObjectUrl]);

  // ── Single Photo Flow (AI background removal via @imgly) ───────
  const processSingleFile = useCallback(async (file: File) => {
    setError(null);

    // Clean product name
    const formattedName = cleanItemName(file.name, category);
    setSingleItemName(formattedName);

    setStep("validating");
    setProgressMsg("Loading AI model for background removal…");
    setBgRemovalBusy(true);

    try {
      const url = URL.createObjectURL(file);
      const img = new Image();
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error("Failed to load image file."));
        img.src = url;
      });
      URL.revokeObjectURL(url);

      const rawCanvas = document.createElement("canvas");
      rawCanvas.width = img.naturalWidth;
      rawCanvas.height = img.naturalHeight;
      const ctx = rawCanvas.getContext("2d");
      if (!ctx) throw new Error("Could not initialize image canvas.");
      ctx.drawImage(img, 0, 0);
      setSingleRawCanvas(rawCanvas);

      // AI-powered background removal via @imgly/background-removal
      setProgressMsg("Removing background with AI (first run downloads model ~40 MB)…");
      const processed = await removeBackgroundAI(rawCanvas, {
        cropPadding: 10,
        upscaleSmall: true,
      });

      // Keep the uploaded source untouched as a fallback.
      setSingleOriginalUrl(rawCanvas.toDataURL("image/png"));

      // Enhance uploaded product (upscale 2x if <1024px, auto-exposure gamma 0.7, unsharp mask, specular boost, metal tint)
      const enhancedCanvas = enhanceUploadedProduct(processed, metal);
      setEnhancedCutoutCanvas(enhancedCanvas);
      const cutoutDataUrl = enhancedCanvas.toDataURL("image/png");
      setSingleCutoutUrl(cutoutDataUrl);

      // Auto-detect jewellery type from image using transformers.js
      let activeCat: UploadCategory = category;
      setIsDetecting(true);
      setProgressMsg("Detecting jewellery type…");
      try {
        const detection = await detectJewellery(enhancedCanvas);
        if (detection && detection.confidence >= 0.5) {
          const detectedCategory = normalizeToUploadCategory(detection.category);
          setCategory(detectedCategory);
          activeCat = detectedCategory;
          const autoName = AUTO_JEWELLERY_NAMES[detectedCategory] || `Gold ${CATEGORY_LABELS[detectedCategory]}`;
          setSingleItemName(autoName);
          setDetectedInfo({
            detected: true,
            label: detection.category,
            confidence: detection.confidence,
          });
        } else {
          setDetectedInfo(null);
        }
      } catch (detErr) {
        console.warn("Jewellery auto-detection failed, fallback to manual selection:", detErr);
        setDetectedInfo(null);
      } finally {
        setIsDetecting(false);
      }

      // Universal jewellery asset preparation pipeline (straighten, clean, front arc, anchors)
      setProgressMsg("Aligning & calibrating AR anchors…");
      try {
        const prep = await prepareAsset(enhancedCanvas, activeCat);
        setPreparedAsset(prep);
        setSingleCutoutUrl(prep.image);
      } catch (prepErr) {
        console.warn("[ProductUploadModal] prepareAsset error:", prepErr);
      }

      setStep("preview");
      setProgressMsg("");
    } catch (err: unknown) {
      console.error("Single photo background removal error:", err);
      setError((err as Error).message || "Background removal failed.");
      setStep("error");
    } finally {
      setBgRemovalBusy(false);
      setIsDetecting(false);
    }
  }, [category, metal]);

  // Retry background removal
  const retryBackgroundRemoval = useCallback(async () => {
    if (!singleRawCanvas) return;
    setBgRemovalBusy(true);
    setStep("validating");
    setProgressMsg("Retrying AI background removal…");
    try {
      const processed = await removeBackgroundAI(singleRawCanvas, {
        cropPadding: 10,
        upscaleSmall: true,
      });
      // Keep the uploaded source untouched as a fallback.
      setSingleOriginalUrl(singleRawCanvas.toDataURL("image/png"));

      // Enhance uploaded product
      const enhancedCanvas = enhanceUploadedProduct(processed, metal);
      setEnhancedCutoutCanvas(enhancedCanvas);
      const cutoutDataUrl = enhancedCanvas.toDataURL("image/png");
      setSingleCutoutUrl(cutoutDataUrl);

      // Re-run detection if needed
      let activeCat: UploadCategory = category;
      setIsDetecting(true);
      setProgressMsg("Detecting jewellery type…");
      try {
        const detection = await detectJewellery(enhancedCanvas);
        if (detection && detection.confidence >= 0.5) {
          const detectedCategory = normalizeToUploadCategory(detection.category);
          setCategory(detectedCategory);
          activeCat = detectedCategory;
          const autoName = AUTO_JEWELLERY_NAMES[detectedCategory] || `Gold ${CATEGORY_LABELS[detectedCategory]}`;
          setSingleItemName(autoName);
          setDetectedInfo({
            detected: true,
            label: detection.category,
            confidence: detection.confidence,
          });
        }
      } catch (detErr) {
        console.warn("Jewellery detection fallback:", detErr);
      } finally {
        setIsDetecting(false);
      }

      // Universal jewellery asset preparation pipeline
      setProgressMsg("Aligning & calibrating AR anchors…");
      try {
        const prep = await prepareAsset(enhancedCanvas, activeCat);
        setPreparedAsset(prep);
        setSingleCutoutUrl(prep.image);
      } catch (prepErr) {
        console.warn("[ProductUploadModal] prepareAsset retry error:", prepErr);
      }

      setStep("preview");
      setProgressMsg("");
    } catch (err: unknown) {
      console.error("Retry background removal error:", err);
      setError((err as Error).message || "Background removal retry failed.");
      setStep("error");
    } finally {
      setBgRemovalBusy(false);
      setIsDetecting(false);
    }
  }, [singleRawCanvas, metal, category]);

  const handleSingleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setSingleDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processSingleFile(file);
  };

  const handleSingleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processSingleFile(file);
  };

  // ── GLB Flow ────────────────────────────────────────────────────
  const processGlbFile = useCallback(async (file: File) => {
    setError(null);
    setStep("validating");
    setProgressMsg("Validating file…");

    const result = await validateGlbFile(file);
    if (!result.valid) {
      setError(result.error || "Invalid file.");
      setStep("error");
      return;
    }

    setProgressMsg("Uploading to server for validation…");
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("type", "glb");
      formData.append("category", category);

      const res = await fetch("/api/upload-product", { method: "POST", body: formData });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `Server error ${res.status}`);
      }
    } catch (e) {
      setError(`Server rejected file: ${(e as Error).message}`);
      setStep("error");
      return;
    }

    const url = URL.createObjectURL(file);
    if (glbObjectUrl) URL.revokeObjectURL(glbObjectUrl);
    setGlbFile(file);
    setGlbObjectUrl(url);
    setStep("preview");
    setProgressMsg("");
  }, [category, glbObjectUrl]);

  const handleGlbDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setGlbDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processGlbFile(file);
  };

  const handleGlbInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processGlbFile(file);
  };

  // ── Photo Sequence Flow ─────────────────────────────────────────
  const addPhotoFiles = useCallback((newFiles: File[]) => {
    setError(null);
    setPhotoFiles((prev) => {
      const existingNames = new Set(prev.map((f) => f.name));
      const unique = newFiles.filter((f) => !existingNames.has(f.name));
      return [...prev, ...unique];
    });
  }, []);

  const handlePhotoDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setPhotoDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) addPhotoFiles(files);
  };

  const handlePhotoInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) addPhotoFiles(files);
  };

  const startPhotoSequencePreview = useCallback(async () => {
    if (photoFiles.length < 24) return;
    setError(null);
    setStep("validating");
    setProgressMsg(`Validating ${photoFiles.length} images…`);

    const result = await validatePhotoSequence(photoFiles);
    if (!result.valid || !result.sortedFiles) {
      setError(result.error || "Invalid photo sequence.");
      setStep("error");
      return;
    }

    const sorted = result.sortedFiles;
    setProgressMsg("Preloading all frames…");
    photoUrlCleanup.current?.();

    const { urls, cleanup } = await preloadPhotoSequence(sorted, (loaded, total) => {
      setProgressMsg(`Preloading frames… ${loaded}/${total}`);
    });

    photoUrlCleanup.current = cleanup;
    setPhotoUrls(urls);
    setStep("preview");
    setProgressMsg("");
  }, [photoFiles]);

  // ── Confirm / Add to catalog ────────────────────────────────────
  const handleConfirm = useCallback(async () => {
    setStep("uploading");
    setProgressMsg("Saving to catalog…");

    const itemId = `upload_${Date.now()}`;
    const itemName =
      mode === "single"
        ? singleItemName || `Custom ${CATEGORY_LABELS[category]}`
        : mode === "glb"
        ? cleanItemName(glbFile?.name || "custom", category)
        : "360° Photo Product";

    // Safe lookup: normalize category and fallback to category-specific AR anchor defaults
    const safeCategory = normalizeToUploadCategory(category);
    const defaults = DEFAULT_ANCHOR_MAP[safeCategory] || DEFAULT_ANCHOR_MAP.necklace;

    const finalAnchor = preparedAsset?.anchor || defaults.anchor || { x: 0.5, y: 0.0 };
    const finalNecklaceAnchors = safeCategory === "necklace"
      ? (preparedAsset?.necklaceAnchors || defaults.necklaceAnchors || {
          leftEnd: { x: 0.14, y: 0.04 },
          rightEnd: { x: 0.86, y: 0.04 },
          pendantCenter: { x: 0.5, y: 0.85 },
          bottomCenter: { x: 0.5, y: 0.94 },
        })
      : undefined;

    const newItem: StoredJewelleryItem = {
      id: itemId,
      name: itemName,
      category: safeCategory,
      price: "Bespoke",
      src: mode === "single" ? (preparedAsset?.image || singleCutoutUrl || "") : mode === "photos" && photoUrls[0] ? photoUrls[0] : "",
      originalSrc: mode === "single" ? singleOriginalUrl || undefined : undefined,
      modelUrl: mode === "glb" ? glbObjectUrl || undefined : undefined,
      type: mode === "glb" ? "glb" : mode === "photos" ? "photo_sequence" : "2d",
      anchor: finalAnchor,
      necklaceAnchors: finalNecklaceAnchors,
      uprightAngle: 0,
      widthRatio: preparedAsset?.widthRatio ?? defaults.widthRatio ?? 0.8,
      scaleFactor: preparedAsset?.scaleFactor ?? defaults.scaleFactor ?? 1.0,
      aspect: preparedAsset?.aspect,
      setPieces: preparedAsset?.setPieces as Record<string, unknown> | undefined,
      meta: preparedAsset?.meta as Record<string, unknown> | undefined,
      createdAt: Date.now(),
    };

    await addUploadedItem(newItem);
    onItemAdded?.(safeCategory, newItem);
    setStep("done");
    setProgressMsg("");

    setTimeout(() => onClose(), 1100);
  }, [
    mode,
    singleItemName,
    singleCutoutUrl,
    glbFile,
    glbObjectUrl,
    photoUrls,
    singleOriginalUrl,
    category,
    preparedAsset,
    addUploadedItem,
    onItemAdded,
    onClose,
  ]);

  const reset = () => {
    setStep("idle");
    setError(null);
    setSingleRawCanvas(null);
    setSingleCutoutUrl(null);
    setPreparedAsset(null);
    setEnhancedCutoutCanvas(null);
    setShowDebugPreview(false);
    setSingleItemName("");
    setIsDetecting(false);
    setDetectedInfo(null);
    setGlbFile(null);
    if (glbObjectUrl) {
      URL.revokeObjectURL(glbObjectUrl);
      setGlbObjectUrl(null);
    }
    photoUrlCleanup.current?.();
    photoUrlCleanup.current = null;
    setPhotoFiles([]);
    setPhotoUrls([]);
  };

  const switchMode = (newMode: UploadMode) => {
    if (newMode === mode) return;
    reset();
    setMode(newMode);
  };

  // ── Render: Single Photo Mode ───────────────────────────────────
  const renderSinglePhotoUpload = () => (
    <div className="flex flex-col gap-4">
      {step === "idle" && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setSingleDragOver(true);
          }}
          onDragLeave={() => setSingleDragOver(false)}
          onDrop={handleSingleDrop}
          onClick={() => singleInputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center gap-4 cursor-pointer transition-all text-center ${
            singleDragOver
              ? "border-[#D4AF37] bg-[#D4AF37]/10 scale-[1.01]"
              : "border-[#D4AF37]/35 hover:border-[#D4AF37]/70 bg-[#D4AF37]/5 hover:bg-[#D4AF37]/8"
          }`}
        >
          <input
            ref={singleInputRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp"
            onChange={handleSingleInput}
            className="hidden"
          />
          <div className="w-16 h-16 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 flex items-center justify-center">
            <Camera className="w-8 h-8 text-[#D4AF37]" />
          </div>
          <div>
            <p className="text-base font-bold text-white mb-1">
              Drop 1 photo here or click to browse
            </p>
            <p className="text-xs text-neutral-400">
              AI-powered background removal (keeps fine chains &amp; diamond links)
            </p>
          </div>
          <div className="text-[11px] text-neutral-500 space-y-0.5">
            <p>✓ JPG, PNG, or WebP</p>
            <p>✓ White or solid studio background recommended</p>
            <p>✓ Instant AR try-on for {CATEGORY_LABELS[category]}</p>
          </div>
        </div>
      )}

      {step === "validating" && (
        <div className="py-12 flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 text-[#D4AF37] animate-spin" />
          <p className="text-sm font-medium text-white">{progressMsg}</p>
          <p className="text-[11px] text-neutral-500">This may take 10–30 s on first run</p>
        </div>
      )}

      {step === "preview" && singleCutoutUrl && (
        <div className="flex flex-col gap-4">
          <div className="relative w-full h-64 rounded-2xl border border-white/10 overflow-hidden bg-[radial-gradient(#252528_1px,transparent_1px)] [background-size:14px_14px] bg-[#0c0c0e] flex items-center justify-center p-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={showDebugPreview && preparedAsset?.meta?.debugPreviewUrl ? preparedAsset.meta.debugPreviewUrl : singleCutoutUrl}
              alt="Cutout Preview"
              className="max-h-full max-w-full object-contain drop-shadow-[0_12px_24px_rgba(0,0,0,0.8)]"
            />
            <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur border border-white/10 text-[10px] text-emerald-300 font-semibold flex items-center gap-1.5">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              {showDebugPreview ? "Calibration Inspection" : "AR Prepared & Anchored"}
            </div>
            {preparedAsset?.meta?.debugPreviewUrl && (
              <button
                type="button"
                onClick={() => setShowDebugPreview(!showDebugPreview)}
                className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur border border-[#D4AF37]/40 text-[10px] text-[#D4AF37] hover:bg-[#D4AF37]/20 transition font-semibold flex items-center gap-1"
              >
                <BookOpen className="w-3 h-3" />
                {showDebugPreview ? "Show Cutout" : "Inspect Alignment"}
              </button>
            )}
          </div>

          {/* Auto-detection status */}
          {isDetecting && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/25 text-[#D4AF37] text-xs animate-pulse">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-[#D4AF37]" />
              <span>Detecting jewellery type…</span>
            </div>
          )}

          {detectedInfo?.detected && (
            <div className="flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-emerald-300 text-xs">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  Auto-detected: <strong>{CATEGORY_LABELS[category]}</strong> ({Math.round(detectedInfo.confidence * 100)}% match)
                </span>
              </div>
              <span className="text-[10px] text-neutral-400">Change below if needed</span>
            </div>
          )}

          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-neutral-300">
              Piece Name
            </label>
            <input
              type="text"
              value={singleItemName}
              onChange={(e) => setSingleItemName(e.target.value)}
              placeholder={`Custom ${CATEGORY_LABELS[category]}`}
              className="px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:border-[#D4AF37] focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              onClick={retryBackgroundRemoval}
              disabled={bgRemovalBusy}
              className="px-4 py-2.5 rounded-xl border border-amber-500/30 text-amber-300 hover:text-amber-200 hover:bg-amber-500/10 text-xs font-medium transition flex items-center gap-1.5 disabled:opacity-40"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${bgRemovalBusy ? "animate-spin" : ""}`} />
              Retry BG Removal
            </button>
            <button
              onClick={reset}
              className="px-4 py-2.5 rounded-xl border border-white/10 text-neutral-300 hover:text-white hover:bg-white/5 text-xs font-medium transition"
            >
              Choose Another
            </button>
            <button
              id="confirm-single-upload-btn"
              onClick={handleConfirm}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#F5E1A4] via-[#E5C158] to-[#D4AF37] hover:brightness-110 text-neutral-950 font-bold text-xs shadow-lg shadow-[#D4AF37]/20 flex items-center gap-2 transition"
            >
              <Sparkles className="w-4 h-4" />
              Add to Catalog &amp; Try On
            </button>
          </div>
        </div>
      )}

      {step === "uploading" && (
        <div className="py-12 flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 text-[#D4AF37] animate-spin" />
          <p className="text-sm font-medium text-white">{progressMsg}</p>
        </div>
      )}

      {step === "done" && (
        <div className="py-12 flex flex-col items-center gap-3">
          <CheckCircle2 className="w-10 h-10 text-emerald-400" />
          <p className="text-sm font-bold text-white">Added to Catalog!</p>
          <p className="text-xs text-neutral-400">Opening your piece in AR…</p>
        </div>
      )}
    </div>
  );

  // ── Render: GLB Mode ────────────────────────────────────────────
  const renderGlbUpload = () => (
    <div className="flex flex-col gap-4">
      {step === "idle" && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setGlbDragOver(true);
          }}
          onDragLeave={() => setGlbDragOver(false)}
          onDrop={handleGlbDrop}
          onClick={() => glbInputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center gap-4 cursor-pointer transition-all text-center ${
            glbDragOver
              ? "border-amber-400 bg-amber-500/10 scale-[1.01]"
              : "border-amber-500/30 hover:border-amber-400/60 bg-amber-500/5 hover:bg-amber-500/8"
          }`}
        >
          <input
            ref={glbInputRef}
            type="file"
            accept=".glb,.gltf"
            onChange={handleGlbInput}
            className="hidden"
          />
          <div className="w-16 h-16 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center">
            <Box className="w-8 h-8 text-amber-400" />
          </div>
          <div>
            <p className="text-base font-bold text-white mb-1">
              Drag &amp; Drop your GLB file here
            </p>
            <p className="text-xs text-zinc-400">
              or <span className="text-amber-300 underline">click to browse</span>
            </p>
          </div>
          <div className="text-[11px] text-zinc-500 space-y-0.5">
            <p>✓ .glb (preferred) or .gltf with embedded textures</p>
            <p>✓ Maximum 20 MB</p>
            <p>✓ Centered model, real-world scale</p>
          </div>
        </div>
      )}

      {(step === "validating" || step === "uploading") && (
        <div className="py-12 flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 text-amber-400 animate-spin" />
          <p className="text-sm font-medium text-white">{progressMsg}</p>
        </div>
      )}

      {step === "preview" && glbObjectUrl && (
        <GlbTurntableViewer
          glbUrl={glbObjectUrl}
          modelName={glbFile?.name?.replace(/\.[^.]+$/, "") || "Custom Model"}
          onClose={reset}
          onConfirm={handleConfirm}
        />
      )}

      {step === "done" && (
        <div className="py-12 flex flex-col items-center gap-3">
          <CheckCircle2 className="w-10 h-10 text-emerald-400" />
          <p className="text-sm font-bold text-white">Added to Catalog!</p>
          <p className="text-xs text-zinc-400">Closing…</p>
        </div>
      )}
    </div>
  );

  // ── Render: Photo Sequence Mode ─────────────────────────────────
  const photoCount = photoFiles.length;
  const minPhotos = 24;
  const progressPct = Math.min(100, Math.round((photoCount / minPhotos) * 100));
  const hasMetMin = photoCount >= minPhotos;

  const renderPhotoUpload = () => (
    <div className="flex flex-col gap-4">
      {step === "idle" && (
        <div className="flex flex-col gap-4">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setPhotoDragOver(true);
            }}
            onDragLeave={() => setPhotoDragOver(false)}
            onDrop={handlePhotoDrop}
            onClick={() => photoInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-7 flex flex-col items-center gap-3 cursor-pointer transition-all text-center ${
              photoDragOver
                ? "border-sky-400 bg-sky-500/10 scale-[1.01]"
                : "border-sky-500/30 hover:border-sky-400/60 bg-sky-500/5 hover:bg-sky-500/8"
            }`}
          >
            <input
              ref={photoInputRef}
              type="file"
              accept="image/jpeg,image/jpg,image/png,image/webp"
              multiple
              onChange={handlePhotoInput}
              className="hidden"
            />
            <div className="w-14 h-14 rounded-2xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center">
              <Images className="w-7 h-7 text-sky-400" />
            </div>
            <div>
              <p className="text-sm font-bold text-white mb-0.5">
                Drag &amp; Drop photos or click to add files
              </p>
              <p className="text-xs text-neutral-400">
                You can add photos in batches before submitting
              </p>
            </div>
            <div className="text-[11px] text-zinc-500">
              <p>24–36 images taken in a circle around the piece</p>
            </div>
          </div>

          {/* Live Counter & Progress Bar */}
          <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col gap-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-white flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-sky-400" />
                Photos Selected:
              </span>
              <span className={`font-mono font-bold ${hasMetMin ? "text-emerald-400" : "text-sky-300"}`}>
                {photoCount} / {minPhotos} minimum
              </span>
            </div>

            {/* Visual Progress Bar */}
            <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  hasMetMin
                    ? "bg-gradient-to-r from-emerald-500 to-emerald-400"
                    : "bg-gradient-to-r from-sky-500 to-sky-400"
                }`}
                style={{ width: `${progressPct}%` }}
              />
            </div>

            {/* Status hint or single photo fallback */}
            {!hasMetMin ? (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1">
                <p className="text-xs text-neutral-400">
                  {photoCount === 0
                    ? `Upload at least ${minPhotos} images for a 360° turntable`
                    : `Add ${minPhotos - photoCount} more photo${
                        minPhotos - photoCount === 1 ? "" : "s"
                      } to unlock 360° submission`}
                </p>
                <button
                  onClick={() => {
                    setMode("single");
                    if (photoFiles.length > 0) {
                      processSingleFile(photoFiles[0]);
                    }
                  }}
                  className="text-xs text-[#D4AF37] hover:text-[#F5E1A4] underline font-medium whitespace-nowrap self-start sm:self-auto"
                >
                  Use single photo instead →
                </button>
              </div>
            ) : (
              <p className="text-xs text-emerald-400 flex items-center gap-1 pt-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Minimum requirement met! You can now generate the 360° turntable.
              </p>
            )}

            {/* Action buttons */}
            <div className="flex items-center justify-between pt-2 border-t border-white/5">
              <button
                onClick={() => setPhotoFiles([])}
                disabled={photoCount === 0}
                className="text-xs text-neutral-500 hover:text-red-400 disabled:opacity-30 disabled:hover:text-neutral-500 transition flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => photoInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-lg border border-white/10 text-xs text-neutral-300 hover:text-white hover:bg-white/5 transition flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add More Photos
                </button>

                <button
                  id="submit-photo-sequence-btn"
                  onClick={startPhotoSequencePreview}
                  disabled={!hasMetMin}
                  className={`px-4 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    hasMetMin
                      ? "bg-gradient-to-r from-sky-400 to-sky-500 text-neutral-950 hover:brightness-110 shadow-md shadow-sky-500/20 cursor-pointer"
                      : "bg-white/5 text-neutral-500 border border-white/5 cursor-not-allowed"
                  }`}
                >
                  Generate 360° Preview
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {step === "validating" && (
        <div className="py-12 flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 text-sky-400 animate-spin" />
          <p className="text-sm font-medium text-white">{progressMsg}</p>
        </div>
      )}

      {step === "preview" && photoUrls.length > 0 && (
        <PhotoSequenceViewer
          frameUrls={photoUrls}
          onClose={reset}
          onConfirm={handleConfirm}
        />
      )}

      {step === "uploading" && (
        <div className="py-12 flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 text-sky-400 animate-spin" />
          <p className="text-sm font-medium text-white">Saving to catalog…</p>
        </div>
      )}

      {step === "done" && (
        <div className="py-12 flex flex-col items-center gap-3">
          <CheckCircle2 className="w-10 h-10 text-emerald-400" />
          <p className="text-sm font-bold text-white">Added to Catalog!</p>
          <p className="text-xs text-zinc-400">Closing…</p>
        </div>
      )}
    </div>
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/88 backdrop-blur-md"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.2, ease: "easeOut" }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-[580px] max-h-[92vh] overflow-y-auto overflow-x-hidden bg-gradient-to-b from-[#18181b] via-[#101012] to-[#09090b] rounded-3xl border border-[#D4AF37]/30 shadow-2xl shadow-black/90 flex flex-col"
        style={{ scrollbarWidth: "none" }}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 pt-5 pb-3 border-b border-white/5 bg-[#18181b]/95 backdrop-blur-xl rounded-t-3xl">
          <div>
            <span className="text-[10px] font-semibold tracking-widest text-[#D4AF37] uppercase">
              {step === "guidelines" ? "Upload Requirements" : "Bespoke Upload Studio"}
            </span>
            <h2 className="text-xl font-bold text-white font-serif tracking-wide">
              {step === "guidelines"
                ? "Guidelines & Checklist"
                : mode === "single"
                ? "Single Photo Upload"
                : mode === "glb"
                ? "3D Model Upload (.GLB)"
                : "Photo Sequence Upload (360°)"}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {step !== "guidelines" && (
              <button
                onClick={() => setStep("guidelines")}
                title="View upload guidelines"
                className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-amber-300 transition"
              >
                <Info className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 text-white/60 hover:text-white flex items-center justify-center transition border border-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-6 flex flex-col gap-5">
          {/* ── 3 Mode Switcher Tabs ── */}
          {step !== "done" && step !== "guidelines" && step !== "uploading" && (
            <div className="grid grid-cols-3 gap-2 p-1.5 rounded-2xl bg-black/40 border border-white/10">
              {/* Option A: Single Photo (DEFAULT) */}
              <button
                id="tab-single-photo"
                onClick={() => switchMode("single")}
                className={`py-2 px-2.5 rounded-xl text-center flex flex-col items-center gap-1 transition ${
                  mode === "single"
                    ? "bg-[#D4AF37] text-neutral-950 font-bold shadow-md shadow-[#D4AF37]/20"
                    : "text-neutral-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Single Photo</span>
                </div>
                <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-semibold ${
                  mode === "single" ? "bg-black/20 text-neutral-900" : "bg-[#D4AF37]/20 text-[#D4AF37]"
                }`}>
                  Default / Instant
                </span>
              </button>

              {/* Option B: GLB / 3D Model */}
              <button
                id="tab-glb-model"
                onClick={() => switchMode("glb")}
                className={`py-2 px-2.5 rounded-xl text-center flex flex-col items-center gap-1 transition ${
                  mode === "glb"
                    ? "bg-amber-400 text-neutral-950 font-bold shadow-md shadow-amber-400/20"
                    : "text-neutral-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs">
                  <Box className="w-3.5 h-3.5" />
                  <span>GLB / 3D Model</span>
                </div>
                <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-semibold ${
                  mode === "glb" ? "bg-black/20 text-neutral-900" : "bg-white/10 text-neutral-400"
                }`}>
                  Full 3D
                </span>
              </button>

              {/* Option C: Photo Sequence (360) */}
              <button
                id="tab-photo-sequence"
                onClick={() => switchMode("photos")}
                className={`py-2 px-2.5 rounded-xl text-center flex flex-col items-center gap-1 transition ${
                  mode === "photos"
                    ? "bg-sky-400 text-neutral-950 font-bold shadow-md shadow-sky-400/20"
                    : "text-neutral-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs">
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Photo Sequence</span>
                </div>
                <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-semibold ${
                  mode === "photos" ? "bg-black/20 text-neutral-900" : "bg-white/10 text-neutral-400"
                }`}>
                  24–36 Images
                </span>
              </button>
            </div>
          )}

          {/* Category selector */}
          {step !== "done" && step !== "guidelines" && step !== "uploading" && (
            <div>
              {detectedInfo?.detected && (
                <div className="mb-2 flex items-center justify-between px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs">
                  <span className="flex items-center gap-1.5 font-medium">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    Auto-detected: {CATEGORY_LABELS[category]} ({Math.round(detectedInfo.confidence * 100)}% match)
                  </span>
                  <span className="text-[10px] text-neutral-400">Click any below to change</span>
                </div>
              )}
              {isDetecting && (
                <div className="mb-2 flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/20 text-[#D4AF37] text-xs">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-[#D4AF37]" />
                  <span>Detecting jewellery type...</span>
                </div>
              )}
              <div className="flex items-center justify-between mb-2">
                <label className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold block">
                  Piece Category {detectedInfo?.detected && <span className="text-emerald-400 font-normal normal-case">(auto-selected)</span>}
                </label>
                {detectedInfo?.detected && (
                  <span className="text-[10px] text-emerald-400/90 font-medium">Confidence &ge; 50%</span>
                )}
              </div>
              <div className="grid grid-cols-5 gap-1.5">
                {(Object.keys(CATEGORY_LABELS) as UploadCategory[]).map((cat) => (
                  <button
                    key={cat}
                    onClick={async () => {
                      setCategory(cat);
                      if (mode === "single" && (!singleItemName || Object.values(AUTO_JEWELLERY_NAMES).includes(singleItemName))) {
                        setSingleItemName(AUTO_JEWELLERY_NAMES[cat]);
                      }
                      if (enhancedCutoutCanvas) {
                        try {
                          const prep = await prepareAsset(enhancedCutoutCanvas, cat);
                          setPreparedAsset(prep);
                          setSingleCutoutUrl(prep.image);
                        } catch (err) {
                          console.warn("[ProductUploadModal] Re-prep on category switch error:", err);
                        }
                      }
                    }}
                    className={`py-2 px-1 rounded-xl text-center text-xs font-semibold transition border ${
                      category === cat
                        ? "bg-[#D4AF37] text-neutral-950 border-[#D4AF37] shadow-md shadow-[#D4AF37]/20"
                        : "bg-white/5 text-neutral-400 border-white/5 hover:border-white/20 hover:text-white"
                    }`}
                  >
                    {CATEGORY_LABELS[cat].split(" ")[0]}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Error display */}
          <AnimatePresence>
            {(step === "error" || error) && error && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex gap-3 p-4 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200"
              >
                <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold mb-0.5">Upload Error</p>
                  <p className="text-xs leading-relaxed">{error}</p>
                  <button
                    onClick={() => {
                      setError(null);
                      setStep("idle");
                    }}
                    className="mt-2 text-xs underline text-red-300 hover:text-white transition"
                  >
                    Try again
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Main content */}
          <AnimatePresence mode="wait">
            {step === "guidelines" ? (
              <motion.div
                key="guidelines"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <UploadGuidelinesPanel />
                <button
                  onClick={() => setStep("idle")}
                  className="mt-4 text-xs text-zinc-400 hover:text-white transition flex items-center gap-1"
                >
                  ← Back to upload
                </button>
              </motion.div>
            ) : mode === "single" ? (
              <motion.div key="single" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                {renderSinglePhotoUpload()}
              </motion.div>
            ) : mode === "glb" ? (
              <motion.div key="glb" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                {renderGlbUpload()}
              </motion.div>
            ) : (
              <motion.div key="photos" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                {renderPhotoUpload()}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
