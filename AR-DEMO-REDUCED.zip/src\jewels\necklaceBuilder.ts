import * as THREE from 'three';
import { JewelConfig } from './types';
import { createJewelMaterials, createBrilliantGemGeometry, createStepCutGemGeometry } from './materials';

/**
 * Creates a CatmullRomCurve3 representing a natural 3D neckline contour.
 * Starts near left clavicle/shoulder, dips down to sternum, returns to right clavicle.
 * Scale: 1 unit = 1 cm.
 */
function createNecklineCurve(dropY = 8.5, widthX = 14.0, depthZ = 3.5): THREE.CatmullRomCurve3 {
  const points = [
    new THREE.Vector3(-widthX * 0.48, 1.5, -depthZ * 0.9), // Left back of neck
    new THREE.Vector3(-widthX * 0.42, 0.0, -depthZ * 0.2), // Left clavicle
    new THREE.Vector3(-widthX * 0.25, -dropY * 0.55, depthZ * 0.6), // Left chest slope
    new THREE.Vector3(0, -dropY, depthZ * 0.9), // Sternum (lowest point)
    new THREE.Vector3(widthX * 0.25, -dropY * 0.55, depthZ * 0.6), // Right chest slope
    new THREE.Vector3(widthX * 0.42, 0.0, -depthZ * 0.2), // Right clavicle
    new THREE.Vector3(widthX * 0.48, 1.5, -depthZ * 0.9), // Right back of neck
  ];
  return new THREE.CatmullRomCurve3(points);
}

/**
 * Builds one of 10 distinct, richly detailed 3D necklaces with linked chain segments and pendants.
 * NOT a flat plane or slab!
 */
export function buildNecklace(config: JewelConfig): THREE.Group {
  const group = new THREE.Group();
  group.name = `necklace_${config.id}`;

  const { metalMat, diamondMat, rubyMat, emeraldMat, sapphireMat, pearlMat } =
    createJewelMaterials(config.metalTone);

  switch (config.style) {
    case 'solitaire_pendant': {
      // Delicate curb chain with floating diamond solitaire pendant
      const curve = createNecklineCurve(8.5, 14.0, 3.2);
      const linkCount = 70;
      const linkGeom = new THREE.TorusGeometry(0.12, 0.035, 8, 16);
      const instancedMesh = new THREE.InstancedMesh(linkGeom, metalMat, linkCount);

      const dummy = new THREE.Object3D();
      for (let i = 0; i < linkCount; i++) {
        const t = i / (linkCount - 1);
        const pt = curve.getPointAt(t);
        const tangent = curve.getTangentAt(t);
        dummy.position.copy(pt);
        dummy.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), tangent);
        dummy.rotateZ((i % 2) * (Math.PI / 2));
        dummy.updateMatrix();
        instancedMesh.setMatrixAt(i, dummy.matrix);
      }
      instancedMesh.instanceMatrix.needsUpdate = true;
      group.add(instancedMesh);

      // Pendant group hanging at lowest point (t = 0.5)
      const sternumPt = curve.getPointAt(0.5);
      const pendant = new THREE.Group();
      pendant.position.copy(sternumPt);

      // Bail
      const bail = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.04, 8, 16), metalMat);
      bail.position.set(0, 0.1, 0);
      pendant.add(bail);

      // Collet & prongs
      const collet = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.28, 0.3, 16), metalMat);
      collet.position.set(0, -0.32, 0);
      pendant.add(collet);

      for (let i = 0; i < 6; i++) {
        const a = (i * Math.PI * 2) / 6;
        const prong = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.35, 6), metalMat);
        prong.position.set(Math.cos(a) * 0.42, -0.22, Math.sin(a) * 0.42);
        pendant.add(prong);
      }

      // Solitaire Diamond
      const gem = new THREE.Mesh(createBrilliantGemGeometry(0.55), diamondMat);
      gem.position.set(0, -0.22, 0.1);
      pendant.add(gem);

      group.add(pendant);
      break;
    }

    case 'diamond_riviere': {
      // Continuous line of graduated prong-set brilliant diamonds
      const curve = createNecklineCurve(7.8, 13.5, 3.0);
      const stoneCount = 45;

      for (let i = 0; i < stoneCount; i++) {
        const t = i / (stoneCount - 1);
        const pt = curve.getPointAt(t);
        const tangent = curve.getTangentAt(t);

        // Center stones are larger (0.35 cm), tapering to 0.18 cm at ends
        const centerDist = Math.abs(t - 0.5) * 2; // 0 at center, 1 at ends
        const size = 0.35 * (1.0 - centerDist * 0.45);

        const gem = new THREE.Mesh(createBrilliantGemGeometry(size), diamondMat);
        gem.position.copy(pt);
        gem.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), tangent);
        group.add(gem);

        // Bezel cup under each diamond
        const cup = new THREE.Mesh(new THREE.CylinderGeometry(size * 1.05, size * 0.7, 0.14, 12), metalMat);
        cup.position.copy(pt);
        cup.position.z -= 0.08;
        cup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), tangent);
        group.add(cup);
      }
      break;
    }

    case 'choker_stones': {
      // Close collar choker studded with alternating rubies and pearls
      const curve = createNecklineCurve(5.2, 12.8, 2.8);
      const segmentCount = 38;

      // Solid articulated gold band
      const bandGeom = new THREE.TubeGeometry(curve, 64, 0.28, 8, false);
      const band = new THREE.Mesh(bandGeom, metalMat);
      group.add(band);

      for (let i = 1; i < segmentCount - 1; i++) {
        const t = i / (segmentCount - 1);
        const pt = curve.getPointAt(t);
        const normal = new THREE.Vector3(0, 0, 1);

        if (i % 2 === 0) {
          const ruby = new THREE.Mesh(createBrilliantGemGeometry(0.24), rubyMat);
          ruby.position.copy(pt).addScaledVector(normal, 0.2);
          group.add(ruby);
        } else {
          const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.25, 14, 14), pearlMat);
          pearl.position.copy(pt).addScaledVector(normal, 0.2);
          group.add(pearl);
        }
      }
      break;
    }

    case 'temple_haram': {
      // Long traditional South Indian temple necklace with Lakshmi medallion
      const curve = createNecklineCurve(14.5, 15.5, 4.2);
      const chainGeom = new THREE.TubeGeometry(curve, 80, 0.22, 8, false);
      group.add(new THREE.Mesh(chainGeom, metalMat));

      // Mango / paisley motifs along lower half of chain
      for (let i = 20; i <= 60; i += 3) {
        const t = i / 80;
        const pt = curve.getPointAt(t);
        const motif = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.55, 8), metalMat);
        motif.position.copy(pt);
        motif.rotation.z = Math.PI;
        group.add(motif);

        const ruby = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), rubyMat);
        ruby.position.copy(pt);
        ruby.position.z += 0.12;
        group.add(ruby);
      }

      // Grand Lakshmi medallion at bottom
      const sternumPt = curve.getPointAt(0.5);
      const medallion = new THREE.Group();
      medallion.position.copy(sternumPt);

      const disc = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 0.18, 32), metalMat);
      disc.rotation.x = Math.PI / 2;
      medallion.add(disc);

      const rubyCenter = new THREE.Mesh(createBrilliantGemGeometry(0.42), rubyMat);
      rubyCenter.position.set(0, 0, 0.15);
      medallion.add(rubyCenter);

      // Pearl fringe bells on bottom of medallion
      for (let j = -3; j <= 3; j++) {
        const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 12), pearlMat);
        pearl.position.set(j * 0.38, -1.9, 0);
        medallion.add(pearl);
      }
      group.add(medallion);
      break;
    }

    case 'layered_chains': {
      // 3 cascading gold chains with coin charms
      const drops = [5.5, 8.5, 12.0];
      drops.forEach((d, layerIdx) => {
        const curve = createNecklineCurve(d, 13.0 + layerIdx * 1.2, 2.8 + layerIdx * 0.4);
        const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 60, 0.08 + layerIdx * 0.02, 6, false), metalMat);
        group.add(tube);

        // Hanging gold coin medallion at lowest point of each tier
        const pt = curve.getPointAt(0.5);
        const coin = new THREE.Mesh(new THREE.CylinderGeometry(0.45 + layerIdx * 0.15, 0.45 + layerIdx * 0.15, 0.06, 20), metalMat);
        coin.position.copy(pt);
        coin.position.y -= 0.3;
        coin.rotation.x = Math.PI / 2;
        group.add(coin);
      });
      break;
    }

    case 'pearl_strand': {
      // Classic single strand of 48 hand-knotted South Sea pearls
      const curve = createNecklineCurve(8.0, 13.8, 3.2);
      const pearlCount = 48;
      for (let i = 0; i < pearlCount; i++) {
        const t = i / (pearlCount - 1);
        const pt = curve.getPointAt(t);
        const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.38, 20, 20), pearlMat);
        pearl.position.copy(pt);
        group.add(pearl);
      }
      break;
    }

    case 'beaded_mala': {
      // Green emerald cabochon beads alternating with fluted gold beads + pendant
      const curve = createNecklineCurve(10.5, 14.5, 3.6);
      const beadCount = 46;
      for (let i = 0; i < beadCount; i++) {
        const t = i / (beadCount - 1);
        const pt = curve.getPointAt(t);
        if (i % 2 === 0) {
          const emeraldBead = new THREE.Mesh(new THREE.SphereGeometry(0.32, 16, 16), emeraldMat);
          emeraldBead.position.copy(pt);
          group.add(emeraldBead);
        } else {
          const goldBead = new THREE.Mesh(new THREE.SphereGeometry(0.24, 12, 12), metalMat);
          goldBead.position.copy(pt);
          group.add(goldBead);
        }
      }

      // Emerald carved pendant
      const sternumPt = curve.getPointAt(0.5);
      const emPendant = new THREE.Mesh(createStepCutGemGeometry(1.2, 1.6, 0.4), emeraldMat);
      emPendant.position.copy(sternumPt);
      emPendant.position.y -= 0.9;
      group.add(emPendant);
      break;
    }

    case 'rope_chain_pendant': {
      // Twisted Singapore rope chain featuring a pear sapphire medallion
      const curve = createNecklineCurve(9.0, 14.0, 3.4);
      const rope = new THREE.Mesh(new THREE.TubeGeometry(curve, 72, 0.16, 8, false), metalMat);
      group.add(rope);

      const sternumPt = curve.getPointAt(0.5);
      const pendant = new THREE.Group();
      pendant.position.copy(sternumPt);

      const halo = new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.08, 12, 32), metalMat);
      halo.position.set(0, -0.6, 0);
      pendant.add(halo);

      const sapphire = new THREE.Mesh(createBrilliantGemGeometry(0.6), sapphireMat);
      sapphire.position.set(0, -0.6, 0.05);
      pendant.add(sapphire);

      group.add(pendant);
      break;
    }

    case 'kundan_collar': {
      // Regal polki kundan collar with hanging emerald bead tassels
      const curve = createNecklineCurve(6.0, 13.0, 2.9);
      const plaqueCount = 20;
      for (let i = 1; i < plaqueCount - 1; i++) {
        const t = i / (plaqueCount - 1);
        const pt = curve.getPointAt(t);
        const tangent = curve.getTangentAt(t);

        // Gold square foil plaque
        const plaque = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 0.14), metalMat);
        plaque.position.copy(pt);
        plaque.quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), tangent);
        group.add(plaque);

        // Uncut polki diamond in center
        const polki = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.08, 8), diamondMat);
        polki.position.copy(pt);
        polki.position.z += 0.1;
        group.add(polki);

        // Hanging emerald drop tassel below plaque
        const emDrop = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), emeraldMat);
        emDrop.position.copy(pt);
        emDrop.position.y -= 0.55;
        group.add(emDrop);
      }
      break;
    }

    case 'bib_statement':
    default: {
      // Art Deco geometric chevron bib collar with tiered gold plaques and diamonds
      const curve = createNecklineCurve(7.0, 13.2, 3.0);
      const bibGroup = new THREE.Group();

      const chevronCount = 14;
      for (let i = 0; i < chevronCount; i++) {
        const t = (i + 1) / (chevronCount + 1);
        const pt = curve.getPointAt(t);
        const centerDist = 1.0 - Math.abs(t - 0.5) * 2; // Longest at center

        const chevron = new THREE.Mesh(
          new THREE.BoxGeometry(0.48, 1.0 + centerDist * 1.4, 0.12),
          metalMat
        );
        chevron.position.copy(pt);
        chevron.position.y -= (0.5 + centerDist * 0.7);
        bibGroup.add(chevron);

        const gem = new THREE.Mesh(createBrilliantGemGeometry(0.16 + centerDist * 0.12), diamondMat);
        gem.position.copy(pt);
        gem.position.y -= (0.5 + centerDist * 0.7);
        gem.position.z += 0.1;
        bibGroup.add(gem);
      }
      group.add(bibGroup);
      break;
    }
  }

  return group;
}
