import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { JewelConfig } from './types';
import { createJewelMaterials } from './materials';

/**
 * Builds a thick 3D relief mesh from a transparent cutout image, or loads a GLB if provided.
 */
export async function buildCustomJewel(config: JewelConfig): Promise<THREE.Group> {
  const group = new THREE.Group();
  group.name = `custom_${config.id}`;

  if (config.modelUrl) {
    try {
      const loader = new GLTFLoader();
      const gltf = await loader.loadAsync(config.modelUrl);
      const model = gltf.scene;

      // Normalize size to approx 4cm
      const box = new THREE.Box3().setFromObject(model);
      const size = new THREE.Vector3();
      box.getSize(size);
      const maxDim = Math.max(size.x, size.y, size.z) || 1;
      const targetScale = 4.0 / maxDim;
      model.scale.setScalar(targetScale);
      group.add(model);
      return group;
    } catch (err) {
      console.warn('Failed to load GLB model, falling back to relief mesh:', err);
    }
  }

  const textureUrl = config.cutoutUrl;
  if (!textureUrl) {
    // Basic placeholder mesh
    const placeholder = new THREE.Mesh(
      new THREE.TorusGeometry(1.5, 0.2, 16, 32),
      createJewelMaterials(config.metalTone).metalMat
    );
    group.add(placeholder);
    return group;
  }

  // Load image texture
  const texture = await new Promise<THREE.Texture>((resolve) => {
    new THREE.TextureLoader().load(
      textureUrl,
      (t) => {
        t.colorSpace = THREE.SRGBColorSpace;
        resolve(t);
      },
      undefined,
      () => {
        const canvas = document.createElement('canvas');
        canvas.width = 64;
        canvas.height = 64;
        resolve(new THREE.CanvasTexture(canvas));
      }
    );
  });

  // Front & Back photo material
  const frontMat = new THREE.MeshStandardMaterial({
    map: texture,
    transparent: true,
    alphaTest: 0.08,
    roughness: 0.25,
    metalness: 0.85,
    side: THREE.FrontSide,
  });

  // Authentic fine gold backside with hallmark and under-gallery
  const { createRealisticJewelleryBacksideTexture } = await import('@/components/TurntablePreview');
  const backTex = createRealisticJewelleryBacksideTexture(texture.image as HTMLImageElement, config.metalTone || 'gold');
  const backMat = new THREE.MeshStandardMaterial({
    map: backTex,
    transparent: true,
    alphaTest: 0.08,
    roughness: 0.22,
    metalness: 0.95,
    side: THREE.BackSide,
  });

  // Dual planar relief plates with 0.18cm depth spacer
  const width = config.dimensions.width || 4.0;
  const height = config.dimensions.height || 4.0;
  const geom = new THREE.PlaneGeometry(width, height);

  const frontMesh = new THREE.Mesh(geom, frontMat);
  frontMesh.position.z = 0.09;
  group.add(frontMesh);

  const backMesh = new THREE.Mesh(geom, backMat);
  backMesh.position.z = -0.09;
  backMesh.rotation.y = Math.PI;
  group.add(backMesh);

  return group;
}
