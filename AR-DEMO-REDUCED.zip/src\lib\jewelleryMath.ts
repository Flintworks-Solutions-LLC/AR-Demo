export interface Landmark {
  x: number;
  y: number;
  z: number;
  visibility?: number;
}

export interface CanvasTransform {
  canvasWidth: number;
  canvasHeight: number;
  videoWidth: number;
  videoHeight: number;
  dpr: number;
  scale: number;
  offsetX: number;
  offsetY: number;
  renderedW: number;
  renderedH: number;
  isMirrored: boolean;
}

/** Backward compatibility interface */
export interface CoverMapping extends CanvasTransform {
  stageW: number;
  stageH: number;
  videoW: number;
  videoH: number;
}

/**
 * Compute the transform mapping from normalized video coordinates [0..1]
 * to the overlay canvas pixels, honoring object-fit: cover, mirror/flip, and devicePixelRatio.
 */
export function computeCanvasTransform(
  canvasW: number,
  canvasH: number,
  videoW: number,
  videoH: number,
  isMirrored: boolean,
  dpr = 1
): CanvasTransform {
  const vW = videoW || canvasW || 1;
  const vH = videoH || canvasH || 1;
  const cW = canvasW || 1;
  const cH = canvasH || 1;

  // object-fit: cover scales by the maximum dimension ratio
  const scale = Math.max(cW / vW, cH / vH);
  const renderedW = vW * scale;
  const renderedH = vH * scale;

  // Centered crop offsets in canvas pixels
  const offsetX = (cW - renderedW) / 2;
  const offsetY = (cH - renderedH) / 2;

  return {
    canvasWidth: cW,
    canvasHeight: cH,
    videoWidth: vW,
    videoHeight: vH,
    dpr,
    scale,
    offsetX,
    offsetY,
    renderedW,
    renderedH,
    isMirrored,
  };
}

/** Backward compatibility wrapper */
export function computeCoverMapping(
  stageW: number,
  stageH: number,
  videoW: number,
  videoH: number
): CoverMapping {
  const ct = computeCanvasTransform(stageW, stageH, videoW, videoH, false, 1);
  return {
    ...ct,
    stageW,
    stageH,
    videoW,
    videoH,
  };
}

/**
 * Single shared landmark-to-screen mapping helper:
 * Maps an un-mirrored normalized MediaPipe landmark [0..1] from video coordinate space
 * directly into overlay canvas buffer pixel coordinates, matching the <video> element's
 * object-fit: cover crop, mirror/flip, and devicePixelRatio.
 */
export function toCanvas(
  lm: Landmark | { x: number; y: number; z?: number; visibility?: number },
  transform: CanvasTransform
): Landmark {
  // If mirrored (e.g. user-facing selfie camera), flip X
  const normX = transform.isMirrored ? 1 - lm.x : lm.x;
  const pxX = transform.offsetX + normX * transform.renderedW;
  const pxY = transform.offsetY + lm.y * transform.renderedH;
  // Depth z scaled uniformly by rendered width
  const pxZ = (lm.z || 0) * transform.renderedW;

  return {
    x: pxX,
    y: pxY,
    z: pxZ,
    visibility: (lm as Landmark).visibility,
  };
}

/**
 * Shared helper: maps an array of landmarks through the canvas transform.
 */
export function mapLandmarksToCanvas(
  landmarks: Landmark[] | null | undefined,
  transform: CanvasTransform
): Landmark[] | null {
  if (!landmarks) return null;
  return landmarks.map((lm) => toCanvas(lm, transform));
}

/** Backward compatibility wrapper */
export function mapLandmarkToCover(lm: Landmark, mapping: CoverMapping): Landmark {
  return toCanvas(lm, mapping);
}

/** Backward compatibility wrapper */
export function mapLandmarksToCover(
  landmarks: Landmark[] | null | undefined,
  mapping: CoverMapping
): Landmark[] | null {
  if (!landmarks) return null;
  return mapLandmarksToCanvas(landmarks, mapping);
}

// ── One Euro Filter (Adaptive low-latency jitter filter) ─────────────────────
export class OneEuroFilter {
  private minCutoff: number;
  private beta: number;
  private dCutoff: number;
  private xPrev: number | null = null;
  private dxPrev: number = 0;
  private tPrev: number = 0;

  constructor(minCutoff = 0.8, beta = 0.015, dCutoff = 1.0) {
    this.minCutoff = minCutoff;
    this.beta = beta;
    this.dCutoff = dCutoff;
  }

  reset() {
    this.xPrev = null;
    this.dxPrev = 0;
    this.tPrev = 0;
  }

  private sf(te: number, cutoff: number) {
    const r = 2 * Math.PI * cutoff * te;
    return r / (r + 1);
  }

  private es(a: number, x: number, xp: number) {
    return a * x + (1 - a) * xp;
  }

  filter(x: number, timestamp: number): number {
    if (this.xPrev === null) {
      this.xPrev = x;
      this.tPrev = timestamp;
      return x;
    }
    const te = (timestamp - this.tPrev) / 1000;
    if (te <= 0) return this.xPrev;
    const ad = this.sf(te, this.dCutoff);
    const dx = (x - this.xPrev) / te;
    const dxHat = this.es(ad, dx, this.dxPrev);
    const cutoff = this.minCutoff + this.beta * Math.abs(dxHat);
    const a = this.sf(te, cutoff);
    const xHat = this.es(a, x, this.xPrev);
    this.xPrev = xHat;
    this.dxPrev = dxHat;
    this.tPrev = timestamp;
    return xHat;
  }

  /**
   * Angle filter with unwrapping so rotations across [-π, π] do not jump 360°.
   */
  filterAngle(rad: number, timestamp: number): number {
    if (this.xPrev === null) {
      this.xPrev = rad;
      this.tPrev = timestamp;
      return rad;
    }
    let diff = rad - this.xPrev;
    while (diff > Math.PI) diff -= 2 * Math.PI;
    while (diff < -Math.PI) diff += 2 * Math.PI;
    const target = this.xPrev + diff;
    return this.filter(target, timestamp);
  }
}

/** 3D coordinate filter for a single landmark */
export class Landmark3DFilter {
  x: OneEuroFilter;
  y: OneEuroFilter;
  z: OneEuroFilter;

  constructor(minCutoff = 0.8, beta = 0.015, dCutoff = 1.0) {
    this.x = new OneEuroFilter(minCutoff, beta, dCutoff);
    this.y = new OneEuroFilter(minCutoff, beta, dCutoff);
    this.z = new OneEuroFilter(minCutoff, beta, dCutoff);
  }

  reset() {
    this.x.reset();
    this.y.reset();
    this.z.reset();
  }

  filter(lm: Landmark, timestamp: number): Landmark {
    return {
      x: this.x.filter(lm.x, timestamp),
      y: this.y.filter(lm.y, timestamp),
      z: this.z.filter(lm.z, timestamp),
      visibility: lm.visibility,
    };
  }
}

/** Bank of filters for an array of landmarks (face, pose, hand) */
export class LandmarkFilterArray {
  private filters: Landmark3DFilter[] = [];
  private minCutoff: number;
  private beta: number;

  constructor(count = 478, minCutoff = 0.8, beta = 0.015) {
    this.minCutoff = minCutoff;
    this.beta = beta;
    this.ensureLength(count);
  }

  private ensureLength(count: number) {
    while (this.filters.length < count) {
      this.filters.push(new Landmark3DFilter(this.minCutoff, this.beta));
    }
  }

  reset() {
    for (const f of this.filters) f.reset();
  }

  filter(landmarks: Landmark[] | null | undefined, timestamp: number): Landmark[] | null {
    if (!landmarks) return null;
    this.ensureLength(landmarks.length);
    return landmarks.map((lm, i) => this.filters[i].filter(lm, timestamp));
  }
}

export class TransformFilter {
  x: OneEuroFilter;
  y: OneEuroFilter;
  scale: OneEuroFilter;
  rotation: OneEuroFilter;
  opacity: OneEuroFilter;

  constructor(minCutoff = 0.8, beta = 0.015, dCutoff = 1.0) {
    this.x = new OneEuroFilter(minCutoff, beta, dCutoff);
    this.y = new OneEuroFilter(minCutoff, beta, dCutoff);
    this.scale = new OneEuroFilter(minCutoff, beta, dCutoff);
    this.rotation = new OneEuroFilter(minCutoff, beta, dCutoff);
    this.opacity = new OneEuroFilter(1.5, 0.02, dCutoff);
  }

  reset() {
    this.x.reset();
    this.y.reset();
    this.scale.reset();
    this.rotation.reset();
    this.opacity.reset();
  }

  filter(
    t: { x: number; y: number; scale: number; rotation: number; opacity?: number },
    timestamp: number
  ) {
    return {
      x: this.x.filter(t.x, timestamp),
      y: this.y.filter(t.y, timestamp),
      scale: this.scale.filter(t.scale, timestamp),
      rotation: this.rotation.filterAngle(t.rotation, timestamp),
      opacity: this.opacity.filter(t.opacity ?? 1, timestamp),
    };
  }
}

// ── Distance helpers ────────────────────────────────────────────────────────
export function dist(a: { x: number; y: number }, b: { x: number; y: number }) {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}

export function distPx(a: { x: number; y: number }, b: { x: number; y: number }) {
  return dist(a, b);
}

// ── Earring placement ────────────────────────────────────────────────────────
// Memory for swing physics (angular velocity & pendulum swing)
const earringSwingState = {
  prevRoll: 0,
  swingAngle: 0,
  angularVel: 0,
  lastTime: 0,
};

/**
 * Calculates earring position, scale, rotation in canvas pixel space.
 * Uses ear landmarks 234/454 directly placed at the lower earlobe.
 * Includes subtle swing physics from head motion.
 */
export function calcEarringTransform(
  lm: Landmark[],
  cw: number,
  ch: number,
  side: "left" | "right", // Screen side (viewer perspective)
  isStud = false
) {
  if (!lm || lm.length < 468) return null;

  const earL = lm[234];
  const earR = lm[454];

  // Distinguish screen left (smaller X) and screen right (larger X)
  const isScreenLeft = side === "left";
  const screenLeftEar = earL.x < earR.x ? earL : earR;
  const screenRightEar = earL.x < earR.x ? earR : earL;
  const earBase = isScreenLeft ? screenLeftEar : screenRightEar;

  const fw = dist(earL, earR); // Face width in canvas pixels
  if (fw <= 0) return null;

  // Head roll angle from eye corners (33 and 263 in canvas pixels)
  const screenLeftEye = lm[33].x < lm[263].x ? lm[33] : lm[263];
  const screenRightEye = lm[33].x < lm[263].x ? lm[263] : lm[33];
  const roll = Math.atan2(
    screenRightEye.y - screenLeftEye.y,
    screenRightEye.x - screenLeftEye.x
  );

  // Swing physics simulation
  const now = performance.now();
  const dt = Math.min(0.05, Math.max(0.001, (now - (earringSwingState.lastTime || now)) / 1000));
  earringSwingState.lastTime = now;

  const dRoll = roll - earringSwingState.prevRoll;
  earringSwingState.prevRoll = roll;

  // Pendulum spring physics
  const springK = 35.0;
  const damping = 4.5;
  earringSwingState.angularVel += (-dRoll * 18.0 - springK * earringSwingState.swingAngle - damping * earringSwingState.angularVel) * dt;
  earringSwingState.swingAngle += earringSwingState.angularVel * dt;
  earringSwingState.swingAngle = Math.max(-0.45, Math.min(0.45, earringSwingState.swingAngle));

  // Combined rotation: head roll + pendulum swing (gravity pulls downward)
  const totalRotation = roll * 0.4 + earringSwingState.swingAngle;

  // Head yaw check: hide earring when that ear is turned away from the camera
  const nose = lm[1] || lm[4];
  const minX = Math.min(earL.x, earR.x);
  const maxX = Math.max(earL.x, earR.x);
  const span = maxX - minX;
  const noseRatio = span > 0 ? (nose.x - minX) / span : 0.5;

  const zLeft = screenLeftEar.z ?? 0;
  const zRight = screenRightEar.z ?? 0;

  if (isScreenLeft) {
    if (noseRatio < 0.32 || (zLeft - zRight) > 0.08 * fw) {
      return null;
    }
  } else {
    if (noseRatio > 0.68 || (zRight - zLeft) > 0.08 * fw) {
      return null;
    }
  }

  // Exact Earlobe Anchor Point:
  // Landmark 234/454 is tragus; the actual earlobe hangs directly below it, slightly outward from jaw
  const lobeX = isScreenLeft
    ? (earBase.x - 0.025 * fw)
    : (earBase.x + 0.025 * fw);
  const lobeY = earBase.y + 0.12 * fw;

  // Size: studs ~10% face width, drops/jhumkas ~20% face width
  const earringWidth = (isStud ? 0.10 : 0.20) * fw;

  return {
    x: lobeX,
    y: lobeY,
    scale: earringWidth,
    rotation: totalRotation,
    opacity: 1.0,
  };
}

// ── Nose ring placement ──────────────────────────────────────────────────────
/**
 * Calculates nose ring/stud transforms in canvas pixel space.
 * Uses anatomical nostril wing (ala nasi) landmarks 102 (screen left) and 331 (screen right).
 * Correctly scales for studs and naths.
 */
export function calcNoseRingTransform(lm: Landmark[], cw: number, ch: number, isNathOrHoop = false) {
  if (!lm || lm.length < 468) return null;
  const faceW = dist(lm[234], lm[454]);

  const screenLeftEye = lm[33].x < lm[263].x ? lm[33] : lm[263];
  const screenRightEye = lm[33].x < lm[263].x ? lm[263] : lm[33];
  const roll = Math.atan2(
    screenRightEye.y - screenLeftEye.y,
    screenRightEye.x - screenLeftEye.x
  );

  // Anatomical nostril wing (ala of nose) landmarks
  // 102 is lateral left nostril crest, 331 is lateral right nostril crest
  const leftNostril = lm[102] || lm[129] || lm[98];
  const rightNostril = lm[331] || lm[358] || lm[327];

  // Scale: nath ~0.24 face width, stud ~0.08 face width
  const scale = (isNathOrHoop ? 0.24 : 0.08) * faceW;

  const mk = (pt: Landmark) => ({
    x: pt.x,
    y: pt.y,
    scale,
    rotation: roll,
    opacity: 1,
  });

  return {
    left: mk(leftNostril),
    right: mk(rightNostril),
  };
}

// ── Necklace tuning options ─────────────────────────────────────────────────
export interface NecklaceTuning {
  neckWidthRatio: number;   // default 0.45
  neckYDropRatio: number;    // default 0.20
  pendantYDropRatio: number; // default 1.60
  chainSagRatio: number;     // default 1.35
}

export const DEFAULT_NECKLACE_TUNING: NecklaceTuning = {
  neckWidthRatio: 0.35,
  neckYDropRatio: 0.28,
  pendantYDropRatio: 0.70,
  chainSagRatio: 0.50,
};

// ── Necklace 3-point placement ───────────────────────────────────────────────
export interface NecklaceTargetPoints {
  leftNeck: { x: number; y: number };
  rightNeck: { x: number; y: number };
  pendant: { x: number; y: number };
  chainSag: { x: number; y: number };
  chestCenter: { x: number; y: number };
  tilt: number;
  isPendantInFrame: boolean;
  fw: number;
  shoulderWidth: number;
  cx: number;
  chinY: number;
}

/**
 * Compute the body target points for necklace PNG anchors in canvas pixel space.
 * Both `face` and `pose` are already mapped to canvas pixel space.
 * Anatomically hugs the neck & collarbone; never sags to the abdomen.
 */
export function calcNecklaceTargetPoints(
  face: Landmark[],
  pose: Landmark[] | null,
  cw: number,
  ch: number,
  tuning: NecklaceTuning = DEFAULT_NECKLACE_TUNING,
  necklaceType: string = 'regular'
): NecklaceTargetPoints | null {
  if (!face || face.length < 468) return null;

  const chin = face[152];
  const earR = face[234];
  const earL = face[454];

  // fw = distance between face ears in canvas pixels
  const fw = dist(earR, earL);
  const cx = (earR.x + earL.x) / 2;
  const chinY = chin.y;
  const jawWidth = face[172] && face[397] ? dist(face[172], face[397]) : fw;

  const maxTilt = (12 * Math.PI) / 180;

  // Pose shoulder detection (Pose 11, 12 in canvas pixels)
  const poseS11 = pose?.[11];
  const poseS12 = pose?.[12];
  const shouldersVisible =
    Boolean(poseS11 &&
    poseS12 &&
    (poseS11.visibility ?? 1) > 0.4 &&
    (poseS12.visibility ?? 1) > 0.4);

  let sMidX = cx;
  let neckBaseY = chinY + 0.32 * fw; // Anatomical suprasternal notch
  let neckHalfW = 0.35 * fw;
  let shoulderTilt = 0;
  let shoulderWidth = fw * 1.8;
  let chestY = neckBaseY + fw * 0.58;

  if (shouldersVisible && pose) {
    let s1 = { x: pose[11].x, y: pose[11].y };
    let s2 = { x: pose[12].x, y: pose[12].y };
    if (s1.x > s2.x) {
      const tmp = s1;
      s1 = s2;
      s2 = tmp;
    }

    shoulderWidth = dist(s1, s2);
    const sMidY = (s1.y + s2.y) / 2;
    const earMidX = (earR.x + earL.x) / 2;
    const shoulderMidX = (s1.x + s2.x) / 2;
    sMidX = earMidX * 0.3 + shoulderMidX * 0.7;
    chestY = sMidY;

    // Suprasternal notch is ~45% between chin and shoulder line
    neckBaseY = chinY + Math.max(20, (sMidY - chinY) * 0.45);
    neckHalfW = Math.min(
      shoulderWidth * 0.18,
      fw * tuning.neckWidthRatio,
      jawWidth * 0.48
    );
    const rawShoulderAngle = Math.atan2(s2.y - s1.y, s2.x - s1.x);
    shoulderTilt = Math.max(-maxTilt, Math.min(maxTilt, rawShoulderAngle));
  }

  const type = necklaceType.toLowerCase();
  const isChoker = type === 'choker' || type.includes('choker') || type.includes('collar') || type.includes('hasli');

  // Use the ear/jaw span and shoulder line to locate the neck base endpoints.
  const lNx = sMidX - neckHalfW;
  const rNx = sMidX + neckHalfW;
  const lNy = neckBaseY - Math.sin(shoulderTilt) * neckHalfW - (isChoker ? 0.08 : 0.04) * fw;
  const rNy = neckBaseY + Math.sin(shoulderTilt) * neckHalfW - (isChoker ? 0.08 : 0.04) * fw;

  // The pendant hangs vertically at 65% of the neck-to-chest distance.
  const chestDistance = Math.max(fw * (isChoker ? 0.16 : 0.38), chestY - neckBaseY);
  const pendX = sMidX;
  const pendY = neckBaseY + 0.65 * chestDistance;
  const sagX = sMidX;
  const sagY = (lNy + rNy) / 2 + chestDistance * 0.28;

  return {
    leftNeck: { x: lNx, y: lNy },
    rightNeck: { x: rNx, y: rNy },
    pendant: { x: pendX, y: pendY },
    chainSag: { x: sagX, y: sagY },
    chestCenter: { x: pendX, y: pendY },
    tilt: shoulderTilt,
    isPendantInFrame: pendY <= ch + 150,
    fw,
    shoulderWidth,
    cx: sMidX,
    chinY,
  };
}

// ── Bangle placement ─────────────────────────────────────────────────────────
export function calcBangleTransform(hand: Landmark[]) {
  if (!hand || hand.length < 21) return null;
  const wrist = hand[0];
  const mid = hand[9];
  const lm5 = hand[5];
  const lm17 = hand[17];

  const palmLen = dist(wrist, mid);
  const dx = wrist.x - mid.x;
  const dy = wrist.y - mid.y;
  const len = Math.sqrt(dx * dx + dy * dy) + 1e-6;

  const cx = wrist.x + 0.12 * palmLen * (dx / len);
  const cy = wrist.y + 0.12 * palmLen * (dy / len);
  const width = 0.95 * dist(lm5, lm17);
  const rotation = Math.atan2(dy / len, dx / len) + Math.PI / 2;

  return { x: cx, y: cy, scale: width, rotation, opacity: 1 };
}

// ── Finger ring placement ────────────────────────────────────────────────────
export function calcRingTransform(hand: Landmark[]) {
  if (!hand || hand.length < 21) return null;
  const mcp = hand[13]; // ring MCP
  const pip = hand[14]; // ring PIP
  const cx = (mcp.x + pip.x) / 2;
  const cy = (mcp.y + pip.y) / 2;
  const width = Math.min(dist(mcp, hand[9]), dist(mcp, hand[17])) * 0.9;
  const rotation = Math.atan2(pip.y - mcp.y, pip.x - mcp.x);

  return { x: cx, y: cy, scale: width, rotation, opacity: 1 };
}
