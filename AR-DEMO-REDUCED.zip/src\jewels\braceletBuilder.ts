import * as THREE from 'three';
import { JewelConfig } from './types';
import { createJewelMaterials, createBrilliantGemGeometry } from './materials';

/**
 * Builds one of 10 distinct, richly detailed 3D bracelets/bangles.
 * Scale: 1 unit = 1 cm (bangle radius ~3.1 cm, diameter ~6.2 cm).
 * Axis is aligned along Z (torus in XY plane) so it can wrap around the forearm in live try-on.
 */
export function buildBracelet(config: JewelConfig): THREE.Group {
  const group = new THREE.Group();
  group.name = `bracelet_${config.id}`;

  const { metalMat, diamondMat, rubyMat, emeraldMat, pearlMat } =
    createJewelMaterials(config.metalTone);

  const radius = 3.1; // 6.2cm internal diameter
  switch (config.style) {
    case 'plain_polished': {
      // Sleek chamfered gold kada
      const kada = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.28, 24, 72), metalMat);
      group.add(kada);

      // Inner comfort rim
      const innerRim = new THREE.Mesh(new THREE.TorusGeometry(radius - 0.08, 0.12, 16, 72), metalMat);
      group.add(innerRim);
      break;
    }

    case 'engraved_kada': {
      // Traditional repoussé etched kada with relief ridges
      const base = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.32, 24, 72), metalMat);
      group.add(base);

      // Relief fluted ribs around perimeter
      const ribCount = 36;
      for (let i = 0; i < ribCount; i++) {
        const a = (i * Math.PI * 2) / ribCount;
        const rib = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.04, 8, 16), metalMat);
        rib.position.set(Math.cos(a) * radius, Math.sin(a) * radius, 0);
        rib.rotation.z = a;
        rib.rotation.y = Math.PI / 2;
        group.add(rib);
      }
      break;
    }

    case 'twisted_rope': {
      // Braided double cable rope bangle
      const segments = 96;
      const strand1 = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.16, 16, segments), metalMat);
      strand1.position.z = -0.12;
      group.add(strand1);

      const strand2 = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.16, 16, segments), metalMat);
      strand2.position.z = 0.12;
      group.add(strand2);

      // Spiral wrap beads
      const beadCount = 32;
      for (let i = 0; i < beadCount; i++) {
        const a = (i * Math.PI * 2) / beadCount;
        const bead = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 10), metalMat);
        bead.position.set(Math.cos(a) * radius, Math.sin(a) * radius, Math.sin(a * 4) * 0.14);
        group.add(bead);
      }
      break;
    }

    case 'studded_diamond_line': {
      // Diamond tennis bracelet with 42 individual prong-set round brilliant diamonds
      const band = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.15, 16, 72), metalMat);
      group.add(band);

      const gemCount = 42;
      for (let i = 0; i < gemCount; i++) {
        const a = (i * Math.PI * 2) / gemCount;
        const gem = new THREE.Mesh(createBrilliantGemGeometry(0.12), diamondMat);
        gem.position.set(Math.cos(a) * (radius + 0.14), Math.sin(a) * (radius + 0.14), 0);
        gem.rotation.z = a - Math.PI / 2;
        group.add(gem);

        // Prong setting
        const prong = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.18, 6), metalMat);
        prong.position.set(Math.cos(a) * (radius + 0.10), Math.sin(a) * (radius + 0.10), 0.08);
        group.add(prong);
      }
      break;
    }

    case 'floral_filigree': {
      // Openwork lace filigree with ruby florets
      const outerRing = new THREE.Mesh(new THREE.TorusGeometry(radius + 0.18, 0.08, 12, 64), metalMat);
      group.add(outerRing);
      const innerRing = new THREE.Mesh(new THREE.TorusGeometry(radius - 0.18, 0.08, 12, 64), metalMat);
      group.add(innerRing);

      const florets = 16;
      for (let i = 0; i < florets; i++) {
        const a = (i * Math.PI * 2) / florets;
        const x = Math.cos(a) * radius;
        const y = Math.sin(a) * radius;

        // Ruby center
        const ruby = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 10), rubyMat);
        ruby.position.set(x, y, 0);
        group.add(ruby);

        // Gold petal ring
        const petalRing = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.035, 8, 16), metalMat);
        petalRing.position.set(x, y, 0);
        group.add(petalRing);
      }
      break;
    }

    case 'flat_wide_cuff': {
      // 2.2 cm architectural wide cuff with satin bevels and diamond studs
      const cuff = new THREE.Mesh(
        new THREE.CylinderGeometry(radius, radius, 1.8, 64, 1, true),
        metalMat
      );
      cuff.rotation.x = Math.PI / 2;
      group.add(cuff);

      // Top and bottom bezel borders
      const topRim = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.08, 12, 64), metalMat);
      topRim.position.z = 0.9;
      group.add(topRim);

      const bottomRim = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.08, 12, 64), metalMat);
      bottomRim.position.z = -0.9;
      group.add(bottomRim);

      // Embedded diamond rivets
      const rivets = 18;
      for (let i = 0; i < rivets; i++) {
        const a = (i * Math.PI * 2) / rivets;
        const gem = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), diamondMat);
        gem.position.set(Math.cos(a) * (radius + 0.02), Math.sin(a) * (radius + 0.02), 0);
        group.add(gem);
      }
      break;
    }

    case 'temple_pattern': {
      // South Indian antique temple bangle with medallions and emerald accents
      const base = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.28, 20, 64), metalMat);
      group.add(base);

      const motifs = 12;
      for (let i = 0; i < motifs; i++) {
        const a = (i * Math.PI * 2) / motifs;
        const x = Math.cos(a) * (radius + 0.18);
        const y = Math.sin(a) * (radius + 0.18);

        // Medallion coin
        const coin = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.08, 16), metalMat);
        coin.position.set(x, y, 0);
        coin.rotation.z = a - Math.PI / 2;
        group.add(coin);

        // Emerald cabochon center
        const em = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), emeraldMat);
        em.position.set(x, y, 0.05);
        group.add(em);
      }
      break;
    }

    case 'beaded_mala': {
      // Fluted spherical gold beads strung into rigid bangle
      const count = 30;
      for (let i = 0; i < count; i++) {
        const a = (i * Math.PI * 2) / count;
        const bead = new THREE.Mesh(new THREE.SphereGeometry(0.24, 16, 16), metalMat);
        bead.position.set(Math.cos(a) * radius, Math.sin(a) * radius, 0);
        group.add(bead);

        // Intercalary pearl every 5th bead
        if (i % 5 === 0) {
          const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.18, 14, 14), pearlMat);
          pearl.position.set(Math.cos(a + 0.08) * radius, Math.sin(a + 0.08) * radius, 0.18);
          group.add(pearl);
        }
      }
      break;
    }

    case 'double_band': {
      // Dual parallel gold wires united by cross bars
      const ring1 = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.12, 16, 64), metalMat);
      ring1.position.z = -0.4;
      group.add(ring1);

      const ring2 = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.12, 16, 64), metalMat);
      ring2.position.z = 0.4;
      group.add(ring2);

      const crossBars = 16;
      for (let i = 0; i < crossBars; i++) {
        const a = (i * Math.PI * 2) / crossBars;
        const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.8, 8), metalMat);
        bar.position.set(Math.cos(a) * radius, Math.sin(a) * radius, 0);
        bar.rotation.x = Math.PI / 2;
        group.add(bar);

        // Small diamond at each junction
        const gem = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), diamondMat);
        gem.position.set(Math.cos(a) * (radius + 0.08), Math.sin(a) * (radius + 0.08), 0);
        group.add(gem);
      }
      break;
    }

    case 'open_cuff_stones':
    default: {
      // Open bypass torque cuff with two emerald pear finials
      // Arc of 300 degrees (leaving 60 degrees open for wrist entry)
      const cuffGeom = new THREE.TorusGeometry(radius, 0.22, 20, 64, Math.PI * 1.66);
      const cuff = new THREE.Mesh(cuffGeom, metalMat);
      cuff.rotation.z = Math.PI * 0.17;
      group.add(cuff);

      // Finial 1 (emerald)
      const finial1 = new THREE.Mesh(createBrilliantGemGeometry(0.38), emeraldMat);
      const a1 = Math.PI * 0.17;
      finial1.position.set(Math.cos(a1) * radius, Math.sin(a1) * radius, 0);
      group.add(finial1);

      // Finial 2 (emerald)
      const a2 = Math.PI * 0.17 + Math.PI * 1.66;
      const finial2 = new THREE.Mesh(createBrilliantGemGeometry(0.38), emeraldMat);
      finial2.position.set(Math.cos(a2) * radius, Math.sin(a2) * radius, 0);
      group.add(finial2);
      break;
    }
  }

  return group;
}
