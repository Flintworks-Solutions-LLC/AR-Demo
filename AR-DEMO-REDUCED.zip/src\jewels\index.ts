import * as THREE from 'three';
import { JewelConfig, MetalColorType } from './types';
import { buildRing } from './ringBuilder';
import { buildBracelet } from './braceletBuilder';
import { buildEarringPair } from './earringBuilder';
import { buildNecklace } from './necklaceBuilder';
import { buildNoseRing } from './noseRingBuilder';
import { buildCustomJewel } from './reliefBuilder';
import { updateGroupMetal } from './materials';

export * from './types';
export * from './materials';
export * from './catalog';
export * from './ringBuilder';
export * from './braceletBuilder';
export * from './earringBuilder';
export * from './necklaceBuilder';
export * from './noseRingBuilder';
export * from './reliefBuilder';

/**
 * Builds the exact 3D model for any jewel config.
 * Throws a descriptive error if the item cannot be built so that Debug displays it visibly.
 */
export async function buildJewel(config: JewelConfig, metalTone?: MetalColorType): Promise<THREE.Group> {
  if (!config) {
    throw new Error('Fatal: buildJewel called with null or undefined JewelConfig');
  }

  // If metalTone is provided, override config.metalTone
  const effectiveConfig: JewelConfig = metalTone ? { ...config, metalTone } : config;

  let model: THREE.Group;

  if (effectiveConfig.isCustom || effectiveConfig.cutoutUrl || effectiveConfig.modelUrl) {
    model = await buildCustomJewel(effectiveConfig);
  } else {
    switch (effectiveConfig.category) {
      case 'finger_ring':
        model = buildRing(effectiveConfig);
        break;
      case 'bangles':
        model = buildBracelet(effectiveConfig);
        break;
      case 'earrings':
        // For turntable viewer, default to pair; live try-on can access buildSingleEarring
        model = buildEarringPair(effectiveConfig);
        break;
      case 'necklace':
        model = buildNecklace(effectiveConfig);
        break;
      case 'nose_ring':
        model = buildNoseRing(effectiveConfig);
        break;
      default:
        throw new Error(`Fatal: No model builder registered for category "${effectiveConfig.category}" (item: ${effectiveConfig.id})`);
    }
  }

  if (!model) {
    throw new Error(`Fatal: Model generator failed for jewel ID "${effectiveConfig.id}"`);
  }

  if (metalTone) {
    updateGroupMetal(model, metalTone);
  }

  return model;
}
