import * as THREE from "three";

/**
 * Client-side GLB/GLTF file validator.
 * Checks: extension, MIME type, magic header bytes ("glTF"), and max file size.
 */

export interface GlbValidationResult {
  valid: boolean;
  error?: string;
  warnings?: string[];
}

const GLB_MAGIC = new Uint8Array([0x67, 0x6c, 0x54, 0x46]); // "glTF"
const MAX_SIZE_BYTES = 20 * 1024 * 1024; // 20 MB
const VALID_EXTENSIONS = [".glb", ".gltf"];
const VALID_MIME_TYPES = [
  "model/gltf-binary",
  "model/gltf+json",
  "application/octet-stream", // browsers often report this for .glb
  "", // some browsers return empty MIME for unknown types
];

/**
 * Validates a GLB file on the client side before uploading.
 * - Checks file extension
 * - Checks MIME type (permissive – browsers often mislabel .glb)
 * - Reads first 4 bytes to confirm magic header (rejects renamed files)
 * - Enforces 20 MB max size
 */
export async function validateGlbFile(file: File): Promise<GlbValidationResult> {
  const name = file.name.toLowerCase();
  const ext = name.substring(name.lastIndexOf("."));

  // 1. Extension check
  if (!VALID_EXTENSIONS.includes(ext)) {
    return {
      valid: false,
      error: `Invalid file type. Only .glb or .gltf files are accepted. You uploaded: "${file.name}"`,
    };
  }

  // 2. Size check
  if (file.size > MAX_SIZE_BYTES) {
    const sizeMB = (file.size / 1024 / 1024).toFixed(1);
    return {
      valid: false,
      error: `File too large (${sizeMB} MB). Maximum allowed size is 20 MB.`,
    };
  }

  // 3. MIME type check (lenient – .glb often reported as application/octet-stream)
  const mime = file.type || "";
  if (!VALID_MIME_TYPES.includes(mime) && !mime.startsWith("model/")) {
    return {
      valid: false,
      error: `Unexpected MIME type "${mime}". Expected a GLB or GLTF 3D model file.`,
    };
  }

  // 4. Magic header check (only for .glb – GLTF is JSON so skip)
  if (ext === ".glb") {
    try {
      const headerBuffer = await file.slice(0, 4).arrayBuffer();
      const headerBytes = new Uint8Array(headerBuffer);
      const magicMatches = GLB_MAGIC.every((byte, i) => headerBytes[i] === byte);
      if (!magicMatches) {
        return {
          valid: false,
          error:
            "File does not appear to be a valid GLB binary. The \"glTF\" magic header was not found. " +
            "Make sure you export as GLB (Binary) from Blender/your 3D tool, not as GLTF Separate.",
        };
      }
    } catch {
      return {
        valid: false,
        error: "Could not read the file header. Please try again or choose a different file.",
      };
    }
  }

  return { valid: true };
}

/**
 * Checks triangle count and texture sizes on a loaded THREE.js GLTF scene.
 * Returns warnings (not errors) so the user can still proceed.
 */
export function getGlbModelWarnings(scene: THREE.Object3D): string[] {
  const warnings: string[] = [];

  let triangleCount = 0;
  const textureSet = new Set<THREE.Texture>();

  scene.traverse((child: unknown) => {
    const mesh = child as THREE.Mesh;
    if (mesh.isMesh && mesh.geometry) {
      const geo = mesh.geometry as THREE.BufferGeometry;
      if (geo.index) {
        triangleCount += geo.index.count / 3;
      } else if (geo.attributes?.position) {
        triangleCount += geo.attributes.position.count / 3;
      }
    }
    const obj = child as THREE.Object3D & { material?: THREE.Material | THREE.Material[] };
    const mats = obj.material
      ? Array.isArray(obj.material)
        ? obj.material
        : [obj.material]
      : [];
    for (const mat of mats) {
      const m = mat as THREE.MeshStandardMaterial;
      if (m.map) textureSet.add(m.map);
      if (m.normalMap) textureSet.add(m.normalMap);
      if (m.roughnessMap) textureSet.add(m.roughnessMap);
    }
  });

  if (triangleCount > 200_000) {
    warnings.push(
      `High polygon count: ~${Math.round(triangleCount / 1000)}K triangles. ` +
        "Models above 200K triangles may load slowly on mobile devices. " +
        "Consider using the Decimate modifier in Blender to reduce complexity."
    );
  }

  textureSet.forEach((tex) => {
    const t = tex as THREE.Texture & { image?: { width: number; height: number } };
    if (t.image && (t.image.width > 2048 || t.image.height > 2048)) {
      if (!warnings.some((w) => w.startsWith("Oversized texture"))) {
        warnings.push(
          `Oversized texture detected (${t.image.width}×${t.image.height}px). ` +
            "Textures larger than 2048×2048px may cause performance issues. " +
            "Resize textures to 2K (2048×2048) or smaller before exporting."
        );
      }
    }
  });

  return warnings;
}
