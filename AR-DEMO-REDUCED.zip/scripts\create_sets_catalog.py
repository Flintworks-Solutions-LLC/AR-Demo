import os
from PIL import Image, ImageOps

os.makedirs('public/catalog/sets', exist_ok=True)

sets_def = [
    {
        'id': 'set_kundan_bridal',
        'neck': 'public/catalog/necklace/gold_necklace_01.png',
        'ear': 'public/catalog/earrings/gold_earrings_02.png',
        'out': 'public/catalog/sets/gold_set_01.png'
    },
    {
        'id': 'set_temple_heritage',
        'neck': 'public/catalog/necklace/gold_necklace_02.png',
        'ear': 'public/catalog/earrings/gold_earrings_01.png',
        'out': 'public/catalog/sets/gold_set_02.png'
    },
    {
        'id': 'set_filigree_choker',
        'neck': 'public/catalog/necklace/gold_necklace_03.png',
        'ear': 'public/catalog/earrings/gold_earrings_09.png',
        'out': 'public/catalog/sets/gold_set_03.png'
    },
    {
        'id': 'set_polki_lotus',
        'neck': 'public/catalog/necklace/gold_necklace_09.png',
        'ear': 'public/catalog/earrings/gold_earrings_11.png',
        'out': 'public/catalog/sets/gold_set_04.png'
    },
    {
        'id': 'set_maharani_hasli',
        'neck': 'public/catalog/necklace/gold_necklace_10.png',
        'ear': 'public/catalog/earrings/gold_earrings_14.png',
        'out': 'public/catalog/sets/gold_set_05.png'
    },
    {
        'id': 'set_peacock_bali',
        'neck': 'public/catalog/necklace/gold_necklace_12.png',
        'ear': 'public/catalog/earrings/gold_earrings_07.png',
        'out': 'public/catalog/sets/gold_set_06.png'
    },
    {
        'id': 'set_princess_diamond',
        'neck': 'public/catalog/necklace/gold_necklace_16.png',
        'ear': 'public/catalog/earrings/gold_earrings_03.png',
        'out': 'public/catalog/sets/gold_set_07.png'
    }
]

CANVAS_SIZE = 900

for s in sets_def:
    canvas = Image.new('RGBA', (CANVAS_SIZE, CANVAS_SIZE), (0, 0, 0, 0))
    neck_im = Image.open(s['neck']).convert('RGBA')
    ear_im = Image.open(s['ear']).convert('RGBA')

    # Resize necklace to fit nicely in lower-center area
    neck_w, neck_h = neck_im.size
    neck_scale = min(620 / neck_w, 560 / neck_h)
    new_neck_w = int(neck_w * neck_scale)
    new_neck_h = int(neck_h * neck_scale)
    neck_resized = neck_im.resize((new_neck_w, new_neck_h), Image.Resampling.LANCZOS)

    neck_x = (CANVAS_SIZE - new_neck_w) // 2
    neck_y = CANVAS_SIZE - new_neck_h - 40
    canvas.paste(neck_resized, (neck_x, neck_y), neck_resized)

    # Resize earrings to fit in top-left and top-right (no overlap with necklace)
    ear_w, ear_h = ear_im.size
    ear_scale = min(210 / ear_w, 220 / ear_h)
    new_ear_w = int(ear_w * ear_scale)
    new_ear_h = int(ear_h * ear_scale)
    ear_resized = ear_im.resize((new_ear_w, new_ear_h), Image.Resampling.LANCZOS)
    ear_mirrored = ImageOps.mirror(ear_resized)

    ear_left_x = 80
    ear_left_y = 50
    canvas.paste(ear_resized, (ear_left_x, ear_left_y), ear_resized)

    ear_right_x = CANVAS_SIZE - new_ear_w - 80
    ear_right_y = 50
    canvas.paste(ear_mirrored, (ear_right_x, ear_right_y), ear_mirrored)

    canvas.save(s['out'], 'PNG')
    print("Generated: " + s['out'])
