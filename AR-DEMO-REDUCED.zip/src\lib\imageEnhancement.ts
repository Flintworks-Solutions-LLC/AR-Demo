"use client";

import { MetalType } from "@/context/JewelleryStoreContext";

/**
 * Computes the principal axis of the alpha mask of an image or canvas.
 * Returns the upright rotation angle (in radians) needed so that the long axis
 * of the object (e.g. a cross or drop pendant) is aligned vertically.
 */
export function computeAlphaPrincipalAxis(
  source: HTMLCanvasElement | HTMLImageElement
): number {
  const w = (source as HTMLImageElement).naturalWidth || source.width;
  const h = (source as HTMLImageElement).naturalHeight || source.height;
  if (!w || !h) return 0;

  // Use a fast downscaled canvas (max 256x256) for robust moment computation
  const scale = Math.min(1, 256 / Math.max(w, h));
  const sw = Math.max(16, Math.round(w * scale));
  const sh = Math.max(16, Math.round(h * scale));

  const canvas = document.createElement("canvas");
  canvas.width = sw;
  canvas.height = sh;
  const ctx = canvas.getContext("2d");
  if (!ctx) return 0;

  ctx.drawImage(source, 0, 0, sw, sh);
  const imgData = ctx.getImageData(0, 0, sw, sh);
  const data = imgData.data;

  let m00 = 0;
  let m10 = 0;
  let m01 = 0;

  for (let y = 0; y < sh; y++) {
    for (let x = 0; x < sw; x++) {
      const a = data[(y * sw + x) * 4 + 3];
      if (a > 30) {
        const wgt = a / 255;
        m00 += wgt;
        m10 += x * wgt;
        m01 += y * wgt;
      }
    }
  }

  if (m00 < 40) return 0;

  const cx = m10 / m00;
  const cy = m01 / m00;

  let mu20 = 0;
  let mu02 = 0;
  let mu11 = 0;

  for (let y = 0; y < sh; y++) {
    for (let x = 0; x < sw; x++) {
      const a = data[(y * sw + x) * 4 + 3];
      if (a > 30) {
        const wgt = a / 255;
        const dx = x - cx;
        const dy = y - cy;
        mu20 += dx * dx * wgt;
        mu02 += dy * dy * wgt;
        mu11 += dx * dy * wgt;
      }
    }
  }

  // Orientation theta in [-pi/2, pi/2]
  // theta = 0 means major axis is horizontal (along X)
  // theta = pi/2 or -pi/2 means major axis is vertical (along Y)
  const theta = 0.5 * Math.atan2(2 * mu11, mu20 - mu02);

  // We want small tilts to be deskewed, but NEVER rotate an object sideways or by 90 degrees
  let uprightAngle = Math.PI / 2 - theta;
  while (uprightAngle > Math.PI / 2) uprightAngle -= Math.PI;
  while (uprightAngle < -Math.PI / 2) uprightAngle += Math.PI;

  // If the detected angle is larger than 25 degrees, the object is naturally wider
  // than tall (like a necklace) or already oriented. Do NOT rotate it sideways!
  if (Math.abs(uprightAngle) > (25 * Math.PI) / 180) {
    return 0;
  }

  return uprightAngle;
}

/**
 * Enhances an uploaded product canvas:
 * 1. Upscale 2x if long side is under 1024px.
 * 2. Auto-exposure: if mean luminance < 110, apply gamma 0.7 + unsharp mask (r: 1.2, amt: 0.6).
 * 3. Boost specular look: soft white highlight gradient on top-left of alpha area (screen blend 15%).
 * 4. Apply metal tint (gold/silver/rose) to luminance only so detail stays visible.
 */
export function enhanceUploadedProduct(
  inputCanvas: HTMLCanvasElement,
  metal: MetalType = "gold"
): HTMLCanvasElement {
  let cur = inputCanvas;
  const maxDim = Math.max(cur.width, cur.height);

  // 1. Upscale 2x (canvas, imageSmoothingQuality='high') if long side is under 1024px
  if (maxDim < 1024) {
    const upCanvas = document.createElement("canvas");
    upCanvas.width = cur.width * 2;
    upCanvas.height = cur.height * 2;
    const upCtx = upCanvas.getContext("2d");
    if (upCtx) {
      upCtx.imageSmoothingEnabled = true;
      upCtx.imageSmoothingQuality = "high";
      upCtx.drawImage(cur, 0, 0, upCanvas.width, upCanvas.height);
      cur = upCanvas;
    }
  }

  const w = cur.width;
  const h = cur.height;
  const ctx = cur.getContext("2d");
  if (!ctx) return cur;

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // Compute mean luminance of alpha area
  let totalLum = 0;
  let alphaCount = 0;
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] > 20) {
      const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
      totalLum += lum;
      alphaCount++;
    }
  }

  const meanLum = alphaCount > 0 ? totalLum / alphaCount : 128;
  const applyGamma = meanLum < 110;

  // Metal tint factors (applied to luminance only)
  const tintMap: Record<MetalType, [number, number, number]> = {
    gold: [1.0, 0.84, 0.40],
    silver: [0.96, 0.96, 0.98],
    rose_gold: [1.0, 0.75, 0.72],
  };
  const tint = tintMap[metal] || tintMap.gold;

  // 2. Auto-exposure (gamma 0.7 if mean luminance < 110) & 4. Metal tint to luminance
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] > 10) {
      let r = data[i];
      let g = data[i + 1];
      let b = data[i + 2];

      if (applyGamma) {
        r = Math.pow(r / 255, 0.7) * 255;
        g = Math.pow(g / 255, 0.7) * 255;
        b = Math.pow(b / 255, 0.7) * 255;
      }

      // Compute luminance
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;

      // Apply metal tint to luminance only, preserving structural detail
      const tr = lum * tint[0];
      const tg = lum * tint[1];
      const tb = lum * tint[2];

      data[i] = Math.min(255, Math.max(0, Math.round(r * 0.45 + tr * 0.55)));
      data[i + 1] = Math.min(255, Math.max(0, Math.round(g * 0.45 + tg * 0.55)));
      data[i + 2] = Math.min(255, Math.max(0, Math.round(b * 0.45 + tb * 0.55)));
    }
  }
  ctx.putImageData(imgData, 0, 0);

  // Unsharp mask (radius 1.2, amount 0.6)
  const blurCanvas = document.createElement("canvas");
  blurCanvas.width = w;
  blurCanvas.height = h;
  const bCtx = blurCanvas.getContext("2d");
  if (bCtx) {
    bCtx.filter = "blur(1.2px)";
    bCtx.drawImage(cur, 0, 0);

    const origData = ctx.getImageData(0, 0, w, h);
    const blurData = bCtx.getImageData(0, 0, w, h);
    const od = origData.data;
    const bd = blurData.data;
    const amount = 0.6;

    for (let i = 0; i < od.length; i += 4) {
      if (od[i + 3] > 10) {
        od[i] = Math.min(255, Math.max(0, od[i] + amount * (od[i] - bd[i])));
        od[i + 1] = Math.min(255, Math.max(0, od[i + 1] + amount * (od[i + 1] - bd[i + 1])));
        od[i + 2] = Math.min(255, Math.max(0, od[i + 2] + amount * (od[i + 2] - bd[i + 2])));
      }
    }
    ctx.putImageData(origData, 0, 0);
  }

  // 3. Boost specular look: soft white highlight gradient on top-left of alpha area (screen blend, 15%)
  const specCanvas = document.createElement("canvas");
  specCanvas.width = w;
  specCanvas.height = h;
  const sCtx = specCanvas.getContext("2d");
  if (sCtx) {
    const grad = sCtx.createRadialGradient(
      w * 0.25,
      h * 0.25,
      Math.max(8, w * 0.05),
      w * 0.35,
      h * 0.35,
      Math.max(w, h) * 0.75
    );
    grad.addColorStop(0, "rgba(255, 255, 255, 0.95)");
    grad.addColorStop(0.45, "rgba(255, 255, 255, 0.30)");
    grad.addColorStop(1, "rgba(255, 255, 255, 0)");
    sCtx.fillStyle = grad;
    sCtx.fillRect(0, 0, w, h);

    // Mask gradient to object alpha
    sCtx.globalCompositeOperation = "destination-in";
    sCtx.drawImage(cur, 0, 0);

    // Blend into main canvas with screen mode at 15% opacity
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.globalAlpha = 0.15;
    ctx.drawImage(specCanvas, 0, 0);
    ctx.restore();
  }

  return cur;
}

